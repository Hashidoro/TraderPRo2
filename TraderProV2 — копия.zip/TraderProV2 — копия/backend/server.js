const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
// Используем переменную окружения, если она есть, или стандартный URI по умолчанию
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const DB_NAME = process.env.DB_NAME || "traderpro";

const client = new MongoClient(MONGODB_URI);

let db;

async function connectDB() {
    try {
        await client.connect();
        db = client.db(DB_NAME); // Имя вашей базы данных
        console.log("✅ Connected successfully to MongoDB");

        // Принудительно создаем коллекцию users и уникальный индекс для email
        // Это также гарантирует создание самой базы данных 'traderpro' при первом запуске
        await db.collection('users').createIndex({ email: 1 }, { unique: true });
        console.log("✅ Database and collections are ready.");
    } catch (err) {
        console.error("❌ Failed to connect to MongoDB or create indexes", err);
        process.exit(1);
    }
}

// API Routes
app.get('/api/accounts', async (req, res) => {
    if (!db) {
        return res.status(500).json({ error: 'Database not connected' });
    }
    try {
        const accounts = await db.collection('accounts').find({}).toArray();
        // Преобразуем _id в id для совместимости с фронтендом
        const accountsWithId = accounts.map(acc => {
            acc.id = acc._id;
            delete acc._id;
            return acc;
        });
        res.json(accountsWithId);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/accounts', async (req, res) => {
    if (!db) {
        return res.status(500).json({ error: 'Database not connected' });
    }
    try {
        const accountData = req.body;
        const result = await db.collection('accounts').insertOne(accountData);
        
        // Возвращаем созданный документ с полем id
        const newAccount = { ...accountData, id: result.insertedId };
        res.status(201).json(newAccount);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/accounts/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const accountData = req.body;
        delete accountData.id;
        delete accountData._id;

        const result = await db.collection('accounts').updateOne(
            { _id: new ObjectId(id) },
            { $set: accountData }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({ error: 'Account not found' });
        }
        res.json({ message: 'Account updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/accounts/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const accountId = new ObjectId(req.params.id);
        const userId = req.get('User-Id'); // Предполагаем, что ID пользователя передается в заголовках

        if (!userId) {
            return res.status(401).json({ error: 'User ID is required' });
        }

        // В реальном приложении здесь была бы проверка, что аккаунт принадлежит пользователю

        const session = client.startSession();
        try {
            await session.withTransaction(async () => {
                await db.collection('trades').deleteMany({ accountId: accountId }, { session });
                await db.collection('payouts').deleteMany({ accountId: accountId }, { session });
                const accountResult = await db.collection('accounts').deleteOne({ _id: accountId }, { session });

                if (accountResult.deletedCount === 0) {
                    throw new Error('Account not found');
                }
            });
            res.status(204).send();
        } catch (err) {
            if (err.message === 'Account not found') {
                return res.status(404).json({ error: 'Account not found' });
            }
            console.error('Transaction failed:', err);
            res.status(500).json({ error: 'Internal server error during transaction' });
        } finally {
            await session.endSession();
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ===============================================
//  Trades API
// ===============================================

app.get('/api/trades', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const trades = await db.collection('trades').find({}).toArray();
        const tradesWithId = trades.map(t => {
            t.id = t._id;
            delete t._id;
            return t;
        });
        res.json(tradesWithId);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/trades', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const tradeData = req.body;
        if (tradeData.accountId) {
            tradeData.accountId = new ObjectId(tradeData.accountId);
        }
        const result = await db.collection('trades').insertOne(tradeData);
        const newTrade = { ...tradeData, id: result.insertedId };
        res.status(201).json(newTrade);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/trades/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const result = await db.collection('trades').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: 'Trade not found' });
        }
        res.status(204).send();
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ===============================================
//  Strategies API
// ===============================================

app.get('/api/strategies', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const strategies = await db.collection('strategies').find({}).toArray();
        const strategiesWithId = strategies.map(s => ({ ...s, id: s._id, _id: undefined }));
        res.json(strategiesWithId);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/strategies', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const strategyData = req.body;
        const result = await db.collection('strategies').insertOne(strategyData);
        const newStrategy = { ...strategyData, id: result.insertedId };
        res.status(201).json(newStrategy);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/strategies/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const strategyData = req.body;
        delete strategyData.id;
        delete strategyData._id;

        const result = await db.collection('strategies').updateOne(
            { _id: new ObjectId(id) },
            { $set: strategyData }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({ error: 'Strategy not found' });
        }
        res.json({ message: 'Strategy updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/strategies/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const result = await db.collection('strategies').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: 'Strategy not found' });
        }
        res.status(204).send();
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ===============================================
//  Setups API
// ===============================================

app.get('/api/setups', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const setups = await db.collection('setups').find({}).toArray();
        const setupsWithId = setups.map(s => ({ ...s, id: s._id, _id: undefined }));
        res.json(setupsWithId);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/setups', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const setupData = req.body;
        const result = await db.collection('setups').insertOne(setupData);
        const newSetup = { ...setupData, id: result.insertedId };
        res.status(201).json(newSetup);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/setups/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const setupData = req.body;
        delete setupData.id;
        delete setupData._id;

        const result = await db.collection('setups').updateOne(
            { _id: new ObjectId(id) },
            { $set: setupData }
        );

        if (result.matchedCount === 0) return res.status(404).json({ error: 'Setup not found' });
        res.json({ message: 'Setup updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/setups/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const result = await db.collection('setups').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: 'Setup not found' });
        }
        res.status(204).send();
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ===============================================
//  Entry Models API
// ===============================================

app.get('/api/entry-models', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const models = await db.collection('entry_models').find({}).toArray();
        const modelsWithId = models.map(m => ({ ...m, id: m._id, _id: undefined }));
        res.json(modelsWithId);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/entry-models', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const modelData = req.body;
        const result = await db.collection('entry_models').insertOne(modelData);
        const newModel = { ...modelData, id: result.insertedId };
        res.status(201).json(newModel);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/entry-models/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const modelData = req.body;
        delete modelData.id;
        delete modelData._id;

        const result = await db.collection('entry_models').updateOne({ _id: new ObjectId(id) }, { $set: modelData });
        if (result.matchedCount === 0) return res.status(404).json({ error: 'Entry Model not found' });
        res.json({ message: 'Entry Model updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/entry-models/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const result = await db.collection('entry_models').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: 'Entry Model not found' });
        }
        res.status(204).send();
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// ===============================================
//  Auth API
// ===============================================

app.post('/api/register', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { email, password, name } = req.body;

        if (!email || !password || !name) {
            return res.status(400).json({ message: 'Please provide name, email, and password.' });
        }

        const existingUser = await db.collection('users').findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User with this email already exists.' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = { name, email, password: hashedPassword, createdAt: new Date() };
        const result = await db.collection('users').insertOne(newUser);

        res.status(201).json({ id: result.insertedId, name, email });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/login', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Please provide email and password.' });
        }

        const user = await db.collection('users').findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid credentials.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid credentials.' });
        }

        res.json({ id: user._id, name: user.name, email: user.email });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/payouts', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const payouts = await db.collection('payouts').find({}).toArray();
        const payoutsWithId = payouts.map(p => {
            p.id = p._id;
            delete p._id;
            return p;
        });
        res.json(payoutsWithId);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/payouts', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const payoutData = req.body;
        // Важно: accountId должен быть ObjectId, если он ссылается на коллекцию accounts
        if (payoutData.accountId) {
            payoutData.accountId = new ObjectId(payoutData.accountId);
        }
        const result = await db.collection('payouts').insertOne(payoutData);
        const newPayout = { ...payoutData, id: result.insertedId };
        res.status(201).json(newPayout);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/payouts/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const payoutData = req.body;
        delete payoutData.id; // Убираем id из тела запроса

        if (payoutData.accountId) {
            payoutData.accountId = new ObjectId(payoutData.accountId);
        }

        const result = await db.collection('payouts').updateOne(
            { _id: new ObjectId(id) },
            { $set: payoutData }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({ error: 'Payout not found' });
        }
        res.json({ message: 'Payout updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.put('/api/trades/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const tradeData = req.body;
        delete tradeData.id;
        delete tradeData._id;

        if (tradeData.accountId) {
            tradeData.accountId = new ObjectId(tradeData.accountId);
        }

        const result = await db.collection('trades').updateOne(
            { _id: new ObjectId(id) },
            { $set: tradeData }
        );

        if (result.matchedCount === 0) return res.status(404).json({ error: 'Trade not found' });
        res.json({ message: 'Trade updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.delete('/api/payouts/:id', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not connected' });
    try {
        const { id } = req.params;
        const result = await db.collection('payouts').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: 'Payout not found' });
        }
        res.status(204).send(); // No Content
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Запуск сервера после подключения к БД
connectDB().then(() => {
    app.listen(port, () => {
        console.log(`Backend server listening at http://localhost:${port}`);
    });
});
