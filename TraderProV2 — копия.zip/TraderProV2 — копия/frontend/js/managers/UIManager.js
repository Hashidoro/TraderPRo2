// ===============================================
// 🎨 UI MANAGER - УПРАВЛІННЯ ІНТЕРФЕЙСОМ ТА ВІДОБРАЖЕННЯМ
// ===============================================

class UIManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.currentSection = 'dashboard';
        this.isSidebarCollapsed = false;
        this.modalStack = [];
        this.isLoginMode = true;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🧭 РОЗДІЛ: НАВІГАЦІЯ ТА СЕКЦІЇ                        █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ПОКАЗ СЕКЦІЇ
    async showSection(sectionName) {
        console.log('Switching to section:', sectionName);

        // Fetch and load the section HTML
        try {
            const response = await fetch(`sections/${sectionName}.html`);
            if (!response.ok) {
                throw new Error(`Could not load section: ${sectionName}`);
            }
            const html = await response.text();
            const targetSection = document.getElementById(sectionName);
            if (targetSection) {
                targetSection.innerHTML = html;
            } else {
                console.error('Section not found in DOM:', sectionName);
                return;
            }
        } catch (error) {
            console.error('Error loading section:', error);
            this.showNotification(`Could not load section: ${sectionName}`, 'error');
            return;
        }

        // Приховати всі секції
        this.hideAllSections();

        // Показати вибрану секцію
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
            console.log('Section activated:', sectionName);
        }

        // Оновити навігацію
        this.updateNavigation(sectionName);

        // Оновити заголовок
        this.updatePageTitle(sectionName);

        // Показати/приховати глобальний фільтр часу
        this.toggleTimeFilter(sectionName);

        // Спеціальна ініціалізація для секцій
        this.initializeSection(sectionName);

        // Оновити відступи
        this.updateMainContentMargin();
        this.createIcons(); // Re-initialize icons after new content is loaded
        if (sectionName === 'dashboard') this.initDashboardDragAndDrop();
    }

    // ПРИХОВАННЯ ВСІХ СЕКЦІЙ
    hideAllSections() {
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
    }

    // ОНОВЛЕННЯ НАВІГАЦІЇ
    updateNavigation(activeSection) {
        // Видалити активний клас з усіх посилань
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Додати активний клас до поточного посилання
        const activeLink = document.querySelector(`[data-section="${activeSection}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
            console.log('Navigation link activated:', activeSection);
        }
    }

    // ОНОВЛЕННЯ ЗАГОЛОВКУ СТОРІНКИ
    updatePageTitle(sectionName) {
        const pageTitle = document.getElementById('page-title');
        if (pageTitle) {
            pageTitle.textContent = this.getSectionTitle(sectionName);
        }

        // Оновлення breadcrumb (для зворотної сумісності)
        const breadcrumb = document.getElementById('current-section');
        if (breadcrumb) {
            breadcrumb.textContent = this.getSectionTitle(sectionName);
        }
    }

    // ОТРИМАННЯ НАЗВИ СЕКЦІЇ
    getSectionTitle(sectionName) {
        const titles = {
            'dashboard': 'Dashboard',
            'trades': 'Trade Journal',
            'accounts': 'Account Management',
            'strategies': 'Strategies & Setups',
            'calendar': 'Trading Calendar',
            'settings': 'Settings'
        };
        return titles[sectionName] || 'Dashboard';
    }

    // ПЕРЕМИКАННЯ ФІЛЬТРУ ЧАСУ
    toggleTimeFilter(sectionName) {
        const timeFilter = document.querySelector('.global-time-filter');
        if (timeFilter) {
            // Показувати тільки на dashboard та trades
            if (sectionName === 'dashboard' || sectionName === 'trades') {
                timeFilter.style.display = 'flex';
            } else {
                timeFilter.style.display = 'none';
            }
        }
    }

    // ІНІЦІАЛІЗАЦІЯ СЕКЦІЇ
    initializeSection(sectionName) {
        if (sectionName === 'dashboard') {
            const prevBtn = document.getElementById('calendar-prev-month');
            const nextBtn = document.getElementById('calendar-next-month');

            if (prevBtn && !prevBtn.hasAttribute('data-dashboard-calendar-setup')) {
                prevBtn.setAttribute('data-dashboard-calendar-setup', 'true');
                prevBtn.addEventListener('click', () => this.app.calendarManager.previousMonth());
            }
            if (nextBtn && !nextBtn.hasAttribute('data-dashboard-calendar-setup')) {
                nextBtn.setAttribute('data-dashboard-calendar-setup', 'true');
                nextBtn.addEventListener('click', () => this.app.calendarManager.nextMonth());
            }
        }
        switch (sectionName) {
            case 'calendar':
                this.app.calendarManager?.initCalendarSection();
                break;
            case 'strategies':
                this.app.strategyManager?.updateDisplay();
                break;
            case 'accounts':
                this.app.accountManager?.updateAccountsDisplay();
                break;
        }
    }

    // === AUTH MODAL ===
    showLogin() {
        this.isLoginMode = true;
        this.setupAuthModal();
        this.showModal('auth-modal');
        this.showAppBlocker();
    }

    showRegister() {
        this.isLoginMode = false;
        this.setupAuthModal();
        this.showModal('auth-modal');
        this.showAppBlocker();
    }

    toggleAuthMode() {
        this.isLoginMode = !this.isLoginMode;
        this.setupAuthModal();
    }

    setupAuthModal() {
        const nameGroup = document.getElementById('auth-name-group');
        const title = document.getElementById('auth-modal-title');
        const button = document.getElementById('auth-submit-button');
        const toggleText = document.getElementById('auth-toggle-text');
        const nameInput = document.getElementById('auth-name');

        if (this.isLoginMode) {
            if(nameGroup) nameGroup.style.display = 'none';
            if(title) title.innerHTML = '<i data-lucide="lock"></i> Login';
            if(button) button.textContent = 'Login';
            if(toggleText) toggleText.innerHTML = `Don't have an account? <a href="#" id="auth-toggle-link">Sign Up</a>`;
            if(nameInput) nameInput.required = false;
        } else {
            if(nameGroup) nameGroup.style.display = 'block';
            if(title) title.innerHTML = '<i data-lucide="user-plus"></i> Sign Up';
            if(button) button.textContent = 'Create Account';
            if(toggleText) toggleText.innerHTML = `Already have an account? <a href="#" id="auth-toggle-link">Login</a>`;
            if(nameInput) nameInput.required = true;
        }
        this.createIcons();
    }

    showAuthNotification(message, type) {
        const area = document.getElementById('auth-notification-area');
        if (area) {
            area.innerHTML = `<div class="notification-login ${type}">${message}</div>`;
        }
    }

    showAppBlocker() {
        const blocker = document.getElementById('app-blocker');
        if (blocker) blocker.style.display = 'block';
    }

    hideAppBlocker() {
        const blocker = document.getElementById('app-blocker');
        if (blocker) blocker.style.display = 'none';
    }

    showCustomDatePicker() {
        const picker = document.getElementById('custom-date-picker');
        if (picker) {
            picker.style.display = 'block';
        }
        console.log("showCustomDatePicker called");
    }

    hideCustomDatePicker() {
        const picker = document.getElementById('custom-date-picker');
        if (picker) {
            picker.style.display = 'none';
        }
        console.log("hideCustomDatePicker called");
    }

    setModalTitle(modalId, title) {
        const modal = document.getElementById(modalId);
        if (modal) {
            const titleElement = modal.querySelector('.modal-header h2');
            if (titleElement) titleElement.innerHTML = title;
        }
    }

    // === DRAG & DROP WIDGETS ===
    initDashboardDragAndDrop() {
        const grid = document.querySelector('.dashboard-widgets-grid');
        if (!grid) return;

        let draggedItem = null;

        grid.addEventListener('dragstart', e => {
            if (e.target.classList.contains('dashboard-widget')) {
                draggedItem = e.target;
                setTimeout(() => {
                    e.target.classList.add('dragging');
                }, 0);
            }
        });

        grid.addEventListener('dragend', e => {
            if (draggedItem) {
                setTimeout(() => {
                    draggedItem.classList.remove('dragging');
                    draggedItem = null;
                }, 0);
            }
        });

        grid.addEventListener('dragover', e => {
            e.preventDefault();
            const overElement = e.target.closest('.dashboard-widget');
            if (overElement && overElement !== draggedItem) {
                const allWidgets = [...grid.querySelectorAll('.dashboard-widget:not(.dragging)')];
                allWidgets.forEach(widget => widget.classList.remove('drag-over'));
                overElement.classList.add('drag-over');
            }
        });

        grid.addEventListener('dragleave', e => {
            const overElement = e.target.closest('.dashboard-widget');
            if (overElement) {
                overElement.classList.remove('drag-over');
            }
        });

        grid.addEventListener('drop', e => {
            e.preventDefault();
            const overElement = e.target.closest('.dashboard-widget');
            if (overElement && draggedItem) {
                // Simple swap logic
                const draggedIndex = Array.from(grid.children).indexOf(draggedItem);
                const targetIndex = Array.from(grid.children).indexOf(overElement);

                if (draggedIndex < targetIndex) {
                    grid.insertBefore(draggedItem, overElement.nextSibling);
                } else {
                    grid.insertBefore(draggedItem, overElement);
                }
            }
            document.querySelectorAll('.dashboard-widget').forEach(widget => widget.classList.remove('drag-over'));
        });
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎪 РОЗДІЛ: MODAL ВІКНА ТА POPUP                        █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ПОКАЗ MODAL ВІКНА
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            this.closeAllModals(); // Закрити всі інші модальні вікна
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
            this.modalStack.push(modalId);
            console.log('Modal opened:', modalId);
        }
    }

    // ЗАКРИТТЯ MODAL ВІКНА
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');

            // Видалити зі стеку
            this.modalStack = this.modalStack.filter(id => id !== modalId);

            // Перевірити чи є ще відкриті модальні вікна
            const openModals = document.querySelectorAll('.modal.show');
            if (openModals.length === 0) {
                document.body.style.overflow = '';
            }

            // Спеціальна логіка закриття для певних модальних вікон
            this.handleModalClose(modalId);
        }
    }

    // ЗАКРИТТЯ ВСІХ MODAL ВІКОН
    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('show');
        });
        document.body.style.overflow = '';
        this.modalStack = [];
    }

    // ОБРОБКА ЗАКРИТТЯ MODAL
    handleModalClose(modalId) {
        switch (modalId) {
            case 'add-trade-modal':
                if (this.app.tradeManager) this.app.tradeManager.resetTradeForm();
                break;
            case 'add-account-modal':
                const accountForm = document.getElementById('add-account-form');
                if (accountForm) accountForm.reset();
                break;
            case 'edit-account-modal':
                if (this.app.accountManager) this.app.accountManager.currentEditAccountId = null;
                break;
            case 'edit-trade-modal':
                if (this.app.tradeManager) {
                    this.app.tradeManager.currentEditTradeId = null;
                    this.app.tradeManager.currentEditSubtradeId = null;
                }
                break;
            case 'add-strategy-modal':
                if (this.app.strategyManager) this.app.strategyManager.resetStrategyForm();
                break;
            case 'entry-models-manager-modal':
                if (this.app.strategyManager) this.app.strategyManager.currentEditEntryModelId = null;
                break;
            case 'profile-settings-modal':
                this.resetEmailEditing();
                break;
        }
    }

    // СКИДАННЯ РЕДАГУВАННЯ EMAIL
    resetEmailEditing() {
        const emailInput = document.getElementById('profile-email');
        if (emailInput && !emailInput.hasAttribute('readonly')) {
            emailInput.setAttribute('readonly', true);
            const editBtn = emailInput.parentElement?.querySelector('.btn-secondary');
            if (editBtn) {
                editBtn.textContent = 'Edit';
                editBtn.onclick = () => this.app.editEmail();
            }
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📱 РОЗДІЛ: SIDEBAR ТА ОСНОВНИЙ КОНТЕНТ                █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ПЕРЕМИКАННЯ SIDEBAR
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebar && mainContent) {
            this.isSidebarCollapsed = !this.isSidebarCollapsed;
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('sidebar-collapsed');
        }
    }

    // ОНОВЛЕННЯ ВІДСТУПІВ ОСНОВНОГО КОНТЕНТУ
    updateMainContentMargin() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebar && mainContent) {
            if (this.isSidebarCollapsed) {
                mainContent.classList.add('sidebar-collapsed');
            } else {
                mainContent.classList.remove('sidebar-collapsed');
            }
        }
    }

    // ОНОВЛЕННЯ ПРОФІЛЮ В HEADER
    updateProfileDisplay(settings) {
        const profileName = document.querySelector('.profile-name');
        const profileEmail = document.querySelector('.profile-email');

        if (profileName) profileName.textContent = settings.name;
        if (profileEmail) profileEmail.textContent = settings.email;
    }

    // ПЕРЕМИКАННЯ МЕНЮ ПРОФІЛЮ
    toggleProfileMenu() {
        const dropdown = document.getElementById('profile-dropdown');
        const button = document.querySelector('.profile-btn');

        if (dropdown && button) {
            const isVisible = dropdown.classList.contains('show');

            if (isVisible) {
                this.closeProfileMenu();
            } else {
                this.openProfileMenu();
            }
        }
    }

    openProfileMenu() {
        const dropdown = document.getElementById('profile-dropdown');
        const button = document.querySelector('.profile-btn');

        if (dropdown && button) {
            dropdown.classList.add('show');
            button.classList.add('active');
        }
    }

    closeProfileMenu() {
        const dropdown = document.getElementById('profile-dropdown');
        const button = document.querySelector('.profile-btn');

        if (dropdown && button) {
            dropdown.classList.remove('show');
            button.classList.remove('active');
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎯 РОЗДІЛ: UI КОМПОНЕНТИ ТА ВІДЖЕТИ                  █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ОНОВЛЕННЯ ЕЛЕМЕНТУ
    updateElement(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = value;
        }
    }

    // ОНОВЛЕННЯ ЕЛЕМЕНТУ З КЛАСОМ
    updateElementWithClass(elementId, value, className) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = value;
            element.className = className;
        }
    }

    // ПОКАЗ СПОВІЩЕНЬ
    showNotification(message, type = 'info') {
        // Видалити існуючі сповіщення
        this.removeExistingNotifications();

        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i data-lucide="${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
            <button class="notification-close" onclick="this.parentElement.remove()">
                <i data-lucide="x"></i>
            </button>
        `;

        document.body.appendChild(notification);

        // Анімація появи
        setTimeout(() => notification.classList.add('show'), 100);

        // Автоматичне закриття
        setTimeout(() => {
            if (notification.parentElement) {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }
        }, 5000);

        // Ініціалізація іконок
        this.createIcons();
    }

    // ВИДАЛЕННЯ ІСНУЮЧИХ СПОВІЩЕНЬ
    removeExistingNotifications() {
        document.querySelectorAll('.notification').forEach(notification => {
            notification.remove();
        });
    }

    // ОТРИМАННЯ ІКОНКИ ДЛЯ СПОВІЩЕННЯ
    getNotificationIcon(type) {
        const icons = {
            'success': 'check-circle',
            'error': 'alert-circle',
            'warning': 'alert-triangle',
            'info': 'info'
        };
        return icons[type] || 'info';
    }

    // ПЕРЕМИКАННЯ THEME
    toggleTheme() {
        const themeSwitch = document.querySelector('.theme-switch');
        const themeLabel = document.getElementById('theme-label');
        const handleIcon = document.querySelector('.handle-icon');
        const currentTheme = document.documentElement.getAttribute('data-theme');

        if (currentTheme === 'light') {
            // Switch to dark mode
            document.documentElement.setAttribute('data-theme', 'dark');
            if (themeSwitch) themeSwitch.classList.add('active');
            if (themeLabel) themeLabel.textContent = 'Dark Mode';
            if (handleIcon) handleIcon.setAttribute('data-lucide', 'moon');
            this.app.saveThemeSetting('dark');
        } else {
            // Switch to light mode
            document.documentElement.setAttribute('data-theme', 'light');
            if (themeSwitch) themeSwitch.classList.remove('active');
            if (themeLabel) themeLabel.textContent = 'Light Mode';
            if (handleIcon) handleIcon.setAttribute('data-lucide', 'sun');
            this.app.saveThemeSetting('light');
        }

        this.createIcons();
    }

    // ЗАВАНТАЖЕННЯ THEME
    loadThemeSetting() {
        try {
            const savedTheme = localStorage.getItem('tradingAppTheme') || 'dark';
            document.documentElement.setAttribute('data-theme', savedTheme);

            const themeSwitch = document.querySelector('.theme-switch');
            const themeLabel = document.getElementById('theme-label');
            const handleIcon = document.querySelector('.handle-icon');

            if (savedTheme === 'dark') {
                if (themeSwitch) themeSwitch.classList.add('active');
                if (themeLabel) themeLabel.textContent = 'Dark Mode';
                if (handleIcon) handleIcon.setAttribute('data-lucide', 'moon');
            } else {
                if (themeSwitch) themeSwitch.classList.remove('active');
                if (themeLabel) themeLabel.textContent = 'Light Mode';
                if (handleIcon) handleIcon.setAttribute('data-lucide', 'sun');
            }

            this.createIcons();
        } catch (error) {
            console.error('Error loading theme setting:', error);
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🏷️ РОЗДІЛ: COLUMN VISIBILITY ТА TABLE MANAGEMENT      █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ПЕРЕМИКАННЯ COLUMN VISIBILITY
    toggleColumnVisibility() {
        const dropdown = document.getElementById('column-visibility-dropdown');
        const filtersDropdown = document.getElementById('filtersDropdown');

        if (dropdown) {
            const isVisible = dropdown.style.display === 'block';

            // Close filters dropdown if open
            if (filtersDropdown) {
                filtersDropdown.style.display = 'none';
            }

            dropdown.style.display = isVisible ? 'none' : 'block';

            // Populate column list when opening
            if (!isVisible) {
                this.populateColumnVisibilityList();
            }
        }
    }

    // ЗАПОВНЕННЯ COLUMN VISIBILITY LIST
    populateColumnVisibilityList() {
        const list = document.getElementById('column-visibility-list');
        if (!list) return;

        const columnLabels = {
            tradeNumber: 'Trade #',
            date: 'Date',
            pair: 'Pair',
            direction: 'Direction',
            result: 'Result',
            profitDollar: 'Profit $',
            profitPercent: 'Profit %',
            rr: 'RR',
            risk: 'Risk',
            strategy: 'Strategy',
            setup: 'Setup',
            session: 'Session',
            notes: 'Notes',
            account: 'Account'
        };

        list.innerHTML = Object.entries(columnLabels).map(([key, label]) => {
            const isChecked = this.app.columnVisibility[key];
            return `
                <div class="column-visibility-item" onclick="event.stopPropagation(); window.app.uiManager.toggleColumn('${key}')">
                    <div class="column-visibility-checkbox ${isChecked ? 'checked' : ''}">
                        <i data-lucide="check"></i>
                    </div>
                    <div class="column-visibility-label">${label}</div>
                </div>
            `;
        }).join('');

        this.createIcons();
    }

    // ПЕРЕМИКАННЯ КОЛОНКИ
    toggleColumn(columnKey) {
        this.app.columnVisibility[columnKey] = !this.app.columnVisibility[columnKey];
        this.app.saveColumnVisibility();
        this.populateColumnVisibilityList();
        this.app.updateAllTables();
        this.updateTableHeaders();
    }

    // ВИБІР УСІХ КОЛОНОК
    selectAllColumns() {
        Object.keys(this.app.columnVisibility).forEach(key => {
            this.app.columnVisibility[key] = true;
        });
        this.app.saveColumnVisibility();
        this.populateColumnVisibilityList();
        this.app.updateAllTables();
        this.updateTableHeaders();
    }

    // СКАСУВАННЯ ВИБОРУ УСІХ КОЛОНОК
    deselectAllColumns() {
        Object.keys(this.app.columnVisibility).forEach(key => {
            this.app.columnVisibility[key] = false;
        });
        this.app.saveColumnVisibility();
        this.populateColumnVisibilityList();
        this.app.updateAllTables();
        this.updateTableHeaders();
    }

    // ОНОВЛЕННЯ ЗАГОЛОВКІВ ТАБЛИЦІ
    updateTableHeaders() {
        const table = document.querySelector('.trades-table');
        if (!table) return;

        const thead = table.querySelector('thead tr');
        if (!thead) return;

        const headers = ['Trade #', 'Date', 'Pair', 'Direction', 'Result', 'Profit $', 'Profit %', 'RR', 'Risk (%)', 'Strategy', 'Setup', 'Session', 'Notes', 'Account'];
        const columnKeys = ['tradeNumber', 'date', 'pair', 'direction', 'result', 'profitDollar', 'profitPercent', 'rr', 'risk', 'strategy', 'setup', 'session', 'notes', 'account'];

        // Завантажити ширину колонок
        const savedWidths = this.app.loadColumnWidths();

        thead.innerHTML = headers.map((header, index) => {
            const key = columnKeys[index];
            const isVisible = this.app.columnVisibility[key];
            const width = savedWidths[key] || 'auto';
            const widthStyle = width !== 'auto' ? `width: ${width}px; min-width: ${width}px;` : '';

            return `<th data-column="${key}" style="display: ${isVisible ? 'table-cell' : 'none'}; ${widthStyle}">
                ${header}
                <div class="resize-handle"></div>
            </th>`;
        }).join('');

        // Ініціалізувати resize
        this.app.initColumnResize();
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🖼️ РОЗДІЛ: IMAGE ТА SCREENSHOT MANAGEMENT             █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ВІДКРИТТЯ ЗОБРАЖЕННЯ У ПОВНОМУ РОЗМІРІ
    openImageFullscreen(imageSrc) {
        const overlay = document.createElement('div');
        overlay.className = 'fullscreen-image-overlay';
        overlay.innerHTML = `
            <div class="fullscreen-image-container">
                <img src="${imageSrc}" alt="Screenshot">
                <button class="fullscreen-close" onclick="this.parentElement.parentElement.remove()">
                    <i data-lucide="x"></i>
                </button>
            </div>
        `;

        // Закриття при кліку на overlay
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });

        document.body.appendChild(overlay);
        this.createIcons();
    }

    // ОБРОБКА PASTE ДЛЯ ЗОБРАЖЕНЬ
    setupImagePasteListener() {
        document.addEventListener('paste', (e) => {
            // Перевіряємо чи відкрите якесь модальне вікно
            const openModal = document.querySelector('.modal.show');
            if (!openModal) return;

            const items = e.clipboardData?.items;
            if (!items) return;

            for (let item of items) {
                if (item.type.indexOf('image') !== -1) {
                    e.preventDefault();
                    const file = item.getAsFile();
                    if (file) {
                        this.handlePastedImage(file, openModal.id);
                    }
                }
            }
        });
    }

    // ОБРОБКА ВСТАВЛЕНОГО ЗОБРАЖЕННЯ
    handlePastedImage(file, modalId) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const imageSrc = e.target.result;

            switch (modalId) {
                case 'add-trade-modal':
                    this.addImageToPreview(imageSrc, 'screenshot-preview');
                    break;
                case 'edit-trade-modal':
                    this.addImageToPreview(imageSrc, 'edit-screenshot-preview');
                    break;
                case 'add-strategy-modal':
                    this.addImageToStrategyPreview(imageSrc);
                    break;
            }
        };
        reader.readAsDataURL(file);
    }

    // ДОДАВАННЯ ЗОБРАЖЕННЯ ДО PREVIEW
    addImageToPreview(imageSrc, previewId) {
        const preview = document.getElementById(previewId);
        if (!preview) return;

        const screenshotDiv = document.createElement('div');
        screenshotDiv.className = 'screenshot-item';
        screenshotDiv.innerHTML = `
            <img src="${imageSrc}" onclick="window.app.uiManager.openImageFullscreen('${imageSrc}')">
            <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
        `;
        preview.appendChild(screenshotDiv);
    }

    // ДОДАВАННЯ ЗОБРАЖЕННЯ ДО STRATEGY PREVIEW
    addImageToStrategyPreview(imageSrc) {
        // Знаходимо активну вкладку стратегії
        const activeTab = document.querySelector('.strategy-tab.active');
        if (!activeTab) return;

        const tabName = activeTab.dataset.tab;
        const imagesContainer = document.getElementById(`${tabName}-images`);
        if (!imagesContainer) return;

        const screenshotDiv = document.createElement('div');
        screenshotDiv.className = 'screenshot-item';
        screenshotDiv.innerHTML = `
            <img src="${imageSrc}" onclick="window.app.uiManager.openImageFullscreen('${imageSrc}')">
            <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
        `;
        imagesContainer.appendChild(screenshotDiv);
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🛠️ РОЗДІЛ: ДОПОМІЖНІ ФУНКЦІЇ                         █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ФОРМАТУВАННЯ ДАТИ
    formatDate(dateStr) {
        if (!dateStr) return 'Unknown';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // ФОРМАТУВАННЯ ДАТИ (КОРОТКИЙ ВАРІАНТ)
    formatDateShort(dateStr) {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric'
        });
    }

    // ІНІЦІАЛІЗАЦІЯ ICONS
    createIcons() {
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    // ПЕРЕВІРКА, ЧИ Є ЕЛЕМЕНТ У ВІДОБРАЖЕННІ
    isElementVisible(element) {
        if (!element) return false;
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    // ПЛАВНА ПРОКРУТКА ДО ЕЛЕМЕНТУ
    scrollToElement(elementId, offset = 100) {
        const element = document.getElementById(elementId);
        if (element) {
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - offset;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }
    }

    // ДОДАВАННЯ LOADING STATE
    setLoadingState(element, isLoading) {
        if (!element) return;

        if (isLoading) {
            element.classList.add('loading');
            element.disabled = true;
        } else {
            element.classList.remove('loading');
            element.disabled = false;
        }
    }

    // ОНОВЛЕННЯ PROGRESS BAR
    updateProgressBar(progressId, percentage) {
        const progressBar = document.getElementById(progressId);
        if (progressBar) {
            progressBar.style.width = `${Math.min(100, Math.max(0, percentage))}%`;
        }
    }
}

// Експорт для використання в інших модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIManager;
}