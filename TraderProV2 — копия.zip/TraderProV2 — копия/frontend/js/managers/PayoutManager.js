// ===============================================
// 💰 PAYOUT MANAGER - УПРАВЛІННЯ ВИПЛАТАМИ
// ===============================================

class PayoutManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.payouts = [];
        this.API_URL = 'http://localhost:3000/api';
        this.currentEditPayoutId = null;
    }

    // ┌───────────────────────────────────┐
    // │ 💾 ЗАВАНТАЖЕННЯ ТА ЗБЕРЕЖЕННЯ     │
    // └───────────────────────────────────┘
    async loadPayouts() {
        try {
            const response = await fetch(`${this.API_URL}/payouts`);
            if (!response.ok) throw new Error('Network response was not ok');
            this.payouts = await response.json();
            console.log('Loaded payouts from backend:', this.payouts.length);
        } catch (error) {
            console.error('Error loading payouts from backend:', error);
            this.app.showNotification('Could not load payouts from server', 'error');
            this.payouts = [];
        }
        this.updatePayoutsDisplay();
    }

    // ┌───────────────────────────────────┐
    // │ ⚙️ ОСНОВНІ ОПЕРАЦІЇ (CRUD)        │
    // └───────────────────────────────────┘
    async addPayout() {
        const date = document.getElementById('payout-date')?.value;
        const accountId = document.getElementById('payout-account')?.value;
        const amount = document.getElementById('payout-amount')?.value;
        const notes = document.getElementById('payout-notes')?.value || '';

        if (!date || !accountId || !amount) {
            this.app.showNotification('Please fill in all required fields (Date, Account, Amount)', 'error');
            return;
        }

        const account = this.app.accountManager.accounts.find(acc => acc.id === accountId);
        if (!account) {
            this.app.showNotification('Account not found', 'error');
            return;
        }

        const newPayout = {
            id: Date.now(),
            date: date,
            accountId: accountId,
            accountName: account.name,
            amount: parseFloat(amount),
            notes: notes,
            createdAt: new Date().toISOString()
        };

        try {
            if (this.currentEditPayoutId) {
                // РЕДАКТИРОВАНИЕ
                const response = await fetch(`${this.API_URL}/payouts/${this.currentEditPayoutId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(newPayout),
                });
                if (!response.ok) throw new Error('Failed to update payout');

                // Обновляем данные в локальном массиве
                const payoutIndex = this.payouts.findIndex(p => p.id === this.currentEditPayoutId);
                if (payoutIndex !== -1) {
                    this.payouts[payoutIndex] = { ...this.payouts[payoutIndex], ...newPayout, id: this.currentEditPayoutId };
                }
                this.app.showNotification('Payout updated successfully!', 'success');
                this.currentEditPayoutId = null;
            } else {
                // ДОБАВЛЕНИЕ
                const response = await fetch(`${this.API_URL}/payouts`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(newPayout),
                });

                if (!response.ok) throw new Error('Failed to add payout');

                const savedPayout = await response.json();
                this.payouts.push(savedPayout);
                this.app.showNotification('Payout added successfully!', 'success');
            }

            this.updatePayoutsDisplay();
            this.app.accountManager.updateAccountsDisplay();
            this.app.updateAllMetrics();
            this.app.uiManager.closeModal('add-payout-modal');
            this.resetPayoutForm();
        } catch (error) {
            console.error('Error adding payout:', error);
            this.app.showNotification('Error adding payout', 'error');
        }
    }

    editPayout(payoutId) {
        const payout = this.payouts.find(p => p.id === payoutId);
        if (!payout) {
            this.app.showNotification('Payout not found', 'error');
            return;
        }

        this.currentEditPayoutId = payoutId;

        document.getElementById('payout-date').value = payout.date;
        document.getElementById('payout-account').value = payout.accountId;
        document.getElementById('payout-amount').value = payout.amount;
        document.getElementById('payout-notes').value = payout.notes || '';

        this.app.uiManager.setModalTitle('add-payout-modal', '<i data-lucide="edit"></i> Edit Payout');
        this.app.uiManager.setModalButton('add-payout-modal', '<i data-lucide="save"></i> Save Changes');

        this.app.showAddPayoutModal();
    }

    async deletePayout(payoutId) {
        if (!confirm('Are you sure you want to delete this payout?')) return;

        try {
            const response = await fetch(`${this.API_URL}/payouts/${payoutId}`, {
                method: 'DELETE',
            });
            if (!response.ok) throw new Error('Failed to delete payout');

            this.payouts = this.payouts.filter(p => p.id !== payoutId);
            this.updatePayoutsDisplay();
            this.app.updateAllMetrics();
            this.app.showNotification('Payout deleted successfully!', 'success');
        } catch (error) {
            console.error('Error deleting payout:', error);
            this.app.showNotification('Error deleting payout', 'error');
        }
    }

    getPayoutsByAccount(accountId) {
        if (!this.payouts) {
            return [];
        }
        return this.payouts.filter(payout => payout.accountId === accountId);
    }

    // ┌───────────────────────────────────┐
    // │ 🎨 ВІДОБРАЖЕННЯ                   │
    // └───────────────────────────────────┘
    updatePayoutsDisplay() {
        this.populatePayoutsAccountSelect();
        this.renderPayoutsList();
        this.updatePayoutsSummary();
    }

    populatePayoutsAccountSelect() {
        const payoutAccountSelect = document.getElementById('payout-account');
        if (payoutAccountSelect) {
            payoutAccountSelect.innerHTML = '<option value="">Select Account</option>';
            this.app.accounts.forEach(account => {
                const statusDisplay = account.status || account.type;
                payoutAccountSelect.innerHTML += `<option value="${account.id}">${account.name} (${statusDisplay})</option>`;
            });
        }
    }

    renderPayoutsList() {
        const payoutsList = document.getElementById('payouts-list');
        if (!payoutsList) return;

        if (!this.payouts || this.payouts.length === 0) {
            payoutsList.innerHTML = `<div class="empty-payouts"><div class="empty-message"><i data-lucide="arrow-up-right"></i><p>No payouts yet</p><small>Add your first payout to get started</small></div></div>`;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        const sortedPayouts = [...this.payouts].sort((a, b) => new Date(b.date) - new Date(a.date));

        payoutsList.innerHTML = sortedPayouts.map(payout => `
            <div class="payout-item" onclick="window.app.payoutManager.editPayout('${payout.id}')" title="Click to edit payout">
                <div class="payout-item-content">
                    <div class="payout-item-left">
                        <div class="payout-account-name">${payout.accountName}</div>
                        <div class="payout-date">${this.app.formatDate(payout.date)}</div>
                    </div>
                    <div class="payout-item-right">
                        <div class="payout-amount">$${payout.amount.toFixed(2)}</div>
                        <button class="payout-delete-btn" onclick="event.stopPropagation(); window.app.payoutManager.deletePayout('${payout.id}')" title="Delete payout"><i data-lucide="x"></i></button>
                    </div>
                </div>
            </div>
        `).join('');

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    updatePayoutsSummary() {
        if (!this.payouts) return;

        const totalPayouts = this.payouts.reduce((sum, payout) => sum + payout.amount, 0);
        const totalPayoutsCount = this.payouts.length;
        const now = new Date();
        const monthPayouts = this.payouts.filter(p => new Date(p.date).getMonth() === now.getMonth() && new Date(p.date).getFullYear() === now.getFullYear()).reduce((sum, p) => sum + p.amount, 0);
        let lastPayoutDate = 'Never';
        if (this.payouts.length > 0) {
            const sorted = [...this.payouts].sort((a, b) => new Date(b.date) - new Date(a.date));
            lastPayoutDate = this.app.formatDate(sorted[0].date);
        }

        this.app.updateElement('total-payouts-count', totalPayoutsCount);
        this.app.updateElement('total-payouts-amount', `$${totalPayouts.toFixed(2)}`);
        this.app.updateElement('month-payouts-amount', `$${monthPayouts.toFixed(2)}`);
        this.app.updateElement('last-payout-date', lastPayoutDate);
    }

    resetPayoutForm() {
        const form = document.getElementById('add-payout-form');
        if (form) form.reset();
        this.app.uiManager.setModalTitle('add-payout-modal', '<i data-lucide="arrow-up-right"></i> Add New Payout');
        this.app.uiManager.setModalButton('add-payout-modal', '<i data-lucide="save"></i> Add Payout');
        this.currentEditPayoutId = null;
    }
}