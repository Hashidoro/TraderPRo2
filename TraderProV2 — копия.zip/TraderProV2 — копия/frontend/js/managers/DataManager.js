// ===============================================
// 💾 DATA MANAGER - ЦЕНТРАЛІЗОВАНЕ УПРАВЛІННЯ ДАНИМИ
// ===============================================

class DataManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.storageKey = 'tradingAppData';
        this.backupInterval = 24 * 60 * 60 * 1000; // 24 години
        this.lastBackupTime = null;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  💾 РОЗДІЛ: ОСНОВНІ МЕТОДИ ЗБЕРЕЖЕННЯ ДАНИХ            █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ЗБЕРЕЖЕННЯ ВСІХ ДАНИХ
    // DEPRECATED: Saving is now handled by individual managers via API calls.
    saveAllData() { return; }

    // ЗАВАНТАЖЕННЯ ВСІХ ДАНИХ
    async loadAllData() {
        console.log('Loading all data from backend...');
        await this.app.accountManager.loadAccounts();
        await this.app.tradeManager.loadTrades();
        await this.app.payoutManager.loadPayouts();
        await this.app.strategyManager.loadStrategies();
        await this.app.strategyManager.loadSetups();
        await this.app.strategyManager.loadEntryModels();
        console.log('All data loaded.');
    }

    // ІНІЦІАЛІЗАЦІЯ ДЕФОЛТНИХ ДАНИХ
    initializeDefaultData() {
        console.log('Initializing with default data');
        this.app.strategyManager.entryModels = this.app.strategyManager.getDefaultEntryModels();
        return true;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📦 РОЗДІЛ: ЕКСПОРТ ТА ІМПОРТ ДАНИХ                    █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ЕКСПОРТ ВСІХ ДАНИХ У JSON
    exportAllData() {
        try {
            const data = {
                version: '1.0.0',
                exportedAt: new Date().toISOString(),
                data: this.getAllDataForExport()
            };

            const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `trading-app-backup-${new Date().toISOString().split('T')[0]}.json`;
            link.click();
            URL.revokeObjectURL(url);

            this.app.showNotification('All data exported successfully!', 'success');
            return true;
        } catch (error) {
            console.error('Error exporting data:', error);
            this.app.showNotification('Error exporting data', 'error');
            return false;
        }
    }

    // ОТРИМАННЯ ВСІХ ДАНИХ ДЛЯ ЕКСПОРТУ
    getAllDataForExport() {
        return {
            trades: this.app.tradeManager?.trades || [],
            accounts: this.app.accountManager?.accounts || [],
            strategies: this.app.strategyManager?.strategies || [],
            setups: this.app.strategyManager?.setups || [],
            entryModels: this.app.strategyManager?.entryModels || [],
            payouts: this.app.payoutManager?.payouts || [],
            settings: this.getSettingsData(),
            statistics: this.getStatisticsData()
        };
    }

    // ІМПОРТ ДАНИХ З JSON ФАЙЛУ
    importDataFromFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (e) => {
                try {
                    const importedData = JSON.parse(e.target.result);
                    this.processImportedData(importedData);
                    resolve(true);
                } catch (error) {
                    console.error('Error parsing imported file:', error);
                    reject(new Error('Invalid file format'));
                }
            };

            reader.onerror = () => reject(new Error('Error reading file'));
            reader.readAsText(file);
        });
    }

    // ОБРОБКА ІМПОРТОВАНИХ ДАНИХ
    processImportedData(importedData) {
        if (!importedData.data) {
            throw new Error('Invalid data format');
        }

        const data = importedData.data;

        // Перевірка версії (для майбутніх оновлень)
        if (importedData.version && importedData.version !== '1.0.0') {
            console.warn('Importing data from different version:', importedData.version);
        }

        // Запит підтвердження для перезапису даних
        if (!confirm('This will replace all current data. Are you sure?')) {
            return;
        }

        // Імпорт основних даних
        if (data.trades) this.app.tradeManager.trades = data.trades;
        if (data.accounts) this.app.accountManager.accounts = data.accounts;
        if (data.strategies) this.app.strategyManager.strategies = data.strategies;
        if (data.setups) this.app.strategyManager.setups = data.setups;
        if (data.entryModels) this.app.strategyManager.entryModels = data.entryModels;
        if (data.payouts && this.app.payoutManager) {
            this.app.payoutManager.payouts = data.payouts;
        }

        // Імпорт налаштувань
        if (data.settings) {
            this.loadSettingsData(data.settings);
        }

        // Збереження всіх даних
        this.saveAllData();

        // Оновлення інтерфейсу
        this.app.updateAllMetrics();
        this.app.updateAllTables();
        this.app.uiManager?.loadThemeSetting();

        this.app.showNotification('Data imported successfully!', 'success');
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🗂️ РОЗДІЛ: РЕЗЕРВНЕ КОПІЮВАННЯ ТА ВІДНОВЛЕННЯ         █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // СТВОРЕННЯ АВТОМАТИЧНОГО БЕКАПУ
    createAutoBackup(data) {
        const now = new Date().getTime();
        this.lastBackupTime = this.lastBackupTime || now;

        // Перевірка чи пройшло достатньо часу для нового бекапу
        if (now - this.lastBackupTime < this.backupInterval) {
            return;
        }

        try {
            const backupKey = `tradingAppBackup_${new Date().toISOString().split('T')[0]}`;
            localStorage.setItem(backupKey, JSON.stringify(data));
            this.lastBackupTime = now;

            // Видалення старих бекапів (зберігаємо тільки останні 7)
            this.cleanupOldBackups();

            console.log('Auto-backup created:', backupKey);
        } catch (error) {
            console.error('Error creating auto-backup:', error);
        }
    }

    // ВИДАЛЕННЯ СТАРИХ БЕКАПІВ
    cleanupOldBackups() {
        const backups = [];
        const now = new Date().getTime();
        const maxBackupAge = 7 * 24 * 60 * 60 * 1000; // 7 днів

        // Знаходження всіх бекапів
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('tradingAppBackup_')) {
                backups.push(key);
            }
        }

        // Сортування за датою (новіші перші)
        backups.sort((a, b) => b.localeCompare(a));

        // Видалення старих бекапів
        backups.forEach((backup, index) => {
            if (index >= 7) { // Зберігаємо тільки 7 останніх
                localStorage.removeItem(backup);
                console.log('Removed old backup:', backup);
            }
        });
    }

    // ВІДНОВЛЕННЯ З БЕКАПУ
    restoreFromBackup(backupKey) {
        try {
            const backupData = localStorage.getItem(backupKey);
            if (!backupData) {
                throw new Error('Backup not found');
            }

            const data = JSON.parse(backupData);

            if (!confirm('This will replace all current data with backup. Are you sure?')) {
                return false;
            }

            this.loadCoreData(data);
            this.saveAllData();

            this.app.updateAllMetrics();
            this.app.updateAllTables();

            this.app.showNotification('Data restored from backup successfully!', 'success');
            return true;
        } catch (error) {
            console.error('Error restoring from backup:', error);
            this.app.showNotification('Error restoring backup', 'error');
            return false;
        }
    }

    // ОТРИМАННЯ СПИСКУ ДОСТУПНИХ БЕКАПІВ
    getAvailableBackups() {
        const backups = [];

        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && key.startsWith('tradingAppBackup_')) {
                const dateStr = key.replace('tradingAppBackup_', '');
                backups.push({
                    key: key,
                    date: new Date(dateStr),
                    dateString: new Date(dateStr).toLocaleDateString()
                });
            }
        }

        // Сортування за датою (новіші перші)
        return backups.sort((a, b) => b.date - a.date);
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🧹 РОЗДІЛ: ОЧИСТКА ТА ОПТИМІЗАЦІЯ ДАНИХ               █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ОЧИСТКА ВСІХ ДАНИХ
    clearAllData() {
        if (!confirm('This will permanently delete ALL data. Are you absolutely sure?')) {
            return false;
        }

        try {
            // Очищення основних даних
            this.app.tradeManager.trades = [];
            this.app.accountManager.accounts = [];
            this.app.strategyManager.strategies = [];
            this.app.strategyManager.setups = [];
            this.app.strategyManager.entryModels = this.app.strategyManager.getDefaultEntryModels();

            if (this.app.payoutManager) {
                this.app.payoutManager.payouts = [];
            }

            // Очищення налаштувань
            localStorage.removeItem('tradingAppTheme');
            localStorage.removeItem('tradingAppColumnVisibility');
            localStorage.removeItem('tradingAppFavoritePairs');
            localStorage.removeItem('tradingAppProfileSettings');
            localStorage.removeItem('dashboardWidgetOrder');
            localStorage.removeItem('tradingAppColumnWidths');
            localStorage.removeItem('tradingAppColumnOrder');

            // Очищення основного сховища
            localStorage.removeItem(this.storageKey);

            // Оновлення інтерфейсу
            this.app.updateAllMetrics();
            this.app.updateAllTables();
            this.app.uiManager?.loadThemeSetting();

            this.app.showNotification('All data cleared successfully!', 'success');
            return true;
        } catch (error) {
            console.error('Error clearing data:', error);
            this.app.showNotification('Error clearing data', 'error');
            return false;
        }
    }

    // ОПТИМІЗАЦІЯ ДАНИХ (ВИДАЛЕННЯ ДУБЛІКАТІВ ТОЩО)
    optimizeData() {
        let optimizedCount = 0;

        // Оптимізація трейдів (видалення дублікатів)
        const uniqueTrades = [];
        const tradeIds = new Set();

        this.app.tradeManager.trades.forEach(trade => {
            if (!tradeIds.has(trade.id)) {
                tradeIds.add(trade.id);
                uniqueTrades.push(trade);
            } else {
                optimizedCount++;
            }
        });

        this.app.tradeManager.trades = uniqueTrades;

        // Аналогічно для інших типів даних...

        if (optimizedCount > 0) {
            this.saveAllData();
            this.app.showNotification(`Data optimized. Removed ${optimizedCount} duplicates.`, 'success');
        } else {
            this.app.showNotification('No optimization needed.', 'info');
        }

        return optimizedCount;
    }

    // ПЕРЕВІРКА ЦІЛІСНОСТІ ДАНИХ
    validateDataIntegrity() {
        const errors = [];

        // Перевірка трейдів
        this.app.tradeManager.trades.forEach((trade, index) => {
            if (!trade.id) errors.push(`Trade at index ${index} missing ID`);
            if (!trade.symbol) errors.push(`Trade ${trade.id} missing symbol`);
            if (!trade.date && !trade.entryDate) errors.push(`Trade ${trade.id} missing date`);
        });

        // Перевірка акаунтів
        this.app.accountManager.accounts.forEach((account, index) => {
            if (!account.id) errors.push(`Account at index ${index} missing ID`);
            if (!account.name) errors.push(`Account ${account.id} missing name`);
            if (!account.startingBalance) errors.push(`Account ${account.id} missing starting balance`);
        });

        if (errors.length > 0) {
            console.warn('Data integrity issues found:', errors);
            return {
                isValid: false,
                errors: errors
            };
        }

        return {
            isValid: true,
            errors: []
        };
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📊 РОЗДІЛ: СТАТИСТИКА ТА АНАЛІТИКА ДАНИХ              █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ОТРИМАННЯ СТАТИСТИКИ СХОВИЩА
    getStorageStatistics() {
        const allData = this.getAllDataForExport();
        const dataSize = new Blob([JSON.stringify(allData)]).size;

        return {
            totalTrades: allData.trades.length,
            totalAccounts: allData.accounts.length,
            totalStrategies: allData.strategies.length,
            totalSetups: allData.setups.length,
            totalEntryModels: allData.entryModels.length,
            totalPayouts: allData.payouts.length,
            dataSize: this.formatBytes(dataSize),
            lastBackup: this.lastBackupTime ? new Date(this.lastBackupTime).toLocaleString() : 'Never',
            availableBackups: this.getAvailableBackups().length
        };
    }

    // ФОРМАТУВАННЯ РОЗМІРУ В БАЙТАХ
    formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    // ЕКСПОРТ СТАТИСТИКИ У CSV
    exportStatistics() {
        const stats = this.getStorageStatistics();
        const headers = ['Metric', 'Value'];
        const data = Object.entries(stats).map(([key, value]) => [
            key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()),
            value
        ]);

        const csvContent = [
            headers.join(','),
            ...data.map(row => row.join(','))
        ].join('\n');

        const blob = new Blob([csvContent], {type: 'text/csv'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `trading-app-statistics-${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
        URL.revokeObjectURL(url);

        this.app.showNotification('Statistics exported successfully!', 'success');
    }
}

// Експорт для використання в інших модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataManager;
}