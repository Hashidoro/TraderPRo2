// ===============================================
// 📊 TRADE MANAGER - УПРАВЛІННЯ ТРЕЙДАМИ
// ===============================================

class TradeManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.trades = [];
        this.API_URL = 'http://localhost:3000/api';
        this.currentEditTradeId = null;
        this.currentEditSubtradeId = null;
        this.tradePanelMode = null;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📥 РОЗДІЛ: ЗАВАНТАЖЕННЯ ТА ЗБЕРЕЖЕННЯ ДАНИХ           █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    async loadTrades() {
        try {
            const response = await fetch(`${this.API_URL}/trades`);
            if (!response.ok) throw new Error('Network response was not ok for trades');
            this.trades = await response.json();
            console.log('Loaded trades from backend:', this.trades.length);
        } catch (error) {
            console.error('Error loading trades from backend:', error);
            this.app.showNotification('Could not load trades from server', 'error');
            this.trades = [];
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  ➕ РОЗДІЛ: ДОДАВАННЯ ТА РЕДАГУВАННЯ ТРЕЙДІВ           █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ГЕНЕРАЦІЯ ID ДЛЯ ТРЕЙДУ
    generateTradeId() {
        return 'trade-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    }

    // ОТРИМАННЯ НАСТУПНОГО НОМЕРУ ТРЕЙДУ
    getNextTradeNumber() {
        const maxTradeNumber = this.trades.reduce((max, trade) => {
            return Math.max(max, trade.tradeNumber || 0);
        }, 0);
        return maxTradeNumber + 1;
    }

    // ДОДАВАННЯ НОВОГО ТРЕЙДУ
    async saveTrade(tradeData) {
        const isEditing = !!this.currentEditTradeId;
        const url = isEditing ? `${this.API_URL}/trades/${this.currentEditTradeId}` : `${this.API_URL}/trades`;
        const method = isEditing ? 'PUT' : 'POST';

        if (!isEditing) {
            tradeData.tradeNumber = this.getNextTradeNumber();
            tradeData.createdAt = new Date().toISOString();
        }

        try {
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(tradeData),
            });

            if (!response.ok) throw new Error(`Failed to ${isEditing ? 'update' : 'add'} trade`);

            if (isEditing) {
                const index = this.trades.findIndex(t => t.id === this.currentEditTradeId);
                if (index !== -1) {
                    this.trades[index] = { ...this.trades[index], ...tradeData, id: this.currentEditTradeId };
                }
                this.app.showNotification('Trade updated successfully!', 'success');
                this.currentEditTradeId = null;
            } else {
                const savedTrade = await response.json();
                this.trades.push(savedTrade);
                this.app.showNotification('Trade added successfully!', 'success');
            }

            this.app.updateAllMetrics();
            this.app.updateAllTables();
            this.app.chartManager?.updateCharts();
            this.app.calendarManager?.renderCalendar();
            this.app.uiManager.closeModal('add-trade-modal');

        } catch (error) {
            console.error('Error saving trade:', error);
            this.app.showNotification('Error saving trade', 'error');
        }
    }

    resetTradeForm() {
        const form = document.getElementById('add-trade-form');
        if (form) form.reset();
    }

    // РЕДАГУВАННЯ ТРЕЙДУ
    // Логика редактирования теперь внутри saveTrade

    // ВИДАЛЕННЯ ТРЕЙДУ
    async deleteTrade(tradeId) {
        if (!confirm('Are you sure you want to delete this trade?')) return;

        try {
            const response = await fetch(`${this.API_URL}/trades/${tradeId}`, {
                method: 'DELETE',
            });

            if (!response.ok) throw new Error('Failed to delete trade');

            this.trades = this.trades.filter(t => t.id !== tradeId);

            this.app.updateAllMetrics();
            this.app.updateAllTables();
            this.app.chartManager?.updateCharts();
            this.app.calendarManager?.renderCalendar();
            this.app.showNotification('Trade deleted successfully!', 'success');
        } catch (error) {
            console.error('Error deleting trade:', error);
            this.app.showNotification('Error deleting trade', 'error');
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🔍 РОЗДІЛ: ПОШУК ТА ФІЛЬТРАЦІЯ ТРЕЙДІВ                █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ОТРИМАННЯ ВІДФІЛЬТРОВАНИХ ТРЕЙДІВ
    getFilteredTrades() {
        let filteredTrades = [...this.trades];

        // Фільтрація по акаунтах
        const selectedAccountIds = this.app.getSelectedAccountIds();
        if (selectedAccountIds && selectedAccountIds.length > 0) {
            filteredTrades = filteredTrades.filter(trade =>
                selectedAccountIds.includes(trade.accountId)
            );
        }

        // Фільтрація по часу
        filteredTrades = this.filterTradesByTimePeriod(filteredTrades);

        return filteredTrades;
    }

    // ФІЛЬТРАЦІЯ ПО ПЕРІОДУ ЧАСУ
    filterTradesByTimePeriod(trades) {
        const period = this.app.globalTimePeriod;
        const now = new Date();

        switch (period) {
            case '1d':
                const today = now.toISOString().split('T')[0];
                return trades.filter(trade =>
                    trade.date === today || trade.entryDate === today
                );

            case '1w':
                const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                return trades.filter(trade => {
                    const tradeDate = new Date(trade.date || trade.entryDate);
                    return tradeDate >= oneWeekAgo;
                });

            case '1m':
                const oneMonthAgo = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
                return trades.filter(trade => {
                    const tradeDate = new Date(trade.date || trade.entryDate);
                    return tradeDate >= oneMonthAgo;
                });

            case 'custom':
                if (this.app.customDateRange.from && this.app.customDateRange.to) {
                    const fromDate = new Date(this.app.customDateRange.from);
                    const toDate = new Date(this.app.customDateRange.to);
                    return trades.filter(trade => {
                        const tradeDate = new Date(trade.date || trade.entryDate);
                        return tradeDate >= fromDate && tradeDate <= toDate;
                    });
                }
                return trades;

            default: // 'all'
                return trades;
        }
    }

    // ПОШУК ТРЕЙДУ ПО ID
    findTradeById(tradeId) {
        return this.trades.find(trade => trade.id === tradeId);
    }

    // ОТРИМАННЯ ТРЕЙДІВ ЗА ПЕРІОД
    getTradesByDateRange(startDate, endDate) {
        return this.trades.filter(trade => {
            const tradeDate = new Date(trade.date || trade.entryDate);
            return tradeDate >= startDate && tradeDate <= endDate;
        });
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📊 РОЗДІЛ: СТАТИСТИКА ТА АНАЛІТИКА ТРЕЙДІВ            █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // РОЗРАХУНОК СТАТИСТИКИ ТРЕЙДІВ
    calculateTradeStats(trades = null) {
        const tradesToAnalyze = trades || this.getFilteredTrades();

        if (tradesToAnalyze.length === 0) {
            return this.getEmptyStats();
        }

        const stats = {
            totalTrades: tradesToAnalyze.length,
            totalPnl: 0,
            winCount: 0,
            lossCount: 0,
            beCount: 0,
            winRate: 0,
            avgRiskReward: 0,
            maxDrawdown: 0
        };

        // Базові розрахунки
        tradesToAnalyze.forEach(trade => {
            const pnl = trade.pnl || 0;
            stats.totalPnl += pnl;

            // Підрахунок результатів
            const result = trade.result?.toLowerCase();
            if (result === 'win' || result === 'winner') {
                stats.winCount++;
            } else if (result === 'loss' || result === 'lose' || result === 'loser') {
                stats.lossCount++;
            } else if (result === 'be' || result === 'breakeven') {
                stats.beCount++;
            }

            // Risk/Reward
            const rr = trade.riskReward || 0;
            stats.avgRiskReward += rr;
        });

        // Win Rate (без BE трейдів)
        const tradesForWinRate = stats.winCount + stats.lossCount;
        stats.winRate = tradesForWinRate > 0 ? (stats.winCount / tradesForWinRate) * 100 : 0;

        // Середній Risk/Reward
        stats.avgRiskReward = stats.totalTrades > 0 ? stats.avgRiskReward / stats.totalTrades : 0;

        // Максимальне просідання
        stats.maxDrawdown = this.calculateMaxDrawdown(tradesToAnalyze);

        return stats;
    }

    // РОЗРАХУНОК МАКСИМАЛЬНОГО ПРОСІДАННЯ
    calculateMaxDrawdown(trades) {
        if (trades.length === 0) return 0;

        const startingBalance = this.app.accounts.reduce((sum, acc) => sum + (acc.startingBalance || 0), 0) || 10000;
        let peak = startingBalance;
        let running = startingBalance;
        let maxDrawdown = 0;

        const sortedTrades = trades.sort((a, b) => {
            const dateA = new Date(a.date || a.entryDate);
            const dateB = new Date(b.date || b.entryDate);
            return dateA.getTime() - dateB.getTime();
        });

        sortedTrades.forEach(trade => {
            const tradePnl = trade.pnl || 0;
            running += tradePnl;

            if (running > peak) peak = running;

            const drawdown = peak > 0 ? ((peak - running) / peak) * 100 : 0;
            if (drawdown > maxDrawdown) maxDrawdown = drawdown;
        });

        return maxDrawdown;
    }

    // ПОРОЖНЯ СТАТИСТИКА
    getEmptyStats() {
        return {
            totalTrades: 0,
            totalPnl: 0,
            winCount: 0,
            lossCount: 0,
            beCount: 0,
            winRate: 0,
            avgRiskReward: 0,
            maxDrawdown: 0
        };
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎯 РОЗДІЛ: SUBTRADES (СУБТРЕЙДИ)                      █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ДОДАВАННЯ SUBTRADE
    addSubtrade(parentTradeId) {
        const parentTrade = this.findTradeById(parentTradeId);
        if (!parentTrade) {
            this.app.showNotification('Parent trade not found', 'error');
            return null;
        }

        // Створення субтрейду
        const subtrade = {
            id: this.generateTradeId(),
            parentTradeId: parentTradeId,
            tradeNumber: this.getNextSubtradeNumber(parentTradeId),
            ...this.inheritParentTradeData(parentTrade),
            createdAt: new Date().toISOString()
        };

        this.trades.push(subtrade);
        this.saveTrades();

        this.app.updateAllMetrics();
        this.app.updateAllTables();

        this.app.showNotification('Subtrade added successfully!', 'success');
        return subtrade;
    }

    // УСПАДКУВАННЯ ДАНИХ ВІД БАТЬКІВСЬКОГО ТРЕЙДУ
    inheritParentTradeData(parentTrade) {
        return {
            entryDate: parentTrade.entryDate,
            exitDate: parentTrade.exitDate || parentTrade.entryDate,
            symbol: parentTrade.symbol,
            direction: parentTrade.direction,
            strategy: parentTrade.strategy,
            entryTimeframes: parentTrade.entryTimeframes,
            result: 'Win',
            accountId: parentTrade.accountId,
            risk: 1,
            pnl: 0,
            riskReward: 0,
            notes: '',
            screenshot: null
        };
    }

    // ОТРИМАННЯ НОМЕРУ SUBTRADE
    getNextSubtradeNumber(parentTradeId) {
        const existingSubtrades = this.trades.filter(t => t.parentTradeId === parentTradeId);
        return existingSubtrades.length + 1;
    }

    // ВИДАЛЕННЯ SUBTRADE
    deleteSubtrade(subtradeId) {
        const initialLength = this.trades.length;
        this.trades = this.trades.filter(t => t.id !== subtradeId);

        if (this.trades.length < initialLength) {
            this.saveTrades();
            this.app.updateAllMetrics();
            this.app.updateAllTables();
            this.app.showNotification('Subtrade deleted successfully!', 'success');
            return true;
        }

        this.app.showNotification('Subtrade not found', 'error');
        return false;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🖼️ РОЗДІЛ: УПРАВЛІННЯ СКРІНШОТАМИ ТРЕЙДІВ            █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ОБРОБКА СКРІНШОТУ ДЛЯ ТРЕЙДУ
    handleTradeScreenshot(file, tradeId = null) {
        return new Promise((resolve, reject) => {
            if (!file || !file.type.startsWith('image/')) {
                reject(new Error('Invalid file type'));
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const screenshotData = e.target.result;

                if (tradeId) {
                    // Додавання скріншоту до існуючого трейду
                    this.addScreenshotToTrade(tradeId, screenshotData);
                }

                resolve(screenshotData);
            };

            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsDataURL(file);
        });
    }

    // ДОДАВАННЯ СКРІНШОТУ ДО ТРЕЙДУ
    addScreenshotToTrade(tradeId, screenshotData) {
        const trade = this.findTradeById(tradeId);
        if (trade) {
            if (!trade.screenshots) {
                trade.screenshots = [];
            }
            trade.screenshots.push(screenshotData);
            trade.screenshot = screenshotData; // Для зворотної сумісності

            this.saveTrades();
            this.app.showNotification('Screenshot added to trade', 'success');
        }
    }

    // ВІДКРИТТЯ СКРІНШОТУ У ПОВНОМУ РОЗМІРІ
    openScreenshotFullscreen(screenshotSrc) {
        const overlay = document.createElement('div');
        overlay.className = 'fullscreen-screenshot-overlay';
        overlay.innerHTML = `
            <div class="fullscreen-screenshot-container">
                <img src="${screenshotSrc}" alt="Trade screenshot">
                <button class="fullscreen-close" onclick="this.parentElement.parentElement.remove()">
                    <i data-lucide="x"></i>
                </button>
            </div>
        `;

        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });

        document.body.appendChild(overlay);

        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎨 РОЗДІЛ: ФОРМАТУВАННЯ ТА ВІДОБРАЖЕННЯ ДАНИХ        █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ФОРМАТУВАННЯ ДАТИ ДЛЯ ВІДОБРАЖЕННЯ
    formatTradeDate(dateStr) {
        if (!dateStr) return 'Unknown';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // ФОРМАТУВАННЯ ДАТИ (КОРОТКИЙ ВАРІАНТ)
    formatDateShort(dateStr) {
        if (!dateStr) return '-';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric'
        });
    }

    // ВІДОБРАЖЕННЯ ВАЛЮТНОЇ ПАРИ З ПРАПОРАМИ
    renderCurrencyPairWithFlags(symbol) {
        if (!symbol) return '<span>-</span>';

        const symbolUpper = symbol.toUpperCase();

        // Спеціальні символи (індекси, товари, крипта)
        const specialSymbols = {
            'GER40': 'ger', 'GER30': 'ger', 'US30': 'us3', 'SPX500': 'spx',
            'NAS100': 'nas', 'UK100': 'uk1', 'FRA40': 'fra', 'JPN225': 'jpn',
            'XAUUSD': 'xau|usd', 'XAGUSD': 'xag|usd', 'BTCUSD': 'btc|usd'
        };

        if (specialSymbols[symbolUpper]) {
            const parts = specialSymbols[symbolUpper].split('|');
            if (parts.length === 1) {
                return `
                    <div class="currency-pair-flags">
                        <div class="currency-flag ${parts[0]}"></div>
                        <span class="currency-pair-symbol">${symbolUpper}</span>
                    </div>
                `;
            } else {
                return `
                    <div class="currency-pair-flags">
                        <div class="currency-flag ${parts[0]}"></div>
                        <div class="currency-flag ${parts[1]}"></div>
                        <span class="currency-pair-symbol">${symbolUpper}</span>
                    </div>
                `;
            }
        }

        // Звичайні Forex пари
        if (symbolUpper.length >= 6) {
            const baseCurrency = symbolUpper.substring(0, 3).toLowerCase();
            const quoteCurrency = symbolUpper.substring(3, 6).toLowerCase();

            return `
                <div class="currency-pair-flags">
                    <div class="currency-flag ${baseCurrency}"></div>
                    <div class="currency-flag ${quoteCurrency}"></div>
                    <span class="currency-pair-symbol">${symbolUpper}</span>
                </div>
            `;
        }

        // Резервний варіант
        return `
            <div class="currency-pair-flags">
                <span class="currency-pair-symbol">${symbolUpper}</span>
            </div>
        `;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🔧 РОЗДІЛ: УТІЛІТИ ТА ДОПОМІЖНІ ФУНКЦІЇ               █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ПЕРЕВІРКА ВАЛІДНОСТІ ДАНИХ ТРЕЙДУ
    validateTradeData(tradeData) {
        const requiredFields = ['symbol', 'direction', 'strategy', 'result', 'entryDate', 'pnl', 'risk'];
        const missingFields = requiredFields.filter(field => !tradeData[field]);

        if (missingFields.length > 0) {
            throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
        }

        if (isNaN(tradeData.pnl) || isNaN(tradeData.risk)) {
            throw new Error('PNL and Risk must be valid numbers');
        }

        return true;
    }

    // ЕКСПОРТ ТРЕЙДІВ У CSV
    exportTradesToCSV() {
        const headers = ['Date', 'Symbol', 'Direction', 'Result', 'PNL', 'Risk', 'RR', 'Strategy', 'Account'];
        const csvData = this.trades.map(trade => [
            trade.date || trade.entryDate,
            trade.symbol,
            trade.direction,
            trade.result,
            trade.pnl,
            trade.risk,
            trade.riskReward,
            trade.strategy,
            this.app.accountManager?.getAccountName(trade.accountId) || 'Unknown'
        ]);

        const csvContent = [
            headers.join(','),
            ...csvData.map(row => row.join(','))
        ].join('\n');

        const blob = new Blob([csvContent], {type: 'text/csv'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `trades-export-${new Date().toISOString().split('T')[0]}.csv`;
        link.click();

        URL.revokeObjectURL(url);
        this.app.showNotification('Trades exported to CSV successfully!', 'success');
    }

    // ІМПОРТ ТРЕЙДІВ З CSV
    importTradesFromCSV(file) {
        // TODO: Реалізація імпорту з CSV
        this.app.showNotification('CSV import functionality coming soon!', 'info');
    }

    // ОЧИСТКА ВСІХ ТРЕЙДІВ
    clearAllTrades() {
        if (confirm('Are you sure you want to delete ALL trades? This action cannot be undone.')) {
            this.trades = [];
            this.saveTrades();
            this.app.updateAllMetrics();
            this.app.updateAllTables();
            this.app.showNotification('All trades cleared successfully!', 'success');
        }
    }
}

// Експорт для використання в інших модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TradeManager;
}