// ===============================================
// 📅 CALENDAR MANAGER - УПРАВЛІННЯ КАЛЕНДАРЕМ
// ===============================================

class CalendarManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.currentDate = new Date(); // Для основного календаря
        this.currentCalendarViewDate = new Date(); // Для розділу календаря
    }

    // ┌───────────────────────────────────┐
    // │ 🗓️ ОСНОВНИЙ КАЛЕНДАР (DASHBOARD)  │
    // └───────────────────────────────────┘
    renderCalendar() {
        const grid = document.getElementById('interactive-calendar-days');
        if (!grid) return;

        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();

        const monthTitle = document.getElementById('calendar-current-month');
        if (monthTitle) {
            monthTitle.textContent = new Date(year, month).toLocaleDateString('en-US', {
                month: 'long',
                year: 'numeric'
            });
        }

        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        let startingDayOfWeek = firstDay.getDay();
        if (startingDayOfWeek === 0) startingDayOfWeek = 7; // Sunday is 0, make it 7
        startingDayOfWeek--; // Monday is now 0

        grid.innerHTML = '';

        for (let i = 0; i < startingDayOfWeek; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day empty';
            grid.appendChild(emptyDay);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';

            const dateStr = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            const dayTrades = this.app.tradeManager.trades.filter(trade => (trade.entryDate === dateStr));
            const dayPnl = dayTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

            const today = new Date();
            if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
                dayElement.classList.add('today');
            }

            if (dayTrades.length > 0) {
                dayElement.classList.add(dayPnl >= 0 ? 'has-trades' : 'has-losses');
            }

            let pnlHtml = '';
            if (dayPnl !== 0) {
                pnlHtml = `<div class="calendar-day-pnl ${dayPnl >= 0 ? 'positive' : 'negative'}">${dayPnl >= 0 ? '+' : ''}$${dayPnl.toFixed(0)}</div>`;
            }

            dayElement.innerHTML = `<div class="calendar-day-number">${day}</div>${pnlHtml}`;
            grid.appendChild(dayElement);
        }
    }

    previousMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.renderCalendar();
    }

    nextMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.renderCalendar();
    }

    // ┌───────────────────────────────────┐
    // │ 📅 РОЗДІЛ "КАЛЕНДАР"              │
    // └───────────────────────────────────┘
    initCalendarSection() {
        this.currentCalendarViewDate = new Date();
        this.setupCalendarNavigation();
        this.renderCalendarView();
    }

    setupCalendarNavigation() {
        const prevBtn = document.getElementById('prevMonth');
        const nextBtn = document.getElementById('nextMonth');

        if (prevBtn && !prevBtn.hasAttribute('data-calendar-setup')) {
            prevBtn.setAttribute('data-calendar-setup', 'true');
            prevBtn.addEventListener('click', () => {
                this.currentCalendarViewDate.setMonth(this.currentCalendarViewDate.getMonth() - 1);
                this.renderCalendarView();
            });
        }

        if (nextBtn && !nextBtn.hasAttribute('data-calendar-setup')) {
            nextBtn.setAttribute('data-calendar-setup', 'true');
            nextBtn.addEventListener('click', () => {
                this.currentCalendarViewDate.setMonth(this.currentCalendarViewDate.getMonth() + 1);
                this.renderCalendarView();
            });
        }
    }

    renderCalendarView() {
        this.renderCalendarMonth();
        this.renderCalendarGrid();
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    renderCalendarMonth() {
        const monthDisplay = document.getElementById('currentMonthDisplay');
        if (monthDisplay) {
            monthDisplay.textContent = this.currentCalendarViewDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        }
    }

    renderCalendarGrid() {
        const grid = document.getElementById('calendarGridView');
        if (!grid) return;

        const year = this.currentCalendarViewDate.getFullYear();
        const month = this.currentCalendarViewDate.getMonth();
        const firstDay = new Date(year, month, 1);
        let startDay = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1;
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        grid.innerHTML = '';

        for (let i = 0; i < startDay; i++) {
            grid.appendChild(this.createDayCell(0, true, false));
        }

        const today = new Date();
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month, day);
            const isToday = date.toDateString() === today.toDateString();
            grid.appendChild(this.createDayCell(day, false, isToday, date));
        }
    }

    createDayCell(day, isOtherMonth, isToday, date = null) {
        // ... (ця функція залишається майже без змін, але тепер вона частина менеджера)
        const cell = document.createElement('div');
        cell.className = `calendar-day-cell ${isOtherMonth ? 'other-month' : ''} ${isToday ? 'today' : ''}`;
        cell.innerHTML = `<div class="day-number">${day || ''}</div>`;
        // ... логіка додавання PnL
        return cell;
    }
}