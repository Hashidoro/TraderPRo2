// ===============================================
// 📋 STRATEGY MANAGER - УПРАВЛІННЯ СТРАТЕГІЯМИ ТА SETUPS
// ===============================================

class StrategyManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.strategies = [];
        this.API_URL = 'http://localhost:3000/api';
        this.setups = [];
        this.entryModels = [];
        this.currentEditStrategyId = null;
        this.currentEditSetupId = null;
        this.currentEditEntryModelId = null;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📥 РОЗДІЛ: ЗАВАНТАЖЕННЯ ТА ЗБЕРЕЖЕННЯ ДАНИХ           █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // СТРАТЕГІЇ
    async loadStrategies() {
        try {
            const response = await fetch(`${this.API_URL}/strategies`);
            if (!response.ok) throw new Error('Network response was not ok for strategies');
            this.strategies = await response.json();
            console.log('Loaded strategies from backend:', this.strategies.length);
        } catch (error) {
            console.error('Error loading strategies from backend:', error);
            this.app.showNotification('Could not load strategies from server', 'error');
            this.strategies = [];
        }
    } 

    // SETUPS
    async loadSetups() {
        try {
            const response = await fetch(`${this.API_URL}/setups`);
            if (!response.ok) throw new Error('Network response was not ok for setups');
            this.setups = await response.json();
            console.log('Loaded setups from backend:', this.setups.length);
        } catch (error) {
            console.error('Error loading setups from backend:', error);
            this.app.showNotification('Could not load setups from server', 'error');
            this.setups = [];
        } finally {
            this.updateDisplay(); // Используем общий метод обновления
        }
    }

    // ENTRY MODELS
    async loadEntryModels() {
        try {
            const response = await fetch(`${this.API_URL}/entry-models`);
            if (!response.ok) throw new Error('Network response was not ok for entry models');
            this.entryModels = await response.json();
            if (this.entryModels.length === 0) {
                // If backend is empty, populate with defaults
                this.entryModels = this.getDefaultEntryModels();
                // Optionally, save these defaults to the backend now
            }
            console.log('Loaded entry models from backend:', this.entryModels.length);
        } catch (error) {
            console.error('Error loading entry models from backend:', error);
            this.app.showNotification('Could not load entry models from server', 'error');
            this.entryModels = this.getDefaultEntryModels();
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎯 РОЗДІЛ: УПРАВЛІННЯ СТРАТЕГІЯМИ                     █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ДОДАВАННЯ НОВОЇ СТРАТЕГІЇ
    async addStrategy(strategyData) {
        if (!strategyData.name || !strategyData.type) {
            this.app.showNotification('Please fill in strategy name and type', 'error');
            return null;
        }

        // If we are in edit mode, update instead of adding
        if (this.currentEditStrategyId) {
            await this.updateStrategy(this.currentEditStrategyId, strategyData);
            return;
        }

        strategyData.createdAt = new Date().toISOString();

        try {
            const response = await fetch(`${this.API_URL}/strategies`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(strategyData),
            });
            if (!response.ok) throw new Error('Failed to add strategy');

            const savedStrategy = await response.json();
            this.strategies.push(savedStrategy);

            this.updateDisplay();
            this.app.closeModal('add-strategy-modal');
            this.app.showNotification('Strategy added successfully!', 'success');
        } catch (error) {
            console.error('Error adding strategy:', error);
            this.app.showNotification('Error adding strategy', 'error');
        }
    }

    // РЕДАГУВАННЯ СТРАТЕГІЇ
    async updateStrategy(strategyId, updatedData) {
        try {
            const response = await fetch(`${this.API_URL}/strategies/${strategyId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedData),
            });
            if (!response.ok) throw new Error('Failed to update strategy');

            const strategyIndex = this.strategies.findIndex(s => s.id === strategyId);
            if (strategyIndex !== -1) {
                this.strategies[strategyIndex] = { ...this.strategies[strategyIndex], ...updatedData, id: strategyId };
            }

            this.currentEditStrategyId = null; // Reset edit mode
            this.updateDisplay();
            this.app.closeModal('add-strategy-modal');
            this.app.showNotification('Strategy updated successfully!', 'success');
        } catch (error) {
            console.error('Error updating strategy:', error);
            this.app.showNotification('Error updating strategy', 'error');
        }
    }

    // ВИДАЛЕННЯ СТРАТЕГІЇ
    async deleteStrategy(strategyId) {
        if (!confirm('Are you sure you want to delete this strategy?')) return;

        try {
            const response = await fetch(`${this.API_URL}/strategies/${strategyId}`, {
                method: 'DELETE',
            });
            if (!response.ok) throw new Error('Failed to delete strategy');

            this.strategies = this.strategies.filter(s => s.id !== strategyId);
            this.updateDisplay();
            this.app.showNotification('Strategy deleted successfully!', 'success');
        } catch (error) {
            console.error('Error deleting strategy:', error);
            this.app.showNotification('Error deleting strategy', 'error');
        }
    }

    // ПОШУК СТРАТЕГІЇ ПО ID
    findStrategyById(strategyId) {
        return this.strategies.find(s => s.id === strategyId);
    }

    // ПОШУК СТРАТЕГІЇ ПО НАЗВІ
    findStrategyByName(strategyName) {
        return this.strategies.find(s => s.name === strategyName);
    }

    resetStrategyForm() {
        const form = document.getElementById('add-strategy-form');
        if (form) form.reset();
    }

    // ОНОВЛЕННЯ ДАТИ ВИКОРИСТАННЯ СТРАТЕГІЇ
    updateStrategyLastUsed(strategyName) {
        const strategy = this.findStrategyByName(strategyName);
        if (strategy) {
            strategy.lastUsed = new Date().toISOString();
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎯 РОЗДІЛ: УПРАВЛІННЯ SETUPS                          █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ДОДАВАННЯ НОВОГО SETUP
    async addSetup() {
        const name = document.getElementById('setup-name')?.value;
        const description = document.getElementById('setup-description')?.value;

        if (!name) {
            this.app.showNotification('Setup name is required', 'error');
            return;
        }

        // If we are in edit mode, update instead of adding
        if (this.currentEditSetupId) {
            await this.updateSetup(this.currentEditSetupId, { name, description });
            return;
        }

        const setupData = {
            name: name,
            description: description,
            createdAt: new Date().toISOString(),
        };

        try {
            const response = await fetch(`${this.API_URL}/setups`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(setupData),
            });
            if (!response.ok) throw new Error('Failed to add setup');

            // Замість додавання в локальний масив, перезавантажуємо дані з бекенду
            await this.loadSetups(); // loadSetups вызовет updateDisplay
            this.app.closeModal('add-setup-modal');
            this.app.showNotification('Setup added successfully!', 'success');
        } catch (error) {
            console.error('Error adding setup:', error);
            this.app.showNotification('Error adding setup', 'error');
        }
    }

    // РЕДАГУВАННЯ SETUP
    editSetup(setupId) {
        const setup = this.findSetupById(setupId);
        if (!setup) return this.app.showNotification('Setup not found', 'error');

        this.currentEditSetupId = setupId;

        document.getElementById('setup-name').value = setup.name;
        document.getElementById('setup-description').value = setup.description || '';

        this.app.uiManager.setModalTitle('add-setup-modal', '<i data-lucide="edit"></i> Edit Setup');
        this.app.uiManager.showModal('add-setup-modal');
    }

    async updateSetup(setupId, updatedData) {
        try {
            const response = await fetch(`${this.API_URL}/setups/${setupId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedData),
            });
            if (!response.ok) throw new Error('Failed to update setup');

            const setupIndex = this.setups.findIndex(s => s.id === setupId);
            if (setupIndex !== -1) {
                this.setups[setupIndex] = { ...this.setups[setupIndex], ...updatedData, id: setupId };
            }

            this.currentEditSetupId = null;
            this.updateDisplay();
            this.app.closeModal('add-setup-modal');
            this.app.showNotification('Setup updated successfully!', 'success');
        } catch (error) {
            console.error('Error updating setup:', error);
            this.app.showNotification('Error updating setup', 'error');
        }
    }

    // ВИДАЛЕННЯ SETUP
    async deleteSetup(setupId) {
        if (!confirm('Are you sure you want to delete this setup?')) return;

        try {
            const response = await fetch(`${this.API_URL}/setups/${setupId}`, {
                method: 'DELETE',
            });
            if (!response.ok) throw new Error('Failed to delete setup');

            this.setups = this.setups.filter(s => s.id !== setupId);
            this.updateDisplay();
            this.app.showNotification('Setup deleted successfully!', 'success');

        } catch (error) {
            console.error('Error deleting setup:', error);
            this.app.showNotification('Error deleting setup', 'error');
        }
    }

    // ПОШУК SETUP ПО ID
    findSetupById(setupId) {
        return this.setups.find(s => s.id === setupId);
    }

    // ПОШУК SETUP ПО НАЗВІ
    findSetupByName(setupName) {
        return this.setups.find(s => s.name === setupName);
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎯 РОЗДІЛ: УПРАВЛІННЯ ENTRY MODELS                    █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ДОДАВАННЯ НОВОЇ ENTRY MODEL
    async addEntryModel(modelData) {
        if (!modelData.name) {
            this.app.showNotification('Please fill in model name', 'error');
            return null;
        }

        const newEntryModel = {
            id: Date.now(),
            name: modelData.name,
            description: modelData.description || '',
            type: modelData.type || 'Custom',
            entryRules: modelData.entryRules || '',
            exitRules: modelData.exitRules || '',
            riskManagement: modelData.riskManagement || '',
            timeframes: modelData.timeframes || [],
            instruments: modelData.instruments || [],
            winRate: 0,
            avgRR: 0,
            totalTrades: 0,
            createdAt: new Date().toISOString(),
            usageCount: 0,
            isActive: true
        };

        try {
            const response = await fetch(`${this.API_URL}/entry-models`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newEntryModel),
            });
            if (!response.ok) throw new Error('Failed to add entry model');

            const savedModel = await response.json();
            this.entryModels.push(savedModel);
            this.app.showNotification('Entry model added successfully!', 'success');
        } catch (error) {
            console.error('Error adding entry model:', error);
            this.app.showNotification('Error adding entry model', 'error');
        }
    }

    // РЕДАГУВАННЯ ENTRY MODEL
    updateEntryModel(modelId, updatedData) {
        const modelIndex = this.entryModels.findIndex(m => m.id === modelId);
        if (modelIndex === -1) {
            this.app.showNotification('Entry model not found', 'error');
            return false;
        }

        this.entryModels[modelIndex] = {
            ...this.entryModels[modelIndex],
            ...updatedData
        };

        this.app.showNotification('Entry model updated successfully!', 'success');
        return true;
    }

    // ВИДАЛЕННЯ ENTRY MODEL
    async deleteEntryModel(modelId) {
        if (!confirm('Are you sure you want to delete this entry model?')) return;

        try {
            const response = await fetch(`${this.API_URL}/entry-models/${modelId}`, {
                method: 'DELETE',
            });
            if (!response.ok) throw new Error('Failed to delete entry model');

            this.entryModels = this.entryModels.filter(m => m.id !== modelId);
            this.updateEntryModelsDisplay();
            this.app.showNotification('Entry model deleted successfully!', 'success');

        } catch (error) {
            console.error('Error deleting entry model:', error);
            this.app.showNotification('Error deleting entry model', 'error');
        }
    }

    // ПОШУК ENTRY MODEL ПО ID
    findEntryModelById(modelId) {
        return this.entryModels.find(m => m.id === modelId);
    }

    // ДЕФОЛТНІ ENTRY MODELS
    getDefaultEntryModels() {
        return [
            {
                id: Date.now() + 1,
                name: 'Breakout Strategy',
                description: 'Entry on price breakout with volume confirmation',
                entryRules: 'Wait for price to break key levels with strong volume',
                exitRules: 'Take profit at next resistance, stop loss below support',
                riskManagement: 'Risk 1-2% per trade',
                timeframes: ['15m', '1h'],
                instruments: ['Forex', 'Indices'],
                winRate: 0,
                avgRR: 0,
                totalTrades: 0,
                createdAt: new Date().toISOString(),
                isActive: true
            },
            {
                id: Date.now() + 2,
                name: 'Trend Following',
                description: 'Follow the main trend with pullback entries',
                entryRules: 'Enter on pullbacks in trending markets',
                exitRules: 'Trail stop loss, exit on trend reversal signals',
                riskManagement: 'Risk 1-2% per trade',
                timeframes: ['1h', '4h'],
                instruments: ['Forex', 'Commodities'],
                winRate: 0,
                avgRR: 0,
                totalTrades: 0,
                createdAt: new Date().toISOString(),
                isActive: true
            }
        ];
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📊 РОЗДІЛ: СТАТИСТИКА ТА АНАЛІТИКА                    █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // РОЗРАХУНОК СТАТИСТИКИ СТРАТЕГІЇ
    calculateStrategyStats(strategyName) {
        const strategyTrades = this.app.tradeManager.getFilteredTrades().filter(
            trade => trade.strategy === strategyName
        );

        return this.calculateTradingStats(strategyTrades);
    }

    // РОЗРАХУНОК СТАТИСТИКИ SETUP
    calculateSetupStats(setupName) {
        const setupTrades = this.app.tradeManager.getFilteredTrades().filter(
            trade => trade.entryModel === setupName
        );

        return this.calculateTradingStats(setupTrades);
    }

    // РОЗРАХУНОК СТАТИСТИКИ ENTRY MODEL
    calculateEntryModelStats(modelName) {
        const modelTrades = this.app.tradeManager.getFilteredTrades().filter(
            trade => trade.entryModel === modelName
        );

        return this.calculateTradingStats(modelTrades);
    }

    // ЗАГАЛЬНИЙ РОЗРАХУНОК СТАТИСТИКИ ТРЕЙДІВ
    calculateTradingStats(trades) {
        if (trades.length === 0) {
            return this.getEmptyTradingStats();
        }

        const totalTrades = trades.length;
        const winTrades = trades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        }).length;

        const lossTrades = trades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        }).length;

        const tradesForWinRate = winTrades + lossTrades;
        const winRate = tradesForWinRate > 0 ? (winTrades / tradesForWinRate) * 100 : 0;

        const totalPnl = trades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        const avgRR = trades.length > 0 ?
            trades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / trades.length : 0;

        return {
            totalTrades,
            winTrades,
            lossTrades,
            winRate,
            totalPnl,
            avgRR
        };
    }

    // ПОРОЖНЯ СТАТИСТИКА
    getEmptyTradingStats() {
        return {
            totalTrades: 0,
            winTrades: 0,
            lossTrades: 0,
            winRate: 0,
            totalPnl: 0,
            avgRR: 0
        };
    }

    // ОНОВЛЕННЯ СТАТИСТИКИ ВСІХ СТРАТЕГІЙ
    updateAllStrategiesStats() {
        this.strategies.forEach(strategy => {
            const stats = this.calculateStrategyStats(strategy.name);
            strategy.winRate = stats.winRate;
            strategy.avgRR = stats.avgRR;
            strategy.totalTrades = stats.totalTrades;
        });
    }

    // ОНОВЛЕННЯ СТАТИСТИКИ ВСІХ SETUPS
    updateAllSetupsStats() {
        this.setups.forEach(setup => {
            const stats = this.calculateSetupStats(setup.name);
            setup.winRate = stats.winRate;
            setup.avgRR = stats.avgRR;
            setup.totalTrades = stats.totalTrades;
        });
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎨 РОЗДІЛ: ВІДОБРАЖЕННЯ ТА UI                         █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ОБНОВЛЕНИЕ ОТОБРАЖЕНИЯ ДЛЯ ВСЕЙ СЕКЦИИ
    updateDisplay() {
        this.renderStrategiesGrid();
        this.renderSetupsGrid();
    }

    // ВІДОБРАЖЕННЯ СТРАТЕГІЙ У ГРІД
    renderStrategiesGrid(containerId = 'strategies-grid') {
        const container = document.getElementById(containerId);
        if (!container) return;

        if (this.strategies.length === 0) {
            container.innerHTML = this.getEmptyStateHTML('target', 'No strategies yet', 'Create your first trading strategy to get started');
            return;
        }

        let html = '';

        this.strategies.forEach(strategy => {
            const stats = this.calculateStrategyStats(strategy.name);
            const lastUsedDate = strategy.lastUsed ?
                new Date(strategy.lastUsed).toLocaleDateString() : 'Never';

            // Формування відображення таймфреймів
            const contextTFs = strategy.contextTimeframes && strategy.contextTimeframes.length > 0
                ? strategy.contextTimeframes.join(', ')
                : 'Not set';
            const entryTFs = strategy.entryTimeframes && strategy.entryTimeframes.length > 0
                ? strategy.entryTimeframes.join(', ')
                : 'Not set';

            const timeframesDisplay = `Context: ${contextTFs} | Entry: ${entryTFs}`;

            html += `
                <div class="strategy-card">
                    <div class="strategy-card-header">
                        <div class="strategy-title-section">
                            <div class="strategy-name">${strategy.name}</div>
                            <div class="strategy-type-badge">${strategy.type}</div>
                        </div>
                        <div class="action-menu-container">
                            <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.strategyManager.showStrategyActionMenu(this, '${strategy.id}')">
                                <i data-lucide="more-horizontal"></i>
                            </button>
                            <div class="action-menu" style="display: none;">
                                <div class="action-menu-item action-edit" onclick="event.stopPropagation(); window.app.editStrategy('${strategy.id}'); this.closest('.action-menu').style.display = 'none';">
                                    <i data-lucide="edit-2"></i>
                                    <span>Edit</span>
                                </div>
                                <div class="action-menu-item action-delete" onclick="event.stopPropagation(); window.app.strategyManager.deleteStrategy('${strategy.id}'); this.closest('.action-menu').style.display = 'none';">
                                    <i data-lucide="trash-2"></i>
                                    <span>Delete</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="strategy-timeframes-section">
                        <div class="strategy-timeframes-label">Timeframes</div>
                        <div class="strategy-timeframes-display">${timeframesDisplay}</div>
                    </div>

                    <div class="strategy-metrics">
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${stats.totalTrades}</div>
                            <div class="strategy-metric-label">TRADES</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${stats.winRate.toFixed(0)}%</div>
                            <div class="strategy-metric-label">WIN RATE</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value ${stats.totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${stats.totalPnl >= 0 ? '+' : ''}$${Math.abs(stats.totalPnl).toFixed(0)}
                            </div>
                            <div class="strategy-metric-label">TOTAL P&L</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${stats.avgRR.toFixed(1)}</div>
                            <div class="strategy-metric-label">AVG RR</div>
                        </div>
                    </div>

                    <div class="strategy-content">
                        ${strategy.contextContent ? `
                            <div class="strategy-content-section">
                                <div class="strategy-content-label">CONTEXT</div>
                                <div class="strategy-content-text">${strategy.contextContent}</div>
                            </div>
                        ` : ''}
                        ${strategy.entryContent ? `
                            <div class="strategy-content-section">
                                <div class="strategy-content-label">ENTRY & EXIT</div>
                                <div class="strategy-content-text">${strategy.entryContent}</div>
                            </div>
                        ` : ''}
                    </div>

                    <div class="strategy-footer">
                        <div class="strategy-last-used">Last used: ${lastUsedDate}</div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        this.createIcons();
    }

    // ВІДОБРАЖЕННЯ SETUPS У ГРІД
    renderSetupsGrid(containerId = 'setups-grid') {
        const container = document.getElementById(containerId);
        if (!container) return;

        if (this.setups.length === 0) {
            container.innerHTML = this.getEmptyStateHTML('target', 'No setups yet', 'Create your first setup to track specific entry patterns');
            return;
        }

        let html = '';

        this.setups.forEach(setup => {
            const stats = this.calculateSetupStats(setup.name);
            const lastUsedDate = setup.lastUsed ?
                new Date(setup.lastUsed).toLocaleDateString() : 'Never';

            html += `
                <div class="strategy-card">
                    <div class="strategy-card-header">
                        <div class="strategy-title-section">
                            <div class="strategy-name">${setup.name}</div>
                        </div>
                        <div class="action-menu-container">
                            <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.strategyManager.showSetupActionMenu(this, '${setup.id}')">
                                <i data-lucide="more-horizontal"></i>
                            </button>
                            <div class="action-menu" style="display: none;">
                                <div class="action-menu-item action-edit" onclick="event.stopPropagation(); window.app.strategyManager.editSetup('${setup.id}'); this.closest('.action-menu').style.display = 'none';">
                                    <i data-lucide="edit-2"></i>
                                    <span>Edit</span>
                                </div>
                                <div class="action-menu-item action-delete" onclick="event.stopPropagation(); window.app.strategyManager.deleteSetup('${setup.id}');">
                                    <i data-lucide="trash-2"></i>
                                    <span>Delete</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="strategy-metrics">
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${stats.totalTrades}</div>
                            <div class="strategy-metric-label">TRADES</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${stats.winRate.toFixed(0)}%</div>
                            <div class="strategy-metric-label">WIN RATE</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value ${stats.totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${stats.totalPnl >= 0 ? '+' : ''}$${Math.abs(stats.totalPnl).toFixed(0)}
                            </div>
                            <div class="strategy-metric-label">TOTAL P&L</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${stats.avgRR.toFixed(1)}</div>
                            <div class="strategy-metric-label">AVG RR</div>
                        </div>
                    </div>

                    ${setup.description ? `
                        <div class="strategy-content">
                            <div class="strategy-content-section">
                                <div class="strategy-content-label">DESCRIPTION</div>
                                <div class="strategy-content-text">${setup.description}</div>
                            </div>
                        </div>
                    ` : ''}

                    <div class="strategy-footer">
                        <div class="strategy-last-used">Last used: ${lastUsedDate}</div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        this.createIcons();
    }

    // ВІДОБРАЖЕННЯ ENTRY MODELS У ГРІД
    renderEntryModelsGrid(containerId = 'entry-models-grid') {
        const container = document.getElementById(containerId);
        if (!container) return;

        if (this.entryModels.length === 0) {
            container.innerHTML = this.getEmptyStateHTML('target', 'No entry models yet', 'Create your first entry model to standardize your trading approach');
            return;
        }

        let html = '';

        this.entryModels.forEach(model => {
            const stats = this.calculateEntryModelStats(model.name);

            html += `
                <div class="entry-model-card">
                    <div class="entry-model-header">
                        <div class="entry-model-title">
                            <h3>${model.name}</h3>
                            <span class="entry-model-type">${model.type}</span>
                        </div>
                        <div class="action-menu-container">
                            <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.strategyManager.showEntryModelActionMenu(this, ${model.id})">
                                <i data-lucide="more-horizontal"></i>
                            </button>
                            <div class="action-menu" style="display: none;">
                                <div class="action-menu-item action-edit">
                                    <i data-lucide="edit-2"></i>
                                    <span>Edit</span>
                                </div>
                                <div class="action-menu-item action-delete">
                                    <i data-lucide="trash-2"></i>
                                    <span>Delete</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="entry-model-stats">
                        <div class="model-stat">
                            <span class="stat-value">${stats.totalTrades}</span>
                            <span class="stat-label">Trades</span>
                        </div>
                        <div class="model-stat">
                            <span class="stat-value">${stats.winRate.toFixed(1)}%</span>
                            <span class="stat-label">Win Rate</span>
                        </div>
                        <div class="model-stat">
                            <span class="stat-value ${stats.totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${stats.totalPnl >= 0 ? '+' : ''}$${Math.abs(stats.totalPnl).toFixed(0)}
                            </span>
                            <span class="stat-label">Total P&L</span>
                        </div>
                        <div class="model-stat">
                            <span class="stat-value">${stats.avgRR.toFixed(1)}</span>
                            <span class="stat-label">Avg RR</span>
                        </div>
                    </div>

                    <div class="entry-model-content">
                        ${model.description ? `<p class="model-description">${model.description}</p>` : ''}
                        ${model.entryRules ? `
                            <div class="model-rules">
                                <h4>Entry Rules</h4>
                                <p>${model.entryRules}</p>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        this.createIcons();
    }

    // ПОРОЖНІЙ СТЕЙТ
    getEmptyStateHTML(icon, title, description) {
        return `
            <div class="empty-state">
                <div class="empty-message">
                    <i data-lucide="${icon}"></i>
                    <p>${title}</p>
                    <small>${description}</small>
                </div>
            </div>
        `;
    }

    // MENU ДІЙ ДЛЯ СТРАТЕГІЙ
    showStrategyActionMenu(button, strategyId) {
        const container = button.closest('.action-menu-container');
        const menu = container.querySelector('.action-menu');

        document.querySelectorAll('.action-menu').forEach(m => {
            m.style.display = 'none';
        });

        menu.style.display = 'block';
        menu.style.position = 'absolute';
        menu.style.top = '100%';
        menu.style.right = '0';
        menu.style.zIndex = '100002';
    }

    // MENU ДІЙ ДЛЯ SETUPS
    showSetupActionMenu(button, setupId) {
        const container = button.closest('.action-menu-container');
        const menu = container.querySelector('.action-menu');

        document.querySelectorAll('.action-menu').forEach(m => {
            m.style.display = 'none';
        });

        menu.style.display = 'block';
        menu.style.position = 'absolute';
        menu.style.top = '100%';
        menu.style.right = '0';
        menu.style.zIndex = '100002';
    }

    // MENU ДІЙ ДЛЯ ENTRY MODELS
    showEntryModelActionMenu(button, modelId) {
        const container = button.closest('.action-menu-container');
        const menu = container.querySelector('.action-menu');

        document.querySelectorAll('.action-menu').forEach(m => {
            m.style.display = 'none';
        });

        menu.style.display = 'block';
        menu.style.position = 'absolute';
        menu.style.top = '100%';
        menu.style.right = '0';
        menu.style.zIndex = '100002';
    }

    // ЗАПОВНЕННЯ SELECT ЕЛЕМЕНТІВ
    populateStrategiesSelect(selectElement) {
        if (!selectElement) return;

        selectElement.innerHTML = '<option value="">Select Strategy</option>';
        this.strategies.forEach(strategy => {
            selectElement.innerHTML += `<option value="${strategy.name}">${strategy.name} (${strategy.type})</option>`;
        });
    }

    populateSetupsSelect(selectElement) {
        if (!selectElement) return;

        selectElement.innerHTML = '<option value="">Select Setup</option>';
        this.setups.forEach(setup => {
            selectElement.innerHTML += `<option value="${setup.name}">${setup.name}</option>`;
        });
    }

    populateEntryModelsSelect(selectElement) {
        if (!selectElement) return;

        selectElement.innerHTML = '<option value="">Select Entry Model</option>';
        this.entryModels.forEach(model => {
            selectElement.innerHTML += `<option value="${model.name}">${model.name}</option>`;
        });
    }

    // ОНОВЛЕННЯ ВІДОБРАЖЕННЯ СТРАТЕГІЙ
    updateStrategiesDisplay() {
        this.renderStrategiesGrid();
        this.updateStrategiesMetrics();
    }

    // ОНОВЛЕННЯ МЕТРИК СТРАТЕГІЙ
    updateStrategiesMetrics() {
        const totalStrategies = this.strategies.length;

        let bestWinRate = 0;
        let mostUsedStrategy = '-';
        let mostProfitableStrategy = '-';

        if (totalStrategies > 0) {
            let maxUsage = 0;
            let maxProfit = -Infinity;

            this.strategies.forEach(strategy => {
                const stats = this.calculateStrategyStats(strategy.name);

                if (stats.winRate > bestWinRate) {
                    bestWinRate = stats.winRate;
                }

                if (stats.totalTrades > maxUsage) {
                    maxUsage = stats.totalTrades;
                    mostUsedStrategy = strategy.name;
                }

                if (stats.totalPnl > maxProfit) {
                    maxProfit = stats.totalPnl;
                    mostProfitableStrategy = strategy.name;
                }
            });
        }

        this.app.updateElement('total-strategies', totalStrategies);
        this.app.updateElement('best-strategy-winrate', `${bestWinRate.toFixed(0)}%`);
        this.app.updateElement('most-used-strategy', mostUsedStrategy);
        this.app.updateElement('most-profitable-strategy', mostProfitableStrategy);
    }

    // ІНІЦІАЛІЗАЦІЯ ICONS
    createIcons() {
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🔧 РОЗДІЛ: УТІЛІТИ ТА ДОПОМІЖНІ ФУНКЦІЇ               █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ЕКСПОРТ СТРАТЕГІЙ У CSV
    exportStrategiesToCSV() {
        const headers = ['Name', 'Type', 'Total Trades', 'Win Rate', 'Total P&L', 'Avg RR', 'Last Used'];
        const csvData = this.strategies.map(strategy => {
            const stats = this.calculateStrategyStats(strategy.name);
            return [
                strategy.name,
                strategy.type,
                stats.totalTrades,
                `${stats.winRate.toFixed(1)}%`,
                `$${stats.totalPnl.toFixed(2)}`,
                stats.avgRR.toFixed(2),
                strategy.lastUsed ? new Date(strategy.lastUsed).toLocaleDateString() : 'Never'
            ];
        });

        const csvContent = [
            headers.join(','),
            ...csvData.map(row => row.join(','))
        ].join('\n');

        this.downloadCSV(csvContent, 'strategies-export');
        this.app.showNotification('Strategies exported to CSV successfully!', 'success');
    }

    // ЕКСПОРТ SETUPS У CSV
    exportSetupsToCSV() {
        const headers = ['Name', 'Description', 'Total Trades', 'Win Rate', 'Total P&L', 'Avg RR'];
        const csvData = this.setups.map(setup => {
            const stats = this.calculateSetupStats(setup.name);
            return [
                setup.name,
                setup.description,
                stats.totalTrades,
                `${stats.winRate.toFixed(1)}%`,
                `$${stats.totalPnl.toFixed(2)}`,
                stats.avgRR.toFixed(2)
            ];
        });

        const csvContent = [
            headers.join(','),
            ...csvData.map(row => row.join(','))
        ].join('\n');

        this.downloadCSV(csvContent, 'setups-export');
        this.app.showNotification('Setups exported to CSV successfully!', 'success');
    }

    // ЗАГАЛЬНИЙ МЕТОД ДЛЯ ЕКСПОРТУ CSV
    downloadCSV(csvContent, filename) {
        const blob = new Blob([csvContent], {type: 'text/csv'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${filename}-${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
        URL.revokeObjectURL(url);
    }

    // ОЧИСТКА ВСІХ СТРАТЕГІЙ
    clearAllStrategies() {
        if (confirm('Are you sure you want to delete ALL strategies? This action cannot be undone.')) {
            this.strategies = [];
            this.app.showNotification('All strategies cleared successfully!', 'success');
        }
    }

    // ОЧИСТКА ВСІХ SETUPS
    clearAllSetups() {
        if (confirm('Are you sure you want to delete ALL setups? This action cannot be undone.')) {
            this.setups = [];
            this.app.showNotification('All setups cleared successfully!', 'success');
        }
    }
}

// Експорт для використання в інших модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StrategyManager;
}