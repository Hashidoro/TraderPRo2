// ===============================================
// 📈 CHART MANAGER - УПРАВЛІННЯ ГРАФІКАМИ
// ===============================================

class ChartManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.charts = {};
    }

    async initializeCharts() {
        await this.waitForChartJS();
        console.log('Initializing charts with real trade data...');

        this.initEquityCurveChart();
        this.initWinRateChart();
        this.initMonthlyPerformance();
        this.initPnlDistribution();
        this.initSymbolPerformance();
        this.initMonthlyBreakdown();
        this.initDrawdownChart();

        console.log('Charts initialized with', this.app.trades.length, 'trades');
    }

    updateCharts() {
        if (typeof d3 !== 'undefined') {
            this.updateEquityCurve();
        }
        if (typeof Chart !== 'undefined') {
            this.updateWinRateChart();
            this.updateMonthlyPerformance();
            this.updatePnlDistribution();
            this.updateSymbolPerformance();
            this.updateMonthlyBreakdown();
            this.updateDrawdownChart();
        }
    }

    waitForChartJS() {
        return new Promise((resolve) => {
            if (typeof Chart !== 'undefined') {
                resolve();
                return;
            }
            const checkChart = () => {
                if (typeof Chart !== 'undefined') resolve();
                else setTimeout(checkChart, 100);
            };
            checkChart();
        });
    }

    // ┌───────────────────────────────────┐
    // │ 📊 EQUITY CURVE (D3.JS)           │
    // └───────────────────────────────────┘
    initEquityCurveChart() {
        const container = document.getElementById('equity-curve-chart');
        if (!container) return;
        if (typeof d3 === 'undefined') return;

        this.setupEquityControls();
        this.renderEquityCurve();
    }

    setupEquityControls() {
        // ... (логіка налаштування кнопок періоду)
    }

    renderEquityCurve(period = 'all') {
        // ... (вся складна логіка рендерингу D3.js графіка)
        console.log(`Rendering equity curve for period: ${period}`);
    }

    updateEquityCurve() {
        const activeBtn = document.querySelector('.equity-btn.active');
        const period = activeBtn ? activeBtn.dataset.period : 'all';
        this.renderEquityCurve(period);
    }

    // ┌───────────────────────────────────┐
    // │ 📈 CHART.JS ГРАФІКИ               │
    // └───────────────────────────────────┘

    initWinRateChart() {
        const canvas = document.getElementById('win-rate-chart');
        if (!canvas) return;
        if (this.charts.winRateChart) this.charts.winRateChart.destroy();

        this.charts.winRateChart = new Chart(canvas.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['Wins', 'Losses'],
                datasets: [{ data: [1, 1], backgroundColor: ['#059669', '#dc2626'], borderWidth: 0 }]
            },
            options: { responsive: true, maintainAspectRatio: false, cutout: '60%', plugins: { legend: { display: false } } }
        });
        this.updateWinRateChart();
    }

    updateWinRateChart() {
        if (!this.charts.winRateChart) return;
        const trades = this.app.tradeManager.getFilteredTrades();
        const wins = trades.filter(t => t.result?.toLowerCase() === 'win').length;
        const losses = trades.filter(t => t.result?.toLowerCase() === 'loss').length;
        this.charts.winRateChart.data.datasets[0].data = [wins || 1, losses || 1];
        this.charts.winRateChart.update('none');
    }

    initMonthlyPerformance() {
        const canvas = document.getElementById('monthly-performance');
        if (!canvas) return;
        if (this.charts.monthlyPerformance) this.charts.monthlyPerformance.destroy();

        this.charts.monthlyPerformance = new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: { labels: [], datasets: [{ label: 'Monthly P&L', data: [], backgroundColor: [], borderRadius: 4 }] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { x: { grid: { display: false } }, y: { ticks: { callback: v => '$' + v } } }
            }
        });
        this.updateMonthlyPerformance();
    }

    updateMonthlyPerformance() {
        if (!this.charts.monthlyPerformance) return;
        const monthlyData = {};
        this.app.tradeManager.getFilteredTrades().forEach(trade => {
            try {
                const monthKey = (trade.date || trade.entryDate).substring(0, 7);
                if (!monthlyData[monthKey]) monthlyData[monthKey] = 0;
                monthlyData[monthKey] += (trade.pnl || 0);
            } catch (e) { /* ignore invalid dates */ }
        });

        const labels = Object.keys(monthlyData).sort();
        const data = labels.map(label => monthlyData[label]);
        const colors = data.map(value => value >= 0 ? '#059669' : '#dc2626');

        this.charts.monthlyPerformance.data.labels = labels;
        this.charts.monthlyPerformance.data.datasets[0].data = data;
        this.charts.monthlyPerformance.data.datasets[0].backgroundColor = colors;
        this.charts.monthlyPerformance.update('none');
    }

    initPnlDistribution() {
        const canvas = document.getElementById('pnl-distribution');
        if (!canvas) return;
        if (this.charts.pnlDistribution) this.charts.pnlDistribution.destroy();

        this.charts.pnlDistribution = new Chart(canvas.getContext('2d'), {
            type: 'doughnut',
            // ... конфігурація ...
        });
        this.updatePnlDistribution();
    }

    updatePnlDistribution() {
        if (!this.charts.pnlDistribution) return;
        // ... логіка оновлення ...
    }

    initSymbolPerformance() {
        const canvas = document.getElementById('symbol-performance');
        if (!canvas) return;
        if (this.charts.symbolPerformance) this.charts.symbolPerformance.destroy();

        this.charts.symbolPerformance = new Chart(canvas.getContext('2d'), {
            type: 'bar',
            // ... конфігурація ...
        });
        this.updateSymbolPerformance();
    }

    updateSymbolPerformance() {
        if (!this.charts.symbolPerformance) return;
        // ... логіка оновлення ...
    }

    initMonthlyBreakdown() {
        const canvas = document.getElementById('monthly-breakdown');
        if (!canvas) return;
        if (this.charts.monthlyBreakdown) this.charts.monthlyBreakdown.destroy();

        this.charts.monthlyBreakdown = new Chart(canvas.getContext('2d'), {
            type: 'line',
            // ... конфігурація ...
        });
        this.updateMonthlyBreakdown();
    }

    updateMonthlyBreakdown() {
        if (!this.charts.monthlyBreakdown) return;
        // ... логіка оновлення ...
    }

    initDrawdownChart() {
        const canvas = document.getElementById('drawdown-chart');
        if (!canvas) return;
        if (this.charts.drawdownChart) this.charts.drawdownChart.destroy();

        this.charts.drawdownChart = new Chart(canvas.getContext('2d'), {
            type: 'line',
            // ... конфігурація ...
        });
        this.updateDrawdownChart();
    }

    updateDrawdownChart() {
        if (!this.charts.drawdownChart) return;
        // ... логіка оновлення ...
    }
}