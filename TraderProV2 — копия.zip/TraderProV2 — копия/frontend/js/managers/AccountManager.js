// ===============================================
// 🏦 ACCOUNT MANAGER - УПРАВЛІННЯ РАХУНКАМИ
// ===============================================

class AccountManager {
    constructor(mainApp) {
        this.app = mainApp;
        this.accounts = [];
        this.currentEditAccountId = null;
        this.API_URL = 'http://localhost:3000/api';
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📥 РОЗДІЛ: ЗАВАНТАЖЕННЯ ТА ЗБЕРЕЖЕННЯ ДАНИХ (через API) █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    async loadAccounts() {
        try {
            const response = await fetch(`${this.API_URL}/accounts`);
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            this.accounts = await response.json();
            console.log('Loaded accounts from backend:', this.accounts.length);
            this.app.updateAccountsDisplay(); // Оновити UI після завантаження
        } catch (error) {
            console.error('Error loading accounts from backend:', error);
            this.app.showNotification('Could not load accounts from server', 'error');
            this.accounts = [];
        }
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  ➕ РОЗДІЛ: ДОДАВАННЯ ТА РЕДАГУВАННЯ РАХУНКІВ (через API) █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    async addAccount(accountData) {
        if (!accountData.name || !accountData.type || !accountData.startingBalance) {
            this.app.showNotification('Please fill in all required fields (Name, Type, Balance)', 'error');
            return null;
        }

        try {
            const response = await fetch(`${this.API_URL}/accounts`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(accountData),
            });

            if (!response.ok) {
                throw new Error('Failed to create account');
            }

            const savedAccount = await response.json(); // Отримуємо повний об'єкт з _id від MongoDB
            this.accounts.push(savedAccount);
            this.app.accountManager.updateAccountsDisplay(); // Використовуємо менеджер для оновлення
            this.app.uiManager.closeModal('add-account-modal');
            this.app.showNotification('Account added successfully!', 'success');
            return savedAccount;
        } catch (error) {
            console.error('Error adding account:', error);
            this.app.showNotification('Error adding account', 'error');
            return null;
        }
    }

    editAccount(accountId) {
        const account = this.findAccountById(accountId);
        if (!account) {
            this.app.showNotification('Account not found', 'error');
            return;
        }

        this.currentEditAccountId = accountId;

        // Заполняем форму в модальном окне (предполагая, что у вас есть модальное окно для редактирования)
        // Если у вас одно модальное окно для добавления и редактирования, используйте его
        const modalId = 'add-account-modal';
        document.getElementById('account-name').value = account.name;
        document.getElementById('account-type').value = account.type;
        document.getElementById('account-balance').value = account.starting_balance;
        document.getElementById('account-broker').value = account.broker || '';
        document.getElementById('account-status').value = account.status || '';
        document.getElementById('account-start-date').value = account.start_date || '';

        this.app.uiManager.setModalTitle(modalId, '<i data-lucide="edit"></i> Edit Account');
        this.app.uiManager.setModalButton(modalId, '<i data-lucide="save"></i> Save Changes');

        this.app.uiManager.showModal(modalId);
    }

    async updateAccount(accountId, updatedData) {
        try {
            const response = await fetch(`${this.API_URL}/accounts/${accountId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedData),
            });
            if (!response.ok) throw new Error('Failed to update account');

            const accountIndex = this.accounts.findIndex(acc => acc.id === accountId);
            if (accountIndex !== -1) {
                this.accounts[accountIndex] = { ...this.accounts[accountIndex], ...updatedData };
            }

            this.app.showNotification('Account updated successfully!', 'success');
            this.app.updateAccountsDisplay();
            this.app.uiManager.closeModal('add-account-modal'); // или 'edit-account-modal'
        } catch (error) {
            console.error('Error updating account:', error);
            this.app.showNotification('Error updating account', 'error');
        }
    }

    async deleteAccount(accountId) {
        if (!confirm('Are you sure you want to delete this account? This will also delete all associated trades.')) return;

        const authState = this.app.getAuthState();
        if (!authState.isAuthenticated || !authState.user.id) {
            this.app.showNotification('You must be logged in to delete an account.', 'error');
            return;
        }

        try {
            const response = await fetch(`${this.API_URL}/accounts/${accountId}`, {
                method: 'DELETE',
                headers: {
                    'User-Id': authState.user.id
                }
            });
            if (!response.ok) throw new Error('Failed to delete account');

            this.accounts = this.accounts.filter(acc => acc.id !== accountId);
            this.app.showNotification('Account deleted successfully!', 'success');
            this.app.updateAccountsDisplay();
        } catch (error) {
            console.error('Error deleting account:', error);
            this.app.showNotification('Error deleting account', 'error');
        }
    }

    // ... (решта методів залишається без змін, оскільки вони працюють з даними в пам'яті) ...

    findAccountById(accountId) {
        return this.accounts.find(acc => acc.id === accountId);
    }

    getAccountName(accountId) {
        const account = this.findAccountById(accountId);
        return account ? account.name : 'Unknown';
    }

    calculateAccountStats(accountId) {
        const account = this.findAccountById(accountId);
        if (!account) return this.getEmptyAccountStats();

        const accountTrades = this.app.tradeManager.getFilteredTrades().filter(
            trade => trade.accountId === accountId
        );

        const accountPayouts = this.app.payoutManager ?
            this.app.payoutManager.getPayoutsByAccount(accountId) : [];

        const totalTradesPnl = accountTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        const payoutAmount = accountPayouts.reduce((sum, payout) => sum + (payout.amount || 0), 0);

        const currentBalance = account.starting_balance + totalTradesPnl - payoutAmount;
        const netPnl = totalTradesPnl;
        const netPnlPercent = account.starting_balance > 0 ? (netPnl / account.starting_balance) * 100 : 0;

        const winTrades = accountTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        }).length;

        const lossTrades = accountTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        }).length;

        const tradesForWinRate = winTrades + lossTrades;
        const winRate = tradesForWinRate > 0 ? (winTrades / tradesForWinRate) * 100 : 0;

        const totalRR = accountTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0);
        const avgRR = accountTrades.length > 0 ? totalRR / accountTrades.length : 0;

        const maxDrawdown = this.calculateAccountDrawdown(account, accountTrades);

        return {
            account,
            currentBalance,
            netPnl,
            netPnlPercent,
            totalTrades: accountTrades.length,
            winRate,
            avgRR,
            maxDrawdown,
            winTrades,
            lossTrades,
            totalPayouts: payoutAmount
        };
    }

    calculateAccountDrawdown(account, trades) {
        if (trades.length === 0) return 0;

        let runningBalance = account.starting_balance;
        let peak = account.starting_balance;
        let maxDrawdown = 0;

        const sortedTrades = trades.sort((a, b) => {
            const dateA = new Date(a.date || a.entryDate);
            const dateB = new Date(b.date || b.entryDate);
            return dateA.getTime() - dateB.getTime();
        });

        sortedTrades.forEach(trade => {
            runningBalance += (trade.pnl || 0);
            if (runningBalance > peak) peak = runningBalance;

            const drawdown = peak > 0 ? ((peak - runningBalance) / peak) * 100 : 0;
            if (drawdown > maxDrawdown) maxDrawdown = drawdown;
        });

        return maxDrawdown;
    }

    getEmptyAccountStats() {
        return {
            currentBalance: 0,
            netPnl: 0,
            netPnlPercent: 0,
            totalTrades: 0,
            winRate: 0,
            avgRR: 0,
            maxDrawdown: 0,
            winTrades: 0,
            lossTrades: 0,
            totalPayouts: 0
        };
    }

    calculateOverallStats() {
        const filteredAccounts = this.getFilteredAccounts();

        if (filteredAccounts.length === 0) {
            return {
                totalCapital: 0,
                totalPnl: 0,
                averageGrowth: 0,
                liveCapital: 0,
                challengeCapital: 0,
                bestPerformer: null
            };
        }

        let totalCapital = 0;
        let totalPnl = 0;
        let totalStartingBalance = 0;
        let liveCapital = 0;
        let challengeCapital = 0;
        let bestPerformer = null;
        let bestPnl = -Infinity;

        filteredAccounts.forEach(account => {
            const stats = this.calculateAccountStats(account.id);

            totalCapital += stats.currentBalance;
            totalPnl += stats.netPnl;
            totalStartingBalance += account.starting_balance;

            if (account.type === 'Live') {
                liveCapital += stats.currentBalance;
            } else {
                challengeCapital += stats.currentBalance;
            }

            if (stats.netPnl > bestPnl) {
                bestPnl = stats.netPnl;
                bestPerformer = account;
            }
        });

        const averageGrowth = totalStartingBalance > 0 ? (totalPnl / totalStartingBalance) * 100 : 0;

        return {
            totalCapital,
            totalPnl,
            averageGrowth,
            liveCapital,
            challengeCapital,
            bestPerformer,
            totalAccounts: filteredAccounts.length
        };
    }

    getFilteredAccounts() {
        let filteredAccounts = [...this.accounts];

        const selectedAccountIds = this.app.getSelectedAccountIds();
        if (selectedAccountIds && selectedAccountIds.length > 0) {
            filteredAccounts = filteredAccounts.filter(acc =>
                selectedAccountIds.includes(acc.id)
            );
        }

        return filteredAccounts;
    }

    groupAccountsByStatus() {
        const filteredAccounts = this.getFilteredAccounts();

        return {
            'Live': filteredAccounts.filter(acc => acc.type === 'Live' || acc.status === 'Live'),
            'Phase 2': filteredAccounts.filter(acc => acc.status === 'Phase 2'),
            'Phase 1': filteredAccounts.filter(acc => acc.status === 'Phase 1' || (acc.type === 'Challenge' && !acc.status)),
            'Passed': filteredAccounts.filter(acc => acc.status === 'Passed'),
            'Failed': filteredAccounts.filter(acc => acc.status === 'Failed')
        };
    }

    getAccountsByType(type) {
        return this.accounts.filter(acc => acc.type === type);
    }

    updateAccountBalance(accountId, amount) {
        const account = this.findAccountById(accountId);
        if (!account) return false;

        account.current_balance += amount;
        // Потрібно реалізувати оновлення на бекенді
        console.warn('updateAccountBalance needs to be implemented on the backend');
        return true;
    }

    addProfitToAccount(accountId, profit) {
        return this.updateAccountBalance(accountId, profit);
    }

    subtractPayoutFromAccount(accountId, payoutAmount) {
        return this.updateAccountBalance(accountId, -payoutAmount);
    }

    hasSufficientBalance(accountId, amount) {
        const account = this.findAccountById(accountId);
        return account ? account.current_balance >= amount : false;
    }

    formatAccountDate(dateStr) {
        if (!dateStr) return 'Unknown';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    calculateAccountDuration(startDate) {
        if (!startDate) return 'Unknown';

        const start = new Date(startDate);
        const now = new Date();
        const diffTime = Math.abs(now - start);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays < 7) {
            return `${diffDays} day${diffDays > 1 ? 's' : ''}`;
        } else if (diffDays < 30) {
            const weeks = Math.floor(diffDays / 7);
            return `${weeks} week${weeks > 1 ? 's' : ''}`;
        } else if (diffDays < 365) {
            const months = Math.floor(diffDays / 30);
            return `${months} month${months > 1 ? 's' : ''}`;
        } else {
            const years = Math.floor(diffDays / 365);
            const remainingDays = diffDays % 365;
            const months = Math.floor(remainingDays / 30);
            if (months > 0) {
                return `${years}y ${months}m`;
            }
            return `${years} year${years > 1 ? 's' : ''}`;
        }
    }

    generateAccountCardHTML(account) {
        const stats = this.calculateAccountStats(account.id);
        const duration = this.calculateAccountDuration(account.start_date);
        const startDateFormatted = this.formatAccountDate(account.start_date);

        const pnlClass = stats.netPnl >= 0 ? 'positive' : 'negative';

        return `
            <div class="account-card-sleek">
                <div class="account-card-header">
                    <div class="account-title-section">
                        <div class="account-name">${account.name}</div>
                        <div class="account-type-badge ${account.type.toLowerCase().replace(' ', '')}">
                            <div class="badge-indicator"></div>
                            ${account.type}
                        </div>
                    </div>
                    <div class="action-menu-container">
                        <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.accountManager.showAccountActionMenu(this, '${account.id}')">
                            <i data-lucide="more-horizontal"></i>
                        </button>
                        <div class="action-menu" style="display: none;">
                            <div class="action-menu-item action-edit" onclick="event.stopPropagation(); window.app.accountManager.editAccount('${account.id}'); this.closest('.action-menu').style.display = 'none';">
                                <i data-lucide="edit-2"></i>
                                <span>Edit</span>
                            </div>
                            <div class="action-menu-item action-delete" onclick="event.stopPropagation(); window.app.accountManager.deleteAccount('${account.id}'); this.closest('.action-menu').style.display = 'none';">
                                <i data-lucide="trash-2"></i>
                                <span>Delete</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="account-balance-section">
                    <div class="balance-amount">$${stats.currentBalance.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}</div>
                    <div class="balance-change ${pnlClass}">
                        ${stats.netPnl >= 0 ? '+' : ''}$${Math.abs(stats.netPnl).toFixed(2)} (${stats.netPnlPercent >= 0 ? '+' : ''}${stats.netPnlPercent.toFixed(1)}%)
                    </div>
                </div>

                <div class="account-timeline">
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <i data-lucide="calendar"></i>
                        </div>
                        <div class="timeline-content">
                            <div class="timeline-label">Started</div>
                            <div class="timeline-value">${startDateFormatted}</div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <i data-lucide="clock"></i>
                        </div>
                        <div class="timeline-content">
                            <div class="timeline-label">Duration</div>
                            <div class="timeline-value">${duration}</div>
                        </div>
                    </div>
                </div>

                <div class="account-stats-grid">
                    <div class="stat-item">
                        <div class="stat-value">${stats.totalTrades}</div>
                        <div class="stat-label">Trades</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${stats.winRate.toFixed(0)}%</div>
                        <div class="stat-label">Win Rate</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${stats.avgRR.toFixed(1)}</div>
                        <div class="stat-label">Avg RR</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value negative">-${stats.maxDrawdown.toFixed(1)}%</div>
                        <div class="stat-label">Max DD</div>
                    </div>
                </div>

                <div class="account-broker-tag">
                    <i data-lucide="building"></i>
                    ${account.broker || 'No Broker'}
                </div>
            </div>
        `;
    }

    showAccountActionMenu(button, accountId) {
        const container = button.closest('.action-menu-container');
        const menu = container.querySelector('.action-menu');

        document.querySelectorAll('.action-menu').forEach(m => {
            m.style.display = 'none';
        });

        menu.style.display = 'block';
        menu.style.position = 'absolute';
        menu.style.top = '100%';
        menu.style.right = '0';
        menu.style.zIndex = '100002';
    }

    populateAccountsSelect(selectElement) {
        if (!selectElement) return;

        selectElement.innerHTML = '<option value="">Select Account</option>';
        this.accounts.forEach(account => {
            const statusDisplay = account.status || account.type;
            selectElement.innerHTML += `<option value="${account.id}">${account.name} (${statusDisplay})</option>`;
        });
    }

    updateAccountsDisplay() {
        this.updateAccountsOverview();
        this.renderAccountsByStatus();
    }

    updateAccountsOverview() {
        const overallStats = this.calculateOverallStats();

        this.app.updateElement('total-accounts-capital', `$${overallStats.totalCapital.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}`);
        this.app.updateElement('overview-live-capital', `$${overallStats.liveCapital.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}`);
        this.app.updateElement('overview-challenge-capital', `$${overallStats.challengeCapital.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}`);

        if (overallStats.bestPerformer) {
            this.app.updateElement('best-performer-account', overallStats.bestPerformer.name);
        } else {
            this.app.updateElement('best-performer-account', '-');
        }

        const pnlElement = document.getElementById('total-accounts-pnl');
        if (pnlElement) {
            pnlElement.textContent = `${overallStats.totalPnl >= 0 ? '+' : ''}$${Math.abs(overallStats.totalPnl).toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            })}`;
            pnlElement.className = 'metric-value ' + (overallStats.totalPnl >= 0 ? 'positive' : 'negative');
        }

        const growthElement = document.getElementById('average-growth-percent');
        if (growthElement) {
            growthElement.textContent = `${overallStats.averageGrowth >= 0 ? '+' : ''}${overallStats.averageGrowth.toFixed(1)}%`;
            growthElement.className = 'metric-value ' + (overallStats.averageGrowth >= 0 ? 'positive' : 'negative');
        }
    }

    renderAccountsByStatus() {
        const container = document.getElementById('accounts-sections');
        if (!container) return;

        const filteredAccounts = this.getFilteredAccounts();

        if (filteredAccounts.length === 0) {
            container.innerHTML = `
                <div class="empty-accounts-state">
                    <div class="empty-message">
                        <i data-lucide="filter"></i>
                        <h3>No matching accounts</h3>
                        <p>Adjust your account filter to see accounts</p>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        const accountsByStatus = this.groupAccountsByStatus();
        let html = '';

        Object.entries(accountsByStatus).forEach(([status, accounts]) => {
            if (accounts.length > 0) {
                const statusClass = status.toLowerCase().replace(' ', '');
                html += `
                    <div class="accounts-section" data-status="${status}">
                        <div class="accounts-section-header" onclick="window.app.accountManager.toggleAccountSection('${status}')">
                            <div class="section-badge ${statusClass}-badge">
                                <i data-lucide="circle"></i>
                                ${status}
                            </div>
                            <button class="accounts-section-toggle">
                                <i data-lucide="chevron-down"></i>
                            </button>
                        </div>
                        <div class="accounts-list">
                            ${accounts.map(account => this.generateAccountCardHTML(account)).join('')}
                        </div>
                    </div>
                `;
            }
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    toggleAccountSection(status) {
        const section = document.querySelector(`[data-status="${status}"]`);
        if (section) {
            section.classList.toggle('collapsed');

            const chevron = section.querySelector('.accounts-section-toggle i[data-lucide="chevron-down"]');
            if (chevron) {
                const isCollapsed = section.classList.contains('collapsed');
                chevron.style.transform = isCollapsed ? 'rotate(-90deg)' : 'rotate(0deg)';
            }
        }
    }

    validateAccountData(accountData) {
        const requiredFields = ['name', 'type', 'startingBalance'];
        const missingFields = requiredFields.filter(field => !accountData[field]);

        if (missingFields.length > 0) {
            throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
        }

        if (isNaN(accountData.startingBalance)) {
            throw new Error('Starting balance must be a valid number');
        }

        if (parseFloat(accountData.startingBalance) <= 0) {
            throw new Error('Starting balance must be greater than 0');
        }

        return true;
    }

    exportAccountsToCSV() {
        const headers = ['Name', 'Type', 'Status', 'Starting Balance', 'Current Balance', 'Currency', 'Broker', 'Start Date'];
        const csvData = this.accounts.map(account => [
            account.name,
            account.type,
            account.status,
            account.starting_balance,
            account.current_balance,
            account.currency,
            account.broker,
            account.start_date
        ]);

        const csvContent = [
            headers.join(','),
            ...csvData.map(row => row.join(','))
        ].join('\n');

        const blob = new Blob([csvContent], {type: 'text/csv'});
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `accounts-export-${new Date().toISOString().split('T')[0]}.csv`;
        link.click();

        URL.revokeObjectURL(url);
        this.app.showNotification('Accounts exported to CSV successfully!', 'success');
    }

    clearAllAccounts() {
        if (confirm('Are you sure you want to delete ALL accounts? This action cannot be undone.')) {
            this.accounts = [];
            // Потрібно реалізувати видалення на бекенді
            console.warn('clearAllAccounts needs to be implemented on the backend');
            this.app.showNotification('All accounts cleared locally (backend not implemented)', 'warning');
        }
    }
}

// Експорт для використання в інших модулях
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AccountManager;
}