
// ===============================================
// 🚀 APP INITIALIZER - ІНІЦІАЛІЗАТОР ДОДАТКУ
// ===============================================

document.addEventListener('DOMContentLoaded', () => {
    // Створюємо екземпляр головного класу додатку
    window.app = new TradingApp();

    // 1. Authentication Check
    const authState = window.app.getAuthState();
    if (!authState || !authState.isAuthenticated) {
        window.app.uiManager.showLogin();
    } else {
        window.app.uiManager.hideAppBlocker();
    }

    // Ініціалізуємо додаток
    window.app.init();

    // Створюємо глобальний API для відладки та доступу з консолі
    window.AppAPI = {
        app: window.app,
        data: window.app.dataManager,
        trades: window.app.tradeManager,
        accounts: window.app.accountManager,
        strategies: window.app.strategyManager,
        ui: window.app.uiManager,
        
        // Допоміжні функції
        help: () => {
            console.log('========================================');
            console.log('======= 👨‍💻 AppAPI Console Tools 👨‍💻 =======');
            console.log('========================================');
            console.log('Available objects:');
            console.log('  - AppAPI.app: The main TradingApp instance');
            console.log('  - AppAPI.data: DataManager for data operations');
            console.log('  - AppAPI.trades: TradeManager for trade operations');
            console.log('  - AppAPI.accounts: AccountManager for account operations');
            console.log('  - AppAPI.strategies: StrategyManager for strategies');
            console.log('  - AppAPI.ui: UIManager for UI operations');
            console.log('');
            console.log('Example commands:');
            console.log('  - AppAPI.trades.getTrades()');
            console.log('  - AppAPI.accounts.getAccounts()');
            console.log('  - AppAPI.ui.showNotification("Hello from console!", "success")');
            console.log('========================================');
        }
    };
});
