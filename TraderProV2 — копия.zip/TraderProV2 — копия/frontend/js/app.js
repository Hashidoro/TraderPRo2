// ===============================================
// 🎯 TRADESCOPE PRO - ГОЛОВНИЙ КЛАС ДОДАТКУ (МОДУЛЬНА ВЕРСІЯ)
// ===============================================

class TradingApp {
    constructor() {
        // ═══════════════════════════════════════════════════════════
        // 🏗️ РОЗДІЛ: ІНІЦІАЛІЗАЦІЯ МЕНЕДЖЕРІВ
        // ═══════════════════════════════════════════════════════════
        this.initializeManagers();

        // ═══════════════════════════════════════════════════════════
        // ⚙️ РОЗДІЛ: СТАН ДОДАТКУ ТА НАЛАШТУВАННЯ
        // ═══════════════════════════════════════════════════════════
        this.currentDate = new Date();
        this.charts = {};
        this.selectedAccountIds = null;
        this.favoritePairs = [];
        this.globalTimePeriod = '1d';
        this.customDateRange = {from: null, to: null};

        this.columnVisibility = {
            tradeNumber: true, date: true, pair: true, direction: true,
            result: true, profitDollar: true, profitPercent: true, rr: true,
            risk: true, strategy: true, setup: true, session: true,
            notes: true, account: true
        };
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🏗️ РОЗДІЛ: ІНІЦІАЛІЗАЦІЯ МЕНЕДЖЕРІВ                   █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // Для зворотної сумісності з існуючим кодом
    get trades() {
        return this.tradeManager.trades;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🔧 РОЗДІЛ: ОСНОВНА ІНІЦІАЛІЗАЦІЯ                      █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    get accounts() {
        return this.accountManager.accounts;
    }

    get strategies() {
        return this.strategyManager.strategies;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🖱️ РОЗДІЛ: ОБРОБНИКИ ПОДІЙ (СПРОЩЕНА ВЕРСІЯ)         █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    get setups() {
        return this.strategyManager.setups;
    }

    get entryModels() {
        return this.strategyManager.entryModels;
    }

    initializeManagers() {
        // Створення менеджерів в правильному порядку
        this.dataManager = new DataManager(this);
        this.tradeManager = new TradeManager(this);
        this.accountManager = new AccountManager(this);
        this.strategyManager = new StrategyManager(this);
        this.uiManager = new UIManager(this);

        // Додаткові менеджери (якщо потрібні)
        this.payoutManager = new PayoutManager(this);
        this.chartManager = new ChartManager(this);
        this.calendarManager = new CalendarManager(this);
    }

    async init() {
        console.log('🚀 Initializing TradingApp with modular architecture...');

        // ┌─────────────────────────────────────────────────────────┐
        // │ 📥 ЗАВАНТАЖЕННЯ ДАНИХ                                  │
        // └─────────────────────────────────────────────────────────┘
        await this.dataManager.loadAllData(); // Чекаємо, доки всі дані завантажаться

        // ┌─────────────────────────────────────────────────────────┐
        // │ 🎨 НАЛАШТУВАННЯ ІНТЕРФЕЙСУ                             │
        // └─────────────────────────────────────────────────────────┘
        this.setupEventListeners();
        this.uiManager.loadThemeSetting();
        this.initializeDelayedComponents(); // Ініціалізуємо компоненти, які залежать від даних

        // Ініціалізація стану автентифікації
        this.authState = this.getAuthState();
        this.updateAuthUI();

        // ┌─────────────────────────────────────────────────────────┐
        // │ 📊 ОНОВЛЕННЯ ВІДОБРАЖЕННЯ                              │
        // └─────────────────────────────────────────────────────────┘
        this.updateAllMetrics();
        this.uiManager.showSection('dashboard');
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎯 РОЗДІЛ: ОСНОВНІ МЕТОДИ (ПРОКСІЇ ДО МЕНЕДЖЕРІВ)     █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // ВІДКЛАДЕНА ІНІЦІАЛІЗАЦІЯ КОМПОНЕНТІВ
    initializeDelayedComponents() {
        this.populateAccountsSelect();
        this.populateStrategiesSelect();
        this.populateEntryModelsSelect();
        this.loadAndApplyProfileSettings();
    }

    setupEventListeners() {
        console.log('Setting up event listeners...');

        // ┌─────────────────────────────────────────────────────────┐
        // │ 🧭 НАВІГАЦІЯ                                            │
        // └─────────────────────────────────────────────────────────┘
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                if (section) {
                    this.uiManager.showSection(section);
                }
            });
        });

        // ┌─────────────────────────────────────────────────────────┐
        // │ 📝 ФОРМИ                                               │
        // └─────────────────────────────────────────────────────────┘
        this.setupFormListeners();

        // ┌─────────────────────────────────────────────────────────┐
        // │ 🎯 КНОПКИ ТА ІНТЕРАКТИВНІ ЕЛЕМЕНТИ                     │
        // └─────────────────────────────────────────────────────────┘
        this.setupButtonListeners();

        // ┌─────────────────────────────────────────────────────────┐
        // │ ⌨️ ГЛОБАЛЬНІ ПОДІЇ                                     │
        // └─────────────────────────────────────────────────────────┘
        this.setupGlobalListeners();

        console.log('Event listeners setup completed');
    }

    // НАЛАШТУВАННЯ ОБРОБНИКІВ ФОРМ
    setupFormListeners() {
        // Форма додавання трейду
        const tradeForm = document.getElementById('add-trade-form');
        if (tradeForm) {
            tradeForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.tradeManager.saveTrade(this.collectTradeFormData());
            });
        }

        // Форма додавання акаунту
        const accountForm = document.getElementById('add-account-form');
        if (accountForm) {
            accountForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const accountData = this.collectAccountFormData();
                if (this.accountManager.currentEditAccountId) {
                    // Если есть ID для редактирования, обновляем аккаунт
                    this.accountManager.updateAccount(this.accountManager.currentEditAccountId, accountData);
                } else {
                    // Иначе, создаем новый
                    this.accountManager.addAccount(accountData);
                }
            });
        }

        // Форма додавання стратегії
        const strategyForm = document.getElementById('add-strategy-form');
        if (strategyForm) {
            strategyForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.strategyManager.addStrategy(this.collectStrategyFormData());
            });
        }

        // Форма додавання сетапу
        const setupForm = document.getElementById('add-setup-form');
        if (setupForm) {
            setupForm.addEventListener('submit', (e) => {
                e.preventDefault();
                // Викликаємо метод addSetup з StrategyManager, який поки що є заглушкою
                this.strategyManager.addSetup();
            });
        }

        // Форма аутентификации
        const authForm = document.getElementById('auth-form');
        if (authForm) {
            authForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAuthFormSubmit();
            });
        }
        // Додаткові форми...
    }

    // НАЛАШТУВАННЯ ОБРОБНИКІВ КНОПОК
    setupButtonListeners() {
        // Кнопка перемикання sidebar
        const sidebarToggle = document.querySelector('.sidebar-toggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                this.uiManager.toggleSidebar();
            });
        }

        // Кнопка додавання трейду
        const addTradeBtn = document.querySelector('.btn-add-trade');
        if (addTradeBtn) {
            addTradeBtn.addEventListener('click', () => { // Можна залишити, бо це проксі до UI
                this.showAddTradeModal();
            });
        }

        // Кнопка додавання акаунту
        const addAccountBtn = document.querySelector('.btn-add-account');
        if (addAccountBtn) {
            addAccountBtn.addEventListener('click', () => { // Можна залишити, бо це проксі до UI
                this.showAddAccountModal();
            });
        }

        // Переключатель на форме входа/регистрации
        document.body.addEventListener('click', (e) => {
            if (e.target && e.target.id === 'auth-toggle-link') {
                e.preventDefault();
                this.uiManager.toggleAuthMode();
            }
        });

        // Додаткові кнопки...
    }

    // НАЛАШТУВАННЯ ГЛОБАЛЬНИХ ОБРОБНИКІВ
    setupGlobalListeners() {
        // Закриття модальних вікон при ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.uiManager.closeAllModals();
                this.uiManager.closeProfileMenu();
            }
        });

        // Paste для скріншотів
        this.uiManager.setupImagePasteListener();
    }

    // === 📊 ОНОВЛЕННЯ ДАНИХ ===
    updateAllMetrics() {
        this.tradeManager.calculateTradeStats();
        this.accountManager.calculateOverallStats();
        this.updateDashboardWidgets();
    }

    updateAllTables() {
        this.updateTradesTable('recent-trades-body', 5);
        this.updateTradesTable('all-trades-body');
        setTimeout(() => this.applyColumnWidthsToAllTables(), 0);
    }

    // === 📝 ФОРМИ ТА МОДАЛЬНІ ВІКНА ===
    showAddTradeModal() {
        this.uiManager.showModal('add-trade-modal');
    }

    showAddSetupModal() {
        this.uiManager.showModal('add-setup-modal');
    }

    showAddAccountModal() {
        this.uiManager.showModal('add-account-modal');
    }

    showAddPayoutModal() {
        this.uiManager.showModal('add-payout-modal');
    }

    showAddStrategyModal() {
        this.uiManager.showModal('add-strategy-modal');
    }

    closeModal(modalId) {
        this.uiManager.closeModal(modalId);
    }

    closeAllModals() {
        this.uiManager.closeAllModals();
    }

    // === ➕ ДОДАВАННЯ ДАНИХ ===

    // === ✏️ РЕДАГУВАННЯ ДАНИХ ===
    editTrade(tradeId) {
        this.tradeManager.editTrade(tradeId);
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📋 РОЗДІЛ: UTILITY МЕТОДИ                             █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    editAccount(accountId) {
        this.accountManager.editAccount(accountId);
    }

    editStrategy(strategyId) {
        const strategy = this.strategyManager.findStrategyById(strategyId);
        if (!strategy) {
            this.showNotification('Strategy not found', 'error');
            return;
        }

        this.strategyManager.currentEditStrategyId = strategyId;

        // Populate the modal form
        document.getElementById('strategy-name').value = strategy.name;
        document.getElementById('strategy-type').value = strategy.type;
        document.getElementById('strategy-context').value = strategy.contextContent || '';
        document.getElementById('strategy-entry').value = strategy.entryContent || '';

        // Update modal title and show it
        this.uiManager.setModalTitle('add-strategy-modal', '<i data-lucide="edit"></i> Edit Strategy');
        this.showAddStrategyModal();
    }

    // === 🗑️ ВИДАЛЕННЯ ДАНИХ ===
    deleteTrade(tradeId) {
        this.tradeManager.deleteTrade(tradeId);
    }

    deleteAccount(accountId) {
        this.accountManager.deleteAccount(accountId);
    }

    deleteStrategy(strategyId) {
        this.strategyManager.deleteStrategy(strategyId);
    }

    // === 🎯 ВІДОБРАЖЕННЯ ===
    showSection(sectionName) {
        this.uiManager.showSection(sectionName);
    }

    showNotification(message, type = 'info') {
        this.uiManager.showNotification(message, type);
    }

    updateElement(elementId, value) {
        this.uiManager.updateElement(elementId, value);
    }

    // === 💾 РОБОТА З ДАНИМИ ===
    saveAllData() {
        return this.dataManager.saveAllData();
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🔄 РОЗДІЛ: GETTERS ДЛЯ ЗВОРОТНОЇ СУМІСНОСТІ           █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    loadAllData() {
        return this.dataManager.loadAllData();
    }

    exportAllData() {
        return this.dataManager.exportAllData();
    }

    // === 🛠️ ДОПОМІЖНІ МЕТОДИ ===
    generateId() {
        return 'id-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    }

    formatDate(dateStr) {
        return this.uiManager.formatDate(dateStr);
    }

    formatDateShort(dateStr) {
        return this.uiManager.formatDateShort(dateStr);
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎪 РОЗДІЛ: МЕТОДИ ДЛЯ UI КОМПОНЕНТІВ                  █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // === 🏦 АКАУНТИ ===
    populateAccountsSelect() {
        const selects = document.querySelectorAll('.trade-account-select');
        selects.forEach(select => {
            this.accountManager.populateAccountsSelect(select);
        });
    }

    updateAccountsDisplay() {
        this.accountManager.updateAccountsDisplay();
    }

    setGlobalTimePeriod(period) {
        this.globalTimePeriod = period;
        console.log(`Global time period set to: ${period}`);

        // Update active button
        document.querySelectorAll('.compact-time-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.period === period);
        });

        if (period === 'custom') {
            this.uiManager.showCustomDatePicker();
        } else {
            this.updateAllMetrics();
            this.updateAllTables();
        }
    }

    toggleAccountFilter() {
        // This can be expanded in UIManager if more complex logic is needed
        const dropdown = document.getElementById('account-filter-dropdown');
        if (dropdown) dropdown.classList.toggle('show');
    }

    selectAllAccounts() {
        this.selectedAccountIds = null; // null signifies all accounts
        this.updateAccountsDisplay();
        this.updateAllMetrics();
        this.updateAllTables();
    }

    deselectAllAccounts() {
        this.selectedAccountIds = []; // An empty array signifies no accounts
        this.updateAccountsDisplay();
        this.updateAllMetrics();
        this.updateAllTables();
    }

    // === 📋 СТРАТЕГІЇ ===
    populateStrategiesSelect() {
        const selects = document.querySelectorAll('.strategy-select');
        selects.forEach(select => {
            this.strategyManager.populateStrategiesSelect(select);
        });
    }

    populateEntryModelsSelect() {
        const selects = document.querySelectorAll('.entry-model-select');
        selects.forEach(select => {
            this.strategyManager.populateEntryModelsSelect(select);
        });
    }

    updateStrategiesDisplay() {
        this.strategyManager.updateStrategiesDisplay();
    }

    renderSetupsGrid() {
        this.strategyManager.renderSetupsGrid();
    }

    updateEntryModelsDisplay() {
        this.strategyManager.renderEntryModelsGrid();
    }

    // === 💱 ВАЛЮТНІ ПАРИ ===
    updatePairButtons() {
        // Оновлення кнопок вибору валютних пар
        const addBtn = document.getElementById('trade-symbol-btn');
        const editBtn = document.getElementById('edit-trade-symbol-btn');
        // Логіка оновлення...
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  📊 РОЗДІЛ: МЕТОДИ ДЛЯ ФІЛЬТРАЦІЇ                      █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    getFilteredTrades() {
        return this.tradeManager.getFilteredTrades();
    }

    getSelectedAccountIds() {
        return this.selectedAccountIds;
    }

    getFilteredAccounts() {
        return this.accountManager.getFilteredAccounts();
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🎨 РОЗДІЛ: МЕТОДИ ДЛЯ ТАБЛИЦЬ                         █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    updateTradesTable(tableBodyId, limit = null) {
        const tbody = document.getElementById(tableBodyId);
        if (!tbody) return;

        let trades = [...this.getFilteredTrades()].sort((a, b) => {
            const dateA = new Date(a.date || a.entryDate);
            const dateB = new Date(b.date || b.entryDate);
            return dateB.getTime() - dateA.getTime();
        });

        if (limit) trades = trades.slice(0, limit);

        if (trades.length === 0) {
            tbody.innerHTML = this.getEmptyTableHTML(tableBodyId);
            return;
        }

        if (tableBodyId === 'all-trades-body') {
            this.renderGroupedTradesTable(tbody, trades);
        } else {
            this.renderSimpleTradesTable(tbody, trades, limit);
        }
    }

    renderSimpleTradesTable(tbody, trades, limit) {
        // Спрощена версія рендерингу таблиці
        tbody.innerHTML = trades.map((trade, index) => {
            const pnl = trade.pnl || 0;
            const pnlClass = pnl >= 0 ? 'pnl-positive' : 'pnl-negative';

            return `
                <tr onclick="window.app.editTrade(${trade.id})" style="cursor: pointer;">
                    <td>${this.formatDate(trade.date || trade.entryDate)}</td>
                    <td>${trade.symbol || '-'}</td>
                    <td class="${pnlClass}">$${pnl.toFixed(2)}</td>
                    <td class="${pnlClass}">${((pnl / 10000) * 100).toFixed(2)}%</td>
                    <td>${(trade.riskReward || 0).toFixed(2)}</td>
                    <td>
                        <button class="btn-danger" onclick="event.stopPropagation(); window.app.deleteTrade(${trade.id})">
                            <i data-lucide="trash-2"></i>
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        this.uiManager.createIcons();
    }

    getEmptyTableHTML(tableBodyId) {
        const colSpan = tableBodyId === 'recent-trades-body' ? '6' : '13';
        return `
            <tr class="empty-state">
                <td colspan="${colSpan}">
                    <div class="empty-message">
                        <i data-lucide="inbox"></i>
                        <p>No trades found. Start by adding your first trade!</p>
                    </div>
                </td>
            </tr>
        `;
    }

    /*
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🛠️ РОЗДІЛ: ДОДАТКОВІ МЕТОДИ (ДЛЯ СУМІСНОСТІ)         █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // Ці методи залишаються для зворотної сумісності
    // Вони будуть поступово замінені на виклики менеджерів

    calculateStats() {
        return this.tradeManager.calculateTradeStats();
    }

    calculateCapitalMetrics() {
        return this.accountManager.calculateOverallStats();
    }

    updateDashboardWidgets() {
        // Оновлення віджетів дашборду
        const stats = this.calculateStats();
        const capital = this.calculateCapitalMetrics();

        this.updateElement('total-trades', stats.totalTrades.toString());
        this.updateElement('win-rate', `${stats.winRate.toFixed(1)}%`);
        this.updateElement('net-profit', `$${stats.totalPnl.toFixed(2)}`);
        this.updateElement('live-capital', `$${capital.liveCapital.toFixed(2)}`);
    }

    updateTableHeaders() {
        this.uiManager.updateTableHeaders();
    }

    applyColumnWidthsToAllTables() {
        // Застосування ширини колонок до всіх таблиць
        const widths = this.loadColumnWidths();
        const tables = document.querySelectorAll('.trades-table, .data-table');

        tables.forEach(table => {
            const headers = table.querySelectorAll('th[data-column]');
            headers.forEach(th => {
                const columnKey = th.dataset.column;
                if (widths[columnKey]) {
                    th.style.width = `${widths[columnKey]}px`;
                    th.style.minWidth = `${widths[columnKey]}px`;
                }
            });
        });
    }

    // Старі методи для зворотної сумісності
    loadColumnWidths() {
        try {
            const saved = localStorage.getItem('tradingAppColumnWidths');
            return saved ? JSON.parse(saved) : {};
        } catch (error) {
            console.error('Error loading column widths:', error);
            return {};
        }
    }

    saveColumnVisibility() {
        try {
            localStorage.setItem('tradingAppColumnVisibility', JSON.stringify(this.columnVisibility));
        } catch (error) {
            console.error('Error saving column visibility:', error);
        }
    }

    loadColumnVisibility() {
        try {
            const saved = localStorage.getItem('tradingAppColumnVisibility');
            if (saved) {
                const savedVisibility = JSON.parse(saved);
                Object.keys(this.columnVisibility).forEach(key => {
                    if (savedVisibility.hasOwnProperty(key)) {
                        this.columnVisibility[key] = savedVisibility[key];
                    }
                });
            }
        } catch (error) {
            console.error('Error loading column visibility:', error);
        }
    }

    logout() {
        if (confirm('Are you sure you want to log out?')) {
            localStorage.removeItem('traderProAuth');
            this.authState = { isAuthenticated: false };
            this.uiManager.showLogin();
        }
    }

    /*
    █████████████████████████████████████████████████████████
    █                                                         █
    █  🔐 РОЗДІЛ: АВТЕНТИФІКАЦІЯ (ЗАГЛУШКА)                  █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */
    getAuthState() {
        try {
            const saved = localStorage.getItem('traderProAuth');
            return saved ? JSON.parse(saved) : {isAuthenticated: false};
        } catch (error) {
            return {isAuthenticated: false};
        }
    }

    updateAuthUI() {
        const authState = this.getAuthState();
        const loginBtn = document.querySelector('.profile-menu-item[onclick*="showLogin"]');
        const registerBtn = document.querySelector('.profile-menu-item[onclick*="showRegister"]');
        const logoutBtn = document.querySelector('.profile-menu-item.logout');
        const profileSection = document.querySelector('.profile-menu-section');

        if (authState.isAuthenticated) {
            if(loginBtn) loginBtn.style.display = 'none';
            if(registerBtn) registerBtn.style.display = 'none';
            if(logoutBtn) logoutBtn.style.display = 'block';
            if(profileSection) profileSection.style.display = 'block';
        } else {
            if(loginBtn) loginBtn.style.display = 'block';
            if(registerBtn) registerBtn.style.display = 'block';
            if(logoutBtn) logoutBtn.style.display = 'none';
            if(profileSection) profileSection.style.display = 'none';
        }

        if (authState.isAuthenticated && authState.user) {
            const profileName = document.querySelector('.profile-name');
            const profileEmail = document.querySelector('.profile-email');

            if (profileName && authState.user.name) {
                profileName.textContent = authState.user.name;
            }
            if (profileEmail && authState.user.email) {
                profileEmail.textContent = authState.user.email;
            }
        }
    }

    async handleAuthFormSubmit() {
        const isLoginMode = this.uiManager.isLoginMode;
        const email = document.getElementById('auth-email').value;
        const password = document.getElementById('auth-password').value;
        const name = document.getElementById('auth-name').value;

        const endpoint = isLoginMode ? '/api/login' : '/api/register';
        const body = isLoginMode ? { email, password } : { name, email, password };

        try {
            const response = await fetch(`http://localhost:3000${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'An error occurred.');
            }

            if (!isLoginMode) {
                // Автоматический вход после успешной регистрации
                const loginResponse = await fetch(`http://localhost:3000/api/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password }),
                });
                const loginData = await loginResponse.json();
                if (!loginResponse.ok) throw new Error(loginData.message || 'Login failed after registration.');
                this.handleSuccessfulLogin(loginData);
            } else {
                this.handleSuccessfulLogin(data);
            }

        } catch (error) {
            this.uiManager.showAuthNotification(error.message, 'error');
        }
    }

    handleSuccessfulLogin(userData) {
        this.authState = { isAuthenticated: true, user: userData };
        localStorage.setItem('traderProAuth', JSON.stringify(this.authState));
        this.updateAuthUI();
        this.uiManager.closeModal('auth-modal');
        this.uiManager.hideAppBlocker();
        this.showNotification(`Welcome, ${userData.name}!`, 'success');
    }

    /*
    █████████████████████████████████████████████████████████
    █                                                         █
    █  ⚡ РОЗДІЛ: ШВИДКІ МЕТОДИ ДЛЯ UI                        █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // Швидкі методи для HTML атрибутів
    toggleTheme() {
        this.uiManager.toggleTheme();
    }

    toggleProfileMenu() {
        this.uiManager.toggleProfileMenu();
    }

    hideCustomDatePicker() {
        this.uiManager.hideCustomDatePicker();
    }

    applyCustomDateRange() {
        const from = document.getElementById('custom-date-from').value;
        const to = document.getElementById('custom-date-to').value;

        if (from && to) {
            this.customDateRange = { from, to };
            this.globalTimePeriod = 'custom'; // Ensure period is set
            this.updateAllMetrics();
            this.updateAllTables();
            this.hideCustomDatePicker();
        } else {
            this.showNotification('Please select both a start and end date.', 'warning');
        }
    }

    toggleColumnVisibility() {
        this.uiManager.toggleColumnVisibility();
    }

    showActionMenu(button, type, data = {}) {
        // Делегування до відповідного менеджера
        switch (type) {
            case 'trade':
                this.tradeManager.showActionMenu(button, data);
                break;
            case 'account':
                this.accountManager.showAccountActionMenu(button, data.accountId);
                break;
            case 'strategy':
                this.strategyManager.showStrategyActionMenu(button, data.strategyId);
                break;
        }
    }

    /*
    █████████████████████████████████████████████████████████
    █                                                         █
    █  🎉 РОЗДІЛ: ДОДАТКОВІ ФУНКЦІЇ                          █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */

    // Колекція даних форм (спрощена версія)
    collectTradeFormData() {
        // Спрощена версія - в реальності потрібна валідація
        return {
            symbol: document.getElementById('trade-symbol')?.value,
            direction: document.getElementById('trade-direction')?.value,
            strategy: document.getElementById('trade-strategy')?.value,
            // ... інші поля
        };
    }

    collectAccountFormData() {
        return {
            name: document.getElementById('account-name')?.value,
            type: document.getElementById('account-type')?.value,
            startingBalance: document.getElementById('account-balance')?.value,
            status: document.getElementById('account-status')?.value,
            // ... інші поля
        };
    }

    collectStrategyFormData() {
        return {
            name: document.getElementById('strategy-name')?.value,
            type: document.getElementById('strategy-type')?.value,
            // ... інші поля
        };
    }

    // Інші методи для зворотної сумісності
    loadAndApplyProfileSettings() {
        try {
            const settings = JSON.parse(localStorage.getItem('tradingAppProfileSettings') || '{}');
            if (settings.name || settings.email) {
                this.uiManager.updateProfileDisplay({
                    name: settings.name || 'Trading Pro',
                    email: settings.email || 'trader@example.com'
                });
            }
        } catch (error) {
            console.error('Error loading profile settings:', error);
        }
    }

    updatePeriodMetricsVisibility(period) {
        // Логіка оновлення відображення метрик за періодом
        console.log('Updating period metrics for:', period);
    }

    // Заглушки для майбутніх функцій
    waitForChartJS() {
        return new Promise(resolve => {
            if (typeof Chart !== 'undefined') {
                resolve();
            } else {
                setTimeout(() => resolve(), 100);
            }
        });
    }

    initializeCharts() {
        console.log('Initializing charts...');
        // Ініціалізація графіків
    }

    initEquityCurveChart() {
        console.log('Initializing equity curve chart...');
        // Ініціалізація графіка equity curve
    }

    renderCalendar() {
        console.log('Rendering calendar...');
        // Рендеринг календаря
    }

    populateFilters() {
        console.log('Populating filters...');
        // Заповнення фільтрів
    }

    loadSettings() {
        console.log('Loading settings...');
        // Завантаження налаштувань
    }



    saveThemeSetting(theme) {
        this.uiManager.saveThemeSetting(theme);
    }

    // Додаткові методи...
}

// Експорт класу
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TradingApp;
}

// Глобальний доступ для HTML
window.TradingApp = TradingApp;