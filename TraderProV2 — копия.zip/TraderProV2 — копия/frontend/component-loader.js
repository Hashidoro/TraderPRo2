// Dynamic component loader
class ComponentLoader {
    constructor() {
        this.components = {
            'sidebar-container': 'partials/sidebar.html',
            'top-header-container': 'partials/top-header.html',
            'dashboard-section': 'sections/dashboard.html',
            'trades-section': 'sections/trades.html',
            'accounts-section': 'sections/accounts.html',
            'strategies-section': 'sections/strategies.html',
            'calendar-section': 'sections/calendar.html',
            'settings-section': 'sections/settings.html',
            'modals-container': 'modals/modals.html',
            'side-panel-container': 'partials/side-panel.html'
        };
    }

    async loadAllComponents() {
        const loadPromises = Object.entries(this.components).map(([elementId, filePath]) => {
            return this.loadComponent(elementId, filePath);
        });

        await Promise.all(loadPromises);
        console.log('All components loaded successfully');

        // Re-initialize icons after all components are loaded
        if (window.lucide) {
            setTimeout(() => lucide.createIcons(), 100);
        }
    }

    async loadComponent(elementId, filePath) {
        try {
            const response = await fetch(filePath);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const html = await response.text();
            const element = document.getElementById(elementId);
            if (element) {
                element.innerHTML = html;
            } else {
                console.warn(`Element with id '${elementId}' not found`);
            }
            return true;
        } catch (error) {
            console.error(`Error loading ${filePath}:`, error);
            return false;
        }
    }

    async loadComponentContent(elementId, filePath) {
        try {
            const response = await fetch(filePath);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const html = await response.text();
            return html;
        } catch (error) {
            console.error(`Error loading ${filePath}:`, error);
            return '';
        }
    }
}

// Initialize and load components when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    const loader = new ComponentLoader();
    await loader.loadAllComponents();

    // Initialize app if it exists
    if (window.app && typeof window.app.init === 'function') {
        window.app.init();
    }
});