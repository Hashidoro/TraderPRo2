// ===============================================
// 🎯 TRADESCOPE PRO - ГОЛОВНИЙ КЛАС ДОДАТКУ 
// ===============================================

/* 
█████████████████████████████████████████████████████████████
█                                                           █
█  🏢 ОСНОВНИЙ КЛАС ДОДАТКУ ДЛЯ УПРАВЛІННЯ ТОРГІВЛЕЮ        █
█                                                           █
█████████████████████████████████████████████████████████████
*/

class TradingApp {
    constructor() {
        // ═══════════════════════════════════════════════════════════
        // 📊 РОЗДІЛ: ОСНОВНІ ДАНІ ДОДАТКУ
        // ═══════════════════════════════════════════════════════════
        this.trades = [];           // 💰 Масив всіх трейдів (угод)
        this.accounts = [];         // 🏦 Масив всіх торгових рахунків

        this.strategies = [];       // 📋 Масив торгових стратегій
        this.setups = [];           // 🎯 Масив торгових сетапів
        this.entryModels = [];      // 🎯 Масив моделей входу (Entry Models)

        // ═══════════════════════════════════════════════════════════
        // ⚙️ РОЗДІЛ: НАЛАШТУВАННЯ ТА СТАН ДОДАТКУ
        // ═══════════════════════════════════════════════════════════
        this.currentDate = new Date();              // 📅 Поточна дата
        this.charts = {};                           // 📈 Об'єкт для зберігання графіків
        this.selectedAccountIds = null;             // 🎯 ID вибраних рахунків для фільтрації
        this.favoritePairs = [];                    // ⭐ Улюблені валютні пари
        this.globalTimePeriod = '1d';               // 🕐 Глобальний період фільтрації (1d, 1w, 1m, all, custom)
        this.customDateRange = {                    // 📆 Кастомний діапазон дат
            from: null,
            to: null
        };
        
        // 👁️ Видимість колонок таблиці трейдів
        this.columnVisibility = {
            tradeNumber: true,
            date: true,
            pair: true,
            direction: true,
            result: true,
            profitDollar: true,
            profitPercent: true,
            rr: true,
            risk: true,
            strategy: true,
            setup: true,
            session: true,
            notes: true,
            account: true
        };

        // ═══════════════════════════════════════════════════════════
        // 🚀 РОЗДІЛ: ЗАПУСК ІНІЦІАЛІЗАЦІЇ ДОДАТКУ
        // ═══════════════════════════════════════════════════════════
        this.init();
    }

    /* 
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🆔 РОЗДІЛ: ГЕНЕРАЦІЯ УНІКАЛЬНИХ ID                     █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */
    generateId() {
        return 'trade-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    }

    /* 
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🔧 РОЗДІЛ: ІНІЦІАЛІЗАЦІЯ ДОДАТКУ                      █
    █  Завантажує дані, налаштовує інтерфейс та графіки      █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */
    init() {
        console.log('Initializing TradingApp...');

        // ┌─────────────────────────────────────────────────────────┐
        // │ 📥 ПІДРОЗДІЛ: ЗАВАНТАЖЕННЯ ЗБЕРЕЖЕНИХ ДАНИХ             │
        // └─────────────────────────────────────────────────────────┘
        this.loadData();                    // 💰 Завантажити трейди з LocalStorage
        this.loadAccounts();               // 🏦 Завантажити рахунки з LocalStorage
        this.loadPayouts();               // 💰 Завантажити виплати з LocalStorage

        this.loadStrategies();             // 📋 Завантажити стратегії з LocalStorage
        this.loadSetups();                 // 🎯 Завантажити сетапи з LocalStorage
        this.loadEntryModels();            // 🎯 Завантажити моделі входу з LocalStorage
        this.loadFavoritePairs();          // ⭐ Завантажити улюблені пари з LocalStorage
        this.loadColumnVisibility();       // 👁️ Завантажити видимість колонок з LocalStorage

        // ┌─────────────────────────────────────────────────────────┐
        // │ 🎨 ПІДРОЗДІЛ: НАЛАШТУВАННЯ ІНТЕРФЕЙСУ                   │
        // └─────────────────────────────────────────────────────────┘
        this.setupEventListeners();        // 🖱️ Налаштувати обробники подій (кліки, зміни)
        this.updateAllMetrics();           // 📊 Оновити всі метрики та розрахунки
        this.updateAccountsDisplay();      // 🏦 Оновити відображення рахунків
        this.updatePayoutsDisplay();       // 💰 Оновити відображення виплат
        this.updateAllTables();            // 📋 Оновити всі таблиці з даними
        this.updateTableHeaders();         // 👁️ Оновити заголовки колонок таблиці
        this.renderCalendar();             // 📅 Відрендерити календар трейдів
        this.populateFilters();            // 🔍 Заповнити фільтри для пошуку
        this.loadSettings();               // ⚙️ Завантажити користувацькі налаштування
        this.loadThemeSetting();           // 🎨 Завантажити налаштування теми

        // Встановлення поточної дати
        const dateInput = document.getElementById('trade-entry-date');
        if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }

        // Ініціалізація стану автентифікації
        this.authState = this.getAuthState();
        this.updateAuthUI();

        // Ініціалізація графіків після завантаження Chart.js
        this.waitForChartJS().then(() => {
            this.initializeCharts();
        });

        // Ініціалізуємо equity curve chart один раз
        this.initEquityCurveChart();

        // Ініціалізація селекту акаунтів після короткої затримки
        setTimeout(() => {
            this.populateAccountsSelect();
            this.populateStrategiesSelect();
            this.populateEntryModelsSelect(); // ініціалізація Entry Models
            this.updatePairButtons(); // Initialize pair buttons

            this.updateStrategiesDisplay(); // Initialize strategies display
            this.renderSetupsGrid();        // Initialize setups display

            // Ensure Entry Models are populated properly
            this.updateEntryModelsDisplay();

            // Load and apply profile settings
            this.loadAndApplyProfileSettings();

            // Ініціалізація відображення метрик залежно від початкового періоду
            this.updatePeriodMetricsVisibility(this.globalTimePeriod);
        }, 100);
    }

    /* 
    ███████████████████████████████████████████████████████████
    █                                                         █
    █  🖱️ РОЗДІЛ: НАЛАШТУВАННЯ ОБРОБНИКІВ ПОДІЙ              █
    █  Встановлює всі кліки, зміни та взаємодії              █
    █                                                         █
    ███████████████████████████████████████████████████████████
    */
    setupEventListeners() {
        // ┌─────────────────────────────────────────────────────────┐
        // │ 📋 ПІДРОЗДІЛ: МЕНЮ ДІЙ (3-крапкові меню)               │
        // └─────────────────────────────────────────────────────────┘
        this.setupActionMenus();

        // ┌─────────────────────────────────────────────────────────┐
        // │ 💱 ПІДРОЗДІЛ: КНОПКИ ВИБОРУ ВАЛЮТНИХ ПАР               │
        // └─────────────────────────────────────────────────────────┘
        this.setupPairSelectButtons();

        // ┌─────────────────────────────────────────────────────────┐
        // │ 📑 ПІДРОЗДІЛ: ВКЛАДКИ МОДАЛЬНОГО ВІКНА СТРАТЕГІЙ        │
        // └─────────────────────────────────────────────────────────┘
        this.setupStrategyModalTabs();

        // 🔍 ЗАКРИТТЯ ФІЛЬТРА АКАУНТІВ ПРИ КЛІКУ ПОЗА НИМ
        document.addEventListener('click', (e) => {
            const accountFilterContainer = document.querySelector('.account-filter-container');
            const accountFilterDropdown = document.getElementById('account-filter-dropdown');
            const accountFilterToggle = document.querySelector('.account-filter-toggle');

            if (accountFilterContainer && accountFilterDropdown && !accountFilterContainer.contains(e.target)) {
                accountFilterDropdown.classList.remove('show');
                if (accountFilterToggle) {
                    accountFilterToggle.classList.remove('active');
                }
            }

            // 👁️ ЗАКРИТТЯ COLUMN VISIBILITY DROPDOWN ПРИ КЛІКУ ПОЗА НИМ
            const columnWrappers = document.querySelectorAll('.section-btn-wrapper');
            columnWrappers.forEach(wrapper => {
                const dropdown = wrapper.querySelector('.column-visibility-dropdown, .filters-dropdown');
                if (dropdown && !wrapper.contains(e.target)) {
                    dropdown.style.display = 'none';
                }
            });

            // 📅 ЗАКРИТТЯ КАСТОМНОГО КАЛЕНДАРЯ ПРИ КЛІКУ ПОЗА НИМ
            const customDatePicker = document.getElementById('custom-date-picker');
            const globalTimeFilter = document.querySelector('.global-time-filter');
            
            if (customDatePicker && globalTimeFilter && 
                !customDatePicker.contains(e.target) && 
                !globalTimeFilter.contains(e.target) &&
                customDatePicker.style.display === 'block') {
                this.hideCustomDatePicker();
            }
        });

        // ┌─────────────────────────────────────────────────────────┐
        // │ 🧭 ПІДРОЗДІЛ: НАВІГАЦІЯ МІЖ РОЗДІЛАМИ ДОДАТКУ           │
        // │ Дашборд, Трейди, Акаунти, Стратегії, Налаштування      │
        // └─────────────────────────────────────────────────────────┘
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                console.log('Navigation clicked:', section);

                if (section) {
                    this.showSection(section);     // 📱 Показати вибраний розділ
                    this.updateActiveNav(link);    // 🎯 Оновити активний пункт навігації
                } else {
                    console.error('No section data found for nav link:', link);
                }
            });
        });

        // ┌─────────────────────────────────────────────────────────┐
        // │ 💰 ПІДРОЗДІЛ: ФОРМА ДОДАВАННЯ НОВОГО ТРЕЙДУ             │
        // └─────────────────────────────────────────────────────────┘
        const tradeForm = document.getElementById('add-trade-form');
        if (tradeForm) {
            tradeForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addTrade();                    // 💾 Зберегти новий трейд
            });
        }

        // ┌─────────────────────────────────────────────────────────┐
        // │ 🏦 ПІДРОЗДІЛ: ФОРМА ДОДАВАННЯ НОВОГО РАХУНКУ            │
        // └─────────────────────────────────────────────────────────┘
        const accountForm = document.getElementById('add-account-form');
        if (accountForm) {
            console.log('Account form found - setting up new event listener');
            accountForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Account form submitted - new handler');
                this.addAccount();              // 💾 Зберегти новий рахунок
            });
        } else {
            console.log('Account form not found in DOM');
        }

        // ✏️ ФОРМА РЕДАГУВАННЯ ІСНУЮЧОГО РАХУНКУ
        const editAccountForm = document.getElementById('edit-account-form');
        if (editAccountForm) {
            editAccountForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.updateAccount();           // 💾 Оновити дані рахунку
            });
        }

        // ✏️ ФОРМА РЕДАГУВАННЯ ІСНУЮЧОГО ТРЕЙДУ
        const editTradeForm = document.getElementById('edit-trade-form');
        if (editTradeForm) {
            editTradeForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.updateTrade();             // 💾 Оновити дані трейду
            });
        }



        // 💰 ФОРМА ДОДАВАННЯ НОВОЇ ВИПЛАТИ
        const payoutForm = document.getElementById('add-payout-form');
        if (payoutForm) {
            payoutForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addPayout();               // 💾 Зберегти нову виплату
            });
        }

        // 📋 ФОРМА ДОДАВАННЯ НОВОЇ СТРАТЕГІЇ
        const strategyForm = document.getElementById('add-strategy-form');
        if (strategyForm) {
            strategyForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addStrategy();             // 💾 Зберегти нову стратегію
            });
        }

        // 🎯 ФОРМА ДОДАВАННЯ НОВОГО SETUP
        const setupForm = document.getElementById('add-setup-form');
        if (setupForm) {
            setupForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAddSetup(e);         // 💾 Зберегти новий setup
            });
        }

        // 🔐 ФОРМА ЛОГІНУ
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                this.submitLogin(formData);     // 🔐 Обробити логін
            });
        }

        // 📝 ФОРМА РЕЄСТРАЦІЇ
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                this.submitRegister(formData);  // 📝 Обробити реєстрацію
            });
        }

        // 🔑 ФОРМА ВІДНОВЛЕННЯ ПАРОЛЮ
        const forgotPasswordForm = document.getElementById('forgot-password-form');
        if (forgotPasswordForm) {
            forgotPasswordForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                this.submitForgotPassword(formData); // 🔑 Обробити відновлення
            });
        }

        // 👤 ФОРМА НАЛАШТУВАНЬ ПРОФІЛЮ
        const profileSettingsForm = document.getElementById('profile-settings-form');
        if (profileSettingsForm) {
            profileSettingsForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveProfileSettings();    // 💾 Зберегти налаштування профілю
            });
        }

        // 🧮 АВТОМАТИЧНІ РОЗРАХУНКИ ДЛЯ НОВИХ ТРЕЙДІВ
        const profitInput = document.getElementById('trade-pnl');
        const riskInput = document.getElementById('trade-risk');
        const accountInput = document.getElementById('trade-account');
        if (profitInput) {
            profitInput.addEventListener('input', () => {
                this.updateTradeCalculations();    // 📊 Перерахувати R/R при зміні прибутку
            });
        }
        if (riskInput) {
            riskInput.addEventListener('input', () => {
                this.updateTradeCalculations();    // 📊 Перерахувати R/R при зміні ризику
            });
        }
        if (accountInput) {
            accountInput.addEventListener('change', () => {
                this.updateTradeCalculations();    // 📊 Перерахувати при зміні рахунку
            });
        }

        // Result selector for add trade form
        document.querySelectorAll('.result-option').forEach(option => {
            option.addEventListener('click', (e) => {
                const container = e.target.closest('.result-selector');
                const hiddenInput = container.parentElement.querySelector('input[type="hidden"]');
                const result = option.dataset.result;

                // Remove selected class from all options in this container
                container.querySelectorAll('.result-option').forEach(opt => {
                    opt.classList.remove('selected');
                });

                // Add selected class to clicked option
                option.classList.add('selected');

                // Update hidden input value
                if (hiddenInput) {
                    hiddenInput.value = result;
                }
            });
        });

        // Result selector for edit trade form
        document.addEventListener('click', (e) => {
            if (e.target.closest('.result-option') && e.target.closest('#edit-trade-modal')) {
                const option = e.target.closest('.result-option');
                const container = option.closest('.result-selector');
                const hiddenInput = container.parentElement.querySelector('input[type="hidden"]');
                const result = option.dataset.result;

                // Remove selected class from all options in this container
                container.querySelectorAll('.result-option').forEach(opt => {
                    opt.classList.remove('selected');
                });

                // Add selected class to clicked option
                option.classList.add('selected');

                // Update hidden input value
                if (hiddenInput) {
                    hiddenInput.value = result;
                }
            }
        });

        // Авто-розрахунок для редагування трейдів
        const editProfitInput = document.getElementById('edit-trade-pnl');
        const editRiskInput = document.getElementById('edit-trade-risk');
        const editAccountInput = document.getElementById('edit-trade-account');
        if (editProfitInput) {
            editProfitInput.addEventListener('input', () => {
                this.updateEditTradeCalculations();
            });
        }
        if (editRiskInput) {
            editRiskInput.addEventListener('input', () => {
                this.updateEditTradeCalculations();
            });
        }
        if (editAccountInput) {
            editAccountInput.addEventListener('change', () => {
                this.updateEditTradeCalculations();
            });
        }

        // Paste для скріншотів
        document.addEventListener('paste', (e) => {
            const addModal = document.getElementById('add-trade-modal');
            const editModal = document.getElementById('edit-trade-modal');
            const editSubtradeModal = document.getElementById('edit-subtrade-modal');
            const strategyModal = document.getElementById('add-strategy-modal');

            if ((addModal && addModal.classList.contains('show')) || 
                (editModal && editModal.classList.contains('show')) ||
                (editSubtradeModal && editSubtradeModal.classList.contains('show')) ||
                (strategyModal && strategyModal.classList.contains('show'))) {

                const items = e.clipboardData.items;
                for (let item of items) {
                    if (item.type.indexOf('image') !== -1) {
                        const file = item.getAsFile();
                        if (editModal && editModal.classList.contains('show')) {
                            this.handleEditScreenshotFile(file);
                        } else if (editSubtradeModal && editSubtradeModal.classList.contains('show')) {
                            this.handleEditSubtradeScreenshotFile(file);
                        } else if (strategyModal && strategyModal.classList.contains('show')) {
                            this.handleStrategyScreenshotFile(file, e.target);
                        } else {
                            this.handleScreenshotFile(file);
                        }
                        e.preventDefault();
                        break;
                    }
                }
            }
        });



        // ФІЛЬТРИ - обробники зміни фільтрів
        const symbolFilter = document.getElementById('symbol-filter');
        const statusFilter = document.getElementById('status-filter');
        const monthFilter = document.getElementById('month-filter');

        if (symbolFilter) symbolFilter.addEventListener('change', () => this.applyFilters());
        if (statusFilter) statusFilter.addEventListener('change', () => this.applyFilters());
        if (monthFilter) monthFilter.addEventListener('change', () => this.applyFilters());

        // КНОПКИ ПЕРІОДІВ - для графіків
        document.querySelectorAll('.time-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.time-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.updateCharts();
            });
        });

        // НАЛАШТУВАННЯ - обробники змін налаштувань
        const startingBalance = document.getElementById('starting-balance');
        const currencySetting = document.getElementById('currency-setting');
        const themeSetting = document.getElementById('theme-setting');
        const compactMode = document.getElementById('compact-mode');

        if (startingBalance) startingBalance.addEventListener('change', () => this.saveSettings());
        if (currencySetting) currencySetting.addEventListener('change', () => this.saveSettings());
        if (themeSetting) themeSetting.addEventListener('change', () => this.saveSettings());
        if (compactMode) compactMode.addEventListener('change', () => this.saveSettings());

        // Закриття модальних вікон при ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal.show').forEach(modal => {
                    modal.classList.remove('show');
                    document.body.style.overflow = '';
                });

                // Також закриваємо profile dropdown
                this.closeProfileMenu();
            }
        });

        // Закриття profile dropdown при кліку поза ним
        document.addEventListener('click', (e) => {
            const profileMenu = document.querySelector('.profile-menu');
            if (profileMenu && !profileMenu.contains(e.target)) {
                this.closeProfileMenu();
            }
        });

        // Setup resizable panels
        this.setupResizablePanels();

        // Setup drag and drop for widgets
        this.setupWidgetDragAndDrop();

        // Setup direction filter buttons
        this.setupDirectionFilters();


    }

    // SETUP PAIR SELECT BUTTONS
    setupPairSelectButtons() {
        // Add trade form pair button
        const addPairBtn = document.getElementById('trade-symbol-btn');
        if (addPairBtn) {
            addPairBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const hiddenInput = document.getElementById('trade-symbol');
                this.showPairSelectionModal(hiddenInput, addPairBtn);
            });
        }

        // Edit trade form pair button
        const editPairBtn = document.getElementById('edit-trade-symbol-btn');
        if (editPairBtn) {
            editPairBtn.addEventListener('click', (e) => {
                e.preventDefault();
                const hiddenInput = document.getElementById('edit-trade-symbol');
                this.showPairSelectionModal(hiddenInput, editPairBtn);
            });
        }
    }

    // ACTION MENUS (3-dot menus)
    setupActionMenus() {
        // Close all action menus when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.action-menu-container')) {
                document.querySelectorAll('.action-menu').forEach(menu => {
                    menu.style.display = 'none';
                });
            }
        });
    }

    // ВІДОБРАЖЕННЯ МЕНЮ ДІЙ (3 крапки)
    showActionMenu(button, type, data = {}) {
        // Читаємо дані з data-атрибутів кнопки, якщо вони є
        if (button.dataset.tradeId) data.tradeId = button.dataset.tradeId;
        if (button.dataset.subtradeId) data.subtradeId = button.dataset.subtradeId;
        if (button.dataset.accountId) data.accountId = button.dataset.accountId;
        if (button.dataset.payoutId) data.payoutId = button.dataset.payoutId;
        if (button.dataset.strategyId) data.strategyId = button.dataset.strategyId;
        if (button.dataset.setupId) data.setupId = button.dataset.setupId;
        if (button.dataset.modelId) data.modelId = button.dataset.modelId;
        
        // Спочатку приховуємо всі інші меню
        document.querySelectorAll('.action-menu').forEach(menu => {
            menu.style.display = 'none';
        });

        // Знаходимо контейнер та меню
        const container = button.closest('.action-menu-container');
        const menu = container.querySelector('.action-menu');

        // Додаємо обробник для приховування меню при відведенні миші
        container.addEventListener('mouseleave', () => {
            setTimeout(() => {
                if (!menu.matches(':hover') && !button.matches(':hover')) {
                    menu.style.display = 'none';
                }
            }, 100);
        });

        // Показуємо/приховуємо опції залежно від типу
        const editOption = menu.querySelector('.action-edit');           // Опція "Редагувати"
        const deleteOption = menu.querySelector('.action-delete');       // Опція "Видалити"
        const addSubtradeOption = menu.querySelector('.action-add-subtrade'); // Опція "Додати субтрейд"

        // Показуємо субтрейд тільки для трейдів
        if (addSubtradeOption) {
            addSubtradeOption.style.display = type === 'trade' ? 'flex' : 'none';
        }

        // Налаштовуємо обробники кліків для редагування
        if (editOption) {
            editOption.onclick = (e) => {
                e.stopPropagation();
                if (type === 'trade') {
                    this.editTrade(data.tradeId);               // Редагувати трейд
                } else if (type === 'subtrade') {
                    this.editSubtrade(data.tradeId, data.subtradeId); // Редагувати субтрейд
                } else if (type === 'account') {
                    this.editAccount(data.accountId);           // Редагувати рахунок
                } else if (type === 'payout') {
                    this.editPayout(data.payoutId);            // Редагувати виплату
                } else if (type === 'strategy') {
                    this.editStrategy(data.strategyId);         // Редагувати стратегію
                }
                menu.style.display = 'none';
            };
        }

        // Налаштовуємо обробники кліків для видалення
        if (deleteOption) {
            deleteOption.onclick = (e) => {
                e.stopPropagation();
                if (type === 'trade') {
                    this.deleteTrade(data.tradeId);             // Видалити трейд
                } else if (type === 'subtrade') {
                    this.deleteSubtrade(data.tradeId, data.subtradeId); // Видалити субтрейд
                } else if (type === 'account') {
                    this.deleteAccount(data.accountId);         // Видалити рахунок
                } else if (type === 'payout') {
                    this.deletePayout(data.payoutId);          // Видалити виплату
                } else if (type === 'strategy') {
                    this.deleteStrategy(data.strategyId);       // Видалити стратегію
                }
                menu.style.display = 'none';
            };
        }

        // Налаштовуємо обробник для додавання субтрейду
        if (addSubtradeOption && type === 'trade') {
            addSubtradeOption.onclick = (e) => {
                e.stopPropagation();
                this.addSubtrade(data.tradeId);                 // Додати субтрейд
                menu.style.display = 'none';
            };
        }

        // Встановлюємо властивості меню
        menu.style.display = 'block';
        menu.style.pointerEvents = 'auto';

        // Для всіх типів стратегій та акаунтів використовуємо відносне позиціонування
        if (type === 'account' || type === 'strategy') {
            menu.style.position = 'absolute';
            menu.style.top = '100%';
            menu.style.right = '0';
            menu.style.left = 'auto';
            menu.style.marginTop = '4px';
            menu.style.zIndex = '100002';
        } else {
            // Для інших типів (трейди, субтрейди, виплати) використовуємо фіксоване позиціонування
            const buttonRect = button.getBoundingClientRect();
            const menuWidth = 140;
            const menuHeight = type === 'payout' ? 80 : 120;
            const safeDistance = 8;

            if (type === 'payout') {
                // Для виплат позиціонуємо меню зверху та зліва від кнопки
                let left = buttonRect.left - menuWidth + 24;
                let top = buttonRect.top - menuHeight - safeDistance;

                // Перевіряємо, щоб меню не виходило за лівий край
                if (left < 8) {
                    left = 8;
                }

                // Перевіряємо, щоб меню не виходило за правий край
                if (left + menuWidth > window.innerWidth - 8) {
                    left = window.innerWidth - menuWidth - 8;
                }

                // Перевіряємо, щоб меню не виходило за верхній край
                if (top < 8) {
                    top = buttonRect.bottom + safeDistance;
                }

                // Фінальна перевірка - якщо все ще виходить за нижній край
                if (top + menuHeight > window.innerHeight - 8) {
                    top = window.innerHeight - menuHeight - 8;
                }

                menu.style.position = 'fixed';
                menu.style.left = left + 'px';
                menu.style.top = top + 'px';
            } else {
                // Для меню трейдів/субтрейдів
                const safeDistance = 16; // Безпечна відстань

                // Позиціонуємо знизу та зліва від кнопки з безпечною відстанню
                let left = buttonRect.right - menuWidth;
                let top = buttonRect.bottom + safeDistance;

                // Коригуємо горизонтальну позицію якщо меню виходить за правий край
                if (left + menuWidth > window.innerWidth - 8) {
                    left = buttonRect.left - menuWidth + 24;
                }

                // Коригуємо якщо меню виходить за лівий край
                if (left < 8) {
                    left = 8;
                }

                // Коригуємо вертикальну позицію якщо меню виходить за нижній край
                if (top + menuHeight > window.innerHeight - 8) {
                    top = buttonRect.top - menuHeight - safeDistance;
                }

                // Коригуємо якщо меню виходить за верхній край
                if (top < 8) {
                    top = buttonRect.bottom + safeDistance;
                    if (top + menuHeight > window.innerHeight - 8) {
                        top = 8;
                    }
                }

                menu.style.position = 'fixed';
                menu.style.left = left + 'px';
                menu.style.top = top + 'px';
            }
        }

        // Скидаємо інші позиційні властивості для fixed позиціонування
        if (type !== 'account' && type !== 'strategy') {
            menu.style.right = 'auto';
            menu.style.bottom = 'auto';
            menu.style.marginTop = '0';
            menu.style.marginBottom = '0';
        }
    }

    // Add Subtrade functionality
    addSubtrade(tradeId) {
        const trade = this.trades.find(t => t.id === tradeId);
        if (!trade) {
            this.showNotification('Trade not found', 'error');
            return;
        }

        // Initialize subtrades array if it doesn't exist
        if (!trade.subtrades) {
            trade.subtrades = [];
        }

        // Get next subtrade number starting from 1
        const existingSubtrades = this.trades.filter(t => t.parentTradeId === tradeId);
        const nextSubtradeNumber = existingSubtrades.length + 1;

        // Create new subtrade with values inherited from parent trade
        const subtrade = {
            id: Date.now(),
            tradeNumber: nextSubtradeNumber,
            entryDate: trade.entryDate,
            exitDate: trade.exitDate || trade.entryDate,
            symbol: trade.symbol, // Inherit from parent
            direction: trade.direction, // Inherit from parent
            strategy: trade.strategy, // Inherit from parent
            entryTimeframes: trade.entryTimeframes, // Inherit from parent
            result: 'Win', // Default result
            accountId: trade.accountId, // Inherit from parent
            risk: 1, // Default risk
            pnl: 0, // Default profit
            riskReward: 0,
            notes: '',
            screenshot: null,
            parentTradeId: tradeId
        };

        // Add to main trades array as standalone subtrade
        this.trades.push({
            ...subtrade,
            parentTradeId: tradeId,
            date: subtrade.entryDate
        });

        // Save and update
        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateCharts();
        this.renderCalendar();
        this.populateFilters();

        this.showNotification('Subtrade added successfully!', 'success');

        // Open edit modal for the new subtrade
        setTimeout(() => {
            this.editSubtrade(tradeId, subtrade.id);
        }, 100);
    }

    deleteSubtrade(tradeId, subtradeId) {
        console.log('Deleting subtrade:', subtradeId, 'from parent:', tradeId);

        // Remove from main trades array (standalone subtrade entries)
        const beforeCount = this.trades.length;
        this.trades = this.trades.filter(t => t.id !== subtradeId);
        const afterCount = this.trades.length;

        console.log('Removed from main trades array:', beforeCount - afterCount, 'trades');

        // Also remove from parent trade's subtrades array if it exists
        const parentTrade = this.trades.find(t => t.id === tradeId);
        if (parentTrade && parentTrade.subtrades) {
            const beforeSubCount = parentTrade.subtrades.length;
            parentTrade.subtrades = parentTrade.subtrades.filter(st => st.id !== subtradeId);
            const afterSubCount = parentTrade.subtrades.length;

            console.log('Removed from parent subtrades:', beforeSubCount - afterSubCount, 'subtrades');

            // If no more subtrades, remove the subtrades array
            if (parentTrade.subtrades.length === 0) {
                delete parentTrade.subtrades;
                console.log('Removed empty subtrades array from parent');
            }
        }

        // Save and update
        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateCharts();
        this.renderCalendar();
        this.populateFilters();

        this.showNotification('Subtrade deleted successfully!', 'success');
    }

    editSubtradeDirectly(subtradeObj) {
        console.log('Editing subtrade directly:', subtradeObj.id);

        // Set editing IDs
        this.currentEditTradeId = subtradeObj.parentTradeId;
        this.currentEditSubtradeId = subtradeObj.id;

        // Fill form with subtrade data
        document.getElementById('edit-trade-entry-date').value = subtradeObj.entryDate || subtradeObj.date;
        document.getElementById('edit-trade-exit-date').value = subtradeObj.exitDate || subtradeObj.date;

        // Update pair selection
        const symbolInput = document.getElementById('edit-trade-symbol');
        const symbolBtn = document.getElementById('edit-trade-symbol-btn');
        if (symbolInput && symbolBtn) {
            symbolInput.value = subtradeObj.symbol || '';
            const textSpan = symbolBtn.querySelector('.pair-select-text');
            if (textSpan) {
                if (subtradeObj.symbol) {
                    textSpan.textContent = subtradeObj.symbol;
                    textSpan.classList.add('has-value');
                } else {
                    textSpan.textContent = 'Select Trading Pair';
                    textSpan.classList.remove('has-value');
                }
            }
        }

        document.getElementById('edit-trade-direction').value = subtradeObj.direction || '';
        document.getElementById('edit-trade-strategy').value = subtradeObj.strategy || '';
        document.getElementById('edit-trade-entry-timeframes').value = subtradeObj.entryTimeframes || '';
        document.getElementById('edit-trade-risk').value = subtradeObj.risk || 1;
        document.getElementById('edit-trade-pnl').value = subtradeObj.pnl || 0;
        document.getElementById('edit-trade-rr').value = subtradeObj.riskReward || 0;
        document.getElementById('edit-trade-account').value = subtradeObj.accountId || '';
        document.getElementById('edit-trade-notes').value = subtradeObj.notes || '';

        // Set result field
        const resultInput = document.getElementById('edit-trade-result');
        if (resultInput && subtradeObj.result) {
            resultInput.value = subtradeObj.result;
            // Find and select the corresponding result option
            const resultContainer = resultInput.closest('.form-group').querySelector('.result-selector');
            if (resultContainer) {
                resultContainer.querySelectorAll('.result-option').forEach(opt => {
                    opt.classList.remove('selected');
                    if (opt.dataset.result === subtradeObj.result) {
                        opt.classList.add('selected');
                    }
                });
            }
        }

        // Handle screenshot
        const editPreview = document.getElementById('edit-screenshot-preview');
        if (editPreview) {
            editPreview.innerHTML = '';
            if (subtradeObj.screenshot) {
                const screenshotDiv = document.createElement('div');
                screenshotDiv.className = 'screenshot-item';
                screenshotDiv.innerHTML = `
                    <img src="${subtradeObj.screenshot}" onclick="window.app.openScreenshotFullscreen('${subtradeObj.screenshot}')">
                    <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                `;
                editPreview.appendChild(screenshotDiv);
            }
        }

        // Update modal title to indicate it's a subtrade
        const modalTitle = document.querySelector('#edit-trade-modal .modal-header h2');
        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="edit"></i> Edit Subtrade #' + (subtradeObj.tradeNumber || 'N/A');
        }

        // Відразу оновлюємо profit display card з поточними даними
        setTimeout(() => {
            this.updateEditTradeCalculations();
        }, 100);

        // Open edit modal
        this.showEditTradeModal();
    }

    editSubtrade(tradeId, subtradeId) {
        console.log('Editing subtrade:', subtradeId, 'of trade:', tradeId);

        const trade = this.trades.find(t => t.id === tradeId);
        if (!trade || !trade.subtrades) {
            this.showNotification('Trade not found', 'error');
            return;
        }

        const subtrade = trade.subtrades.find(st => st.id === subtradeId);
        if (!subtrade) {
            this.showNotification('Subtrade not found', 'error');
            return;
        }

        // Set editing IDs
        this.currentEditTradeId = tradeId;
        this.currentEditSubtradeId = subtradeId;

        // Fill form with subtrade data (reuse edit trade form)
        document.getElementById('edit-trade-entry-date').value = subtrade.entryDate || subtrade.date;
        document.getElementById('edit-trade-exit-date').value = subtrade.exitDate || subtrade.date;
        document.getElementById('edit-trade-symbol').value = subtrade.symbol || '';
        document.getElementById('edit-trade-direction').value = subtrade.direction || '';
        document.getElementById('edit-trade-strategy').value = subtrade.strategy || '';
        document.getElementById('edit-trade-risk').value = subtrade.risk || 1;
        document.getElementById('edit-trade-pnl').value = subtrade.pnl || 0;
        document.getElementById('edit-trade-rr').value = subtrade.riskReward || 0;
        document.getElementById('edit-trade-account').value = subtrade.accountId || '';
        document.getElementById('edit-trade-notes').value = subtrade.notes || '';

        // Set result field
        const resultInput = document.getElementById('edit-trade-result');
        if (resultInput && subtrade.result) {
            resultInput.value = subtrade.result;
        }

        // Handle screenshot
        const editPreview = document.getElementById('edit-screenshot-preview');
        if (editPreview) {
            editPreview.innerHTML = '';
            if (subtrade.screenshot) {
                const screenshotDiv = document.createElement('div');
                screenshotDiv.className = 'screenshot-item';
                screenshotDiv.innerHTML = `
                    <img src="${subtrade.screenshot}" onclick="window.app.openScreenshotFullscreen('${subtrade.screenshot}')">
                    <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                `;
                editPreview.appendChild(screenshotDiv);
            }
        }

        // Update modal title to indicate it's a subtrade
        const modalTitle = document.querySelector('#edit-trade-modal .modal-header h2');
        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="edit"></i> Edit Subtrade #' + (subtrade.tradeNumber || 'N/A');
        }

        // Open edit modal
        this.showEditTradeModal();
    }

    // ОБРОБКА ФАЙЛУ СКРІНШОТУ
    handleScreenshotFile(file) {
        if (!file || !file.type.startsWith('image/')) return;

        const reader = new FileReader();
        const preview = document.getElementById('screenshot-preview');

        reader.onload = (e) => {
            if (preview) {
                const screenshotDiv = document.createElement('div');
                screenshotDiv.className = 'screenshot-item';
                screenshotDiv.innerHTML = `
                    <img src="${e.target.result}" onclick="window.app.openScreenshotFullscreen('${e.target.result}')">
                    <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                `;
                preview.appendChild(screenshotDiv);
            }
        };
        reader.readAsDataURL(file);
    }

    // ОБРОБКА ФАЙЛУ СКРІНШОТУ ДЛЯ РЕДАГУВАННЯ
    handleEditScreenshotFile(file) {
        if (!file || !file.type.startsWith('image/')) return;

        const reader = new FileReader();
        const preview = document.getElementById('edit-screenshot-preview');

        reader.onload = (e) => {
            if (preview) {
                const screenshotDiv = document.createElement('div');
                screenshotDiv.className = 'screenshot-item';
                screenshotDiv.innerHTML = `
                    <img src="${e.target.result}" onclick="window.app.openScreenshotFullscreen('${e.target.result}')">
                    <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                `;
                preview.appendChild(screenshotDiv);
            }
        };
        reader.readAsDataURL(file);
    }

    // ОБРОБКА ФАЙЛУ СКРІНШОТУ ДЛЯ РЕДАГУВАННЯ СУБТРЕЙДІВ
    handleEditSubtradeScreenshotFile(file) {
        if (!file || !file.type.startsWith('image/')) return;

        const reader = new FileReader();
        const preview = document.getElementById('edit-subtrade-screenshot-preview');

        reader.onload = (e) => {
            if (preview) {
                const screenshotDiv = document.createElement('div');
                screenshotDiv.className = 'screenshot-item';
                screenshotDiv.innerHTML = `
                    <img src="${e.target.result}" onclick="window.app.openScreenshotFullscreen('${e.target.result}')">
                    <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                `;
                preview.appendChild(screenshotDiv);
            }
        };
        reader.readAsDataURL(file);
    }

    // ОБРОБКА ФАЙЛУ СКРІНШОТУ ДЛЯ СТРАТЕГІЙ
    handleStrategyScreenshotFile(file, targetElement) {
        if (!file || !file.type.startsWith('image/')) return;

        // Знаходимо найближчий textarea-with-screenshots контейнер
        const container = targetElement.closest('.textarea-with-screenshots');
        if (!container) return;

        const preview = container.querySelector('.screenshot-preview-simple');
        if (!preview) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const screenshotDiv = document.createElement('div');
            screenshotDiv.className = 'screenshot-item';
            screenshotDiv.innerHTML = `
                <img src="${e.target.result}" onclick="window.app.openScreenshotFullscreen('${e.target.result}')">
                <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
            `;
            preview.appendChild(screenshotDiv);
        };
        reader.readAsDataURL(file);
    }

    // ENTRY MODELS MANAGEMENT
    showEntryModelsManager() {
        this.closeAllModals();
        const modal = document.getElementById('entry-models-manager-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
            this.updateEntryModelsManagerDisplay();
        }
    }

    addEntryModel(event) {
        if (event) event.preventDefault();

        const name = document.getElementById('quick-entry-model-name')?.value;

        if (!name) {
            this.showNotification('Please fill in model name', 'error');
            return;
        }

        if (this.currentEditEntryModelId) {
            // Edit existing model
            const modelIndex = this.entryModels.findIndex(m => m.id === this.currentEditEntryModelId);
            if (modelIndex !== -1) {
                this.entryModels[modelIndex].name = name;
                this.showNotification('Entry model updated successfully!', 'success');
            }
            this.currentEditEntryModelId = null;

            // Reset button
            const button = document.querySelector('.btn-create-entry-model');
            if (button) {
                button.innerHTML = '<i data-lucide="plus"></i> Add';
            }
        } else {
            // Add new model
            const newEntryModel = {
                id: Date.now(),
                name: name,

                createdAt: new Date().toISOString(),
                usageCount: 0
            };

            this.entryModels.push(newEntryModel);
            this.showNotification('Entry model added successfully!', 'success');
        }

        this.saveEntryModels();
        this.populateEntryModelsSelect();
        this.updateEntryModelsManagerDisplay();

        // Reset form
        document.getElementById('quick-entry-model-name').value = '';
    }

    deleteEntryModel(entryModelId) {
        // Знаходимо індекс моделі для видалення
        const modelIndex = this.entryModels.findIndex(model => model.id === entryModelId);
        if (modelIndex === -1) {
            this.showNotification('Entry model not found', 'error');
            return;
        }

        // Видаляємо модель з масиву без підтвердження
        this.entryModels.splice(modelIndex, 1);

        // Зберігаємо оновлені дані
        this.saveEntryModels();

        // Оновлюємо всі пов'язані елементи інтерфейсу
        this.populateEntryModelsSelect();
        this.updateEntryModelsManagerDisplay();

        // Показуємо повідомлення про успіх
        this.showNotification('Entry model deleted successfully!', 'success');
    }

    editEntryModel(entryModelId) {
        const model = this.entryModels.find(m => m.id === entryModelId);
        if (!model) return;

        const nameInput = document.getElementById('quick-entry-model-name');

        if (nameInput) {
            nameInput.value = model.name;

            // Store editing ID for form submission
            this.currentEditEntryModelId = entryModelId;

            // Change form behavior
            const form = document.getElementById('quick-entry-model-form');
            const button = form.querySelector('.btn-create-entry-model');
            if (button) {
                button.innerHTML = '<i data-lucide="save"></i> Save';
            }
        }
    }

    updateEntryModelsManagerDisplay() {
        const container = document.getElementById('entry-models-list');
        const emptyState = document.getElementById('entry-models-empty');

        if (!container || !emptyState) return;

        if (this.entryModels.length === 0) {
            container.style.display = 'none';
            emptyState.style.display = 'flex';
            return;
        }

        container.style.display = 'block';
        emptyState.style.display = 'none';

        let html = '';
        this.entryModels.forEach(model => {
            html += `
                <div class="entry-model-item">
                    <div class="entry-model-header">
                        <div class="entry-model-info">
                            <div class="entry-model-name">${model.name}</div>
                        </div>
                        <div class="entry-model-actions">
                            <button class="btn-entry-model-delete" onclick="event.stopPropagation(); window.app.deleteEntryModel(${model.id});" title="Delete">
                                <i data-lucide="x"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;

        // Re-create lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    // ДОДАВАННЯ ДОДАТКОВОГО ТАЙМФРЕЙМУ
    addTimeframe() {
        const container = document.getElementById('additional-timeframes');
        if (!container) return;

        const timeframeItem = document.createElement('div');
        timeframeItem.className = 'additional-timeframe-item';
        timeframeItem.innerHTML = `
            <select class="additional-timeframe-select">
                <option value="">Select TF</option>
                <option value="1m">1 Minute</option>
                <option value="5m">5 Minutes</option>
                <option value="15m">15 Minutes</option>
                <option value="30m">30 Minutes</option>
                <option value="1h">1 Hour</option>
                <option value="4h">4 Hours</option>
                <option value="1d">Daily</option>
                <option value="1w">Weekly</option>
                <option value="1M">Monthly</option>
            </select>
            <input type="text" class="additional-timeframe-purpose" placeholder="Purpose (e.g., confirmation, trend analysis)">
            <button type="button" class="btn-remove-timeframe" onclick="this.parentElement.remove()" title="Remove">×</button>
        `;
        container.appendChild(timeframeItem);
    }

    // ВІДОБРАЖЕННЯ ВАЛЮТНИХ ПАР З ПРАПОРАМИ
    renderCurrencyPairWithFlags(symbol) {
        if (!symbol) return '<span>-</span>';

        const symbolUpper = symbol.toUpperCase();

        // Special handling for specific symbols
        const specialSymbols = {
            'GER40': 'ger',
            'GER30': 'ger', 
            'US30': 'us3',
            'SPX500': 'spx',
            'NAS100': 'nas',
            'UK100': 'uk1',
            'FRA40': 'fra',
            'JPN225': 'jpn',
            'AUS200': 'aus',
            'HK50': 'hk5',
            'XAUUSD': 'xau|usd',
            'XAGUSD': 'xag|usd',
            'XPTUSD': 'xpt|usd',
            'XPDUSD': 'xpd|usd',
            'USOIL': 'uso|usd',
            'UKOIL': 'uko|usd',
            'NATGAS': 'nat|usd',
            'COPPER': 'cop|usd',
            'BTCUSD': 'btc|usd',
            'ETHUSD': 'eth|usd',
            'LTCUSD': 'ltc|usd',
            'XRPUSD': 'xrp|usd',
            'ADAUSD': 'ada|usd',
            'DOTUSD': 'dot|usd',
            'LINKUSD': 'lin|usd',
            'BNBUSD': 'bnb|usd',
            'SOLUSD': 'sol|usd',
            'MATICUSD': 'mat|usd'
        };

        // Check for special symbols first
        if (specialSymbols[symbolUpper]) {
            const parts = specialSymbols[symbolUpper].split('|');
            if (parts.length === 1) {
                // Single flag (indices, etc)
                return `
                    <div class="currency-pair-flags">
                        <div class="currency-flag ${parts[0]}"></div>
                        <span class="currency-pair-symbol">${symbolUpper}</span>
                    </div>
                `;
            } else {
                // Two flags (commodities/crypto vs USD)
                return `
                    <div class="currency-pair-flags">
                        <div class="currency-flag ${parts[0]}"></div>
                        <div class="currency-flag ${parts[1]}"></div>
                        <span class="currency-pair-symbol">${symbolUpper}</span>
                    </div>
                `;
            }
        }

        // For regular forex pairs (6+ characters)
        if (symbolUpper.length >= 6) {
            const baseCurrency = symbolUpper.substring(0, 3).toLowerCase();
            const quoteCurrency = symbolUpper.substring(3, 6).toLowerCase();

            return `
                <div class="currency-pair-flags">
                    <div class="currency-flag ${baseCurrency}"></div>
                    <div class="currency-flag ${quoteCurrency}"></div>
                    <span class="currency-pair-symbol">${symbolUpper}</span>
                </div>
            `;
        }

        // Fallback for unknown symbols
        return `
            <div class="currency-pair-flags">
                <span class="currency-pair-symbol">${symbolUpper}</span>
            </div>
        `;
    }

    // АВТОМАТИЧНІ РОЗРАХУНКИ
    updateTradeCalculations() {
        const profitInput = document.getElementById('trade-pnl');
        const riskInput = document.getElementById('trade-risk');
        const accountSelect = document.getElementById('trade-account');

        if (profitInput && riskInput && accountSelect) {
            const profit = parseFloat(profitInput.value) || 0;
            const riskPercent = parseFloat(riskInput.value) || 0;
            const accountId = parseInt(accountSelect.value);

            // Знаходимо вибраний акаунт
            const selectedAccount = this.accounts.find(acc => acc.id === accountId);
            let accountBalance = 10000; // значення за замовчуванням

            if (selectedAccount) {
                accountBalance = selectedAccount.currentBalance || selectedAccount.startingBalance || 10000;
            }

            // Розрахунок RR на основі ризику у % та прибутку
            const riskAmount = (accountBalance * riskPercent) / 100;
            let rr = 0;

            if (riskAmount > 0) {
                rr = profit / riskAmount; // Зберігаємо знак профіту
                // Якщо це збиткова угода, RR буде від'ємним
                if (profit < 0) {
                    rr = -1; // Для збиткових угод завжди -1 RR
                }
            }

            const rrEl = document.getElementById('trade-rr');
            if (rrEl) rrEl.value = rr.toFixed(2);

            // Оновлюємо відображення прибутку у картці
            this.updateProfitDisplayCard(profit, riskPercent, rr, selectedAccount);
        }
    }

    updateEditTradeCalculations() {
        const profitInput = document.getElementById('edit-trade-pnl');
        const riskInput = document.getElementById('edit-trade-risk');
        const accountSelect = document.getElementById('edit-trade-account');

        if (profitInput && accountSelect) {
            const profit = parseFloat(profitInput.value) || 0;
            const riskPercent = parseFloat(riskInput.value) || 0;
            const accountId = parseInt(accountSelect.value);

            // Знаходимо вибраний акаунт
            const selectedAccount = this.accounts.find(acc => acc.id === accountId);
            let accountBalance = 10000; // значення за замовчуванням

            if (selectedAccount) {
                accountBalance = selectedAccount.currentBalance || selectedAccount.startingBalance || 10000;
            }

            // Розрахунок RR на основі ризику у % та прибутку
            const riskAmount = (accountBalance * riskPercent) / 100;
            let rr = 0;

            if (riskAmount > 0) {
                rr = profit / riskAmount; // Зберігаємо знак профіту
                // Якщо це збиткова угода, RR буде від'ємним
                if (profit < 0) {
                    rr = -1; // Для збиткових угод завжди -1 RR
                }
            }

            const rrEl = document.getElementById('edit-trade-rr');
            if (rrEl) rrEl.value = rr.toFixed(2);

            // Оновлюємо відображення прибутку у картці для edit modal
            this.updateEditProfitDisplayCard(profit, riskPercent, rr, selectedAccount);
        }
    }

    // НАВІГАЦІЯ МІЖ СЕКЦІЯМИ
    showSection(sectionName) {
        console.log('Switching to section:', sectionName);

        // Приховати всі секції (Dashboard, Trades, Accounts, тощо)
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // Показати вибрану секцію
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
            console.log('Section activated:', sectionName);
        } else {
            console.error('Section not found:', sectionName);
        }

        // Видалити активний клас з усіх навігаційних посилань в боковій панелі
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Додати активний клас до поточного посилання
        const activeLink = document.querySelector(`[data-section="${sectionName}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
            console.log('Navigation link activated:', sectionName);
        }

        // Оновити назву розділу в header
        const pageTitle = document.getElementById('page-title');
        if (pageTitle) {
            pageTitle.textContent = this.getSectionTitle(sectionName);
        }

        // Оновити хлібні крихти (breadcrumb) - для зворотної сумісності
        const breadcrumb = document.getElementById('current-section');
        if (breadcrumb) {
            breadcrumb.textContent = this.getSectionTitle(sectionName);
        }

        // Показати/приховати глобальний фільтр часу
        const timeFilter = document.querySelector('.global-time-filter');
        if (timeFilter) {
            // Показувати тільки на dashboard та trades
            if (sectionName === 'dashboard' || sectionName === 'trades') {
                timeFilter.style.display = 'flex';
            } else {
                timeFilter.style.display = 'none';
            }
        }

        // Initialize calendar section when switching to it
        if (sectionName === 'calendar') {
            this.initCalendarSection();
        }

        // Оновити відступи основного контенту
        this.updateMainContentMargin();
    }

    getSectionTitle(sectionName) {
        const titles = {
            'dashboard': 'Dashboard',
            'trades': 'Trade Journal',
            'accounts': 'Account Management',
            'strategies': 'Strategies & Setups',
            'calendar': 'Trading Calendar',
            'settings': 'Settings'
        };
        return titles[sectionName] || 'Dashboard';
    }

    updateActiveNav(activeLink) {
        console.log('Updating active nav for:', activeLink);
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        if (activeLink) {
            activeLink.classList.add('active');
            console.log('Active nav set to:', activeLink.dataset.section);
        }
    }

    // ========================================
    // УПРАВЛІННЯ БІЧНОЮ ПАНЕЛЛЮ
    // ========================================
    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebar && mainContent) {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('sidebar-collapsed');
        }
    }

    updateMainContentMargin() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebar && mainContent) {
            if (sidebar.classList.contains('collapsed')) {
                mainContent.classList.add('sidebar-collapsed');
            } else {
                mainContent.classList.remove('sidebar-collapsed');
            }
        }
    }

    // МОДАЛЬНІ ВІКНА (POPUP ВІКНА)
    showAddTradeModal() {
        console.log('Opening trade side panel for new trade');
        this.openTradePanel('new');
    }

    // Side Panel Functions
    openTradePanel(mode = 'new', tradeData = null) {
        const overlay = document.getElementById('trade-panel-overlay');
        const panel = document.getElementById('trade-side-panel');
        const title = document.getElementById('trade-panel-title');
        const form = document.getElementById('trade-panel-form');

        if (!overlay || !panel) {
            console.error('Trade panel elements not found');
            return;
        }

        // Встановлюємо режим (new або edit)
        this.tradePanelMode = mode;
        this.currentTradeId = tradeData ? tradeData.id : null;

        // Оновлюємо заголовок
        if (title) {
            title.textContent = mode === 'new' ? 'New Trade' : 'Edit Trade';
        }

        // Заповнюємо випадаючі списки
        this.populateTradePanelSelects();

        // Заповнюємо форму даними (якщо редагування)
        if (mode === 'edit' && tradeData) {
            this.fillTradePanelWithData(tradeData);
        } else {
            // Очищуємо форму для нового трейду
            if (form) form.reset();
            // Встановлюємо поточну дату
            const entryDateInput = document.getElementById('panel-entry-date');
            const exitDateInput = document.getElementById('panel-exit-date');
            const today = new Date().toISOString().split('T')[0];
            if (entryDateInput) entryDateInput.value = today;
            if (exitDateInput) exitDateInput.value = today;
        }

        // Показуємо панель
        overlay.classList.add('show');
        panel.classList.add('show');
        document.body.style.overflow = 'hidden';

        // Налаштовуємо paste listener для зображень (тільки один раз)
        if (!this.imagePasteListenerSetup) {
            this.setupImagePasteListener();
            this.imagePasteListenerSetup = true;
        }

        // Налаштовуємо автоматичний розрахунок Profit %
        this.setupProfitPercentCalculation();

        // Ініціалізуємо іконки
        setTimeout(() => lucide.createIcons(), 100);
    }

    closeTradePanel() {
        const overlay = document.getElementById('trade-panel-overlay');
        const panel = document.getElementById('trade-side-panel');
        const form = document.getElementById('trade-panel-form');
        const imagePreview = document.getElementById('panel-images');

        if (overlay) overlay.classList.remove('show');
        if (panel) panel.classList.remove('show');
        if (form) form.reset();
        if (imagePreview) imagePreview.innerHTML = '';
        
        document.body.style.overflow = '';
        this.tradePanelMode = null;
        this.currentTradeId = null;
    }

    setupProfitPercentCalculation() {
        const accountSelect = document.getElementById('panel-account');
        const profitInput = document.getElementById('panel-profit');
        
        if (accountSelect && profitInput) {
            // Видаляємо старі listeners якщо є
            accountSelect.removeEventListener('change', this.calculateProfitPercent.bind(this));
            profitInput.removeEventListener('input', this.calculateProfitPercent.bind(this));
            
            // Додаємо нові listeners
            accountSelect.addEventListener('change', this.calculateProfitPercent.bind(this));
            profitInput.addEventListener('input', this.calculateProfitPercent.bind(this));
            
            // Розраховуємо одразу при відкритті
            this.calculateProfitPercent();
        }
    }

    calculateProfitPercent() {
        const accountSelect = document.getElementById('panel-account');
        const profitInput = document.getElementById('panel-profit');
        const profitPercentInput = document.getElementById('panel-profit-percent');
        
        if (!accountSelect || !profitInput || !profitPercentInput) return;
        
        const selectedAccountId = accountSelect.value;
        const profitValue = parseFloat(profitInput.value);
        
        if (!selectedAccountId || isNaN(profitValue)) {
            profitPercentInput.value = '';
            return;
        }
        
        // Знаходимо обраний акаунт
        const account = this.accounts.find(acc => acc.id === selectedAccountId);
        
        if (!account || !account.balance) {
            profitPercentInput.value = '';
            return;
        }
        
        // Розраховуємо % від балансу
        const profitPercent = (profitValue / account.balance) * 100;
        profitPercentInput.value = profitPercent.toFixed(2) + '%';
    }

    populateTradePanelSelects() {
        // Заповнюємо акаунти
        const accountSelect = document.getElementById('panel-account');
        if (accountSelect) {
            accountSelect.innerHTML = '<option value="">Select Account</option>';
            this.accounts.forEach(account => {
                const option = document.createElement('option');
                option.value = account.id;
                option.textContent = `${account.name} (${account.type})`;
                accountSelect.appendChild(option);
            });
        }

        // Заповнюємо стратегії
        const strategySelect = document.getElementById('panel-strategy');
        if (strategySelect) {
            strategySelect.innerHTML = '<option value="">Select Strategy</option>';
            this.strategies.forEach(strategy => {
                const option = document.createElement('option');
                option.value = strategy.id;
                option.textContent = strategy.name;
                strategySelect.appendChild(option);
            });
        }

        // Заповнюємо entry models з setups
        const entryModelSelect = document.getElementById('panel-entry-model');
        if (entryModelSelect) {
            entryModelSelect.innerHTML = '<option value="">Select Entry Model</option>';
            this.setups.forEach(setup => {
                const option = document.createElement('option');
                option.value = setup.id;  // Зберігаємо ID замість name
                option.textContent = setup.name;
                entryModelSelect.appendChild(option);
            });
        }
    }

    fillTradePanelWithData(trade) {
        console.log('Filling trade panel with data:', trade);
        
        // Заповнюємо тільки ті поля які існують в новій спрощеній формі
        const entryDate = document.getElementById('panel-entry-date');
        const exitDate = document.getElementById('panel-exit-date');
        const account = document.getElementById('panel-account');
        const pair = document.getElementById('panel-pair');
        const direction = document.getElementById('panel-direction');
        const risk = document.getElementById('panel-risk');
        const profit = document.getElementById('panel-profit');
        const profitPercent = document.getElementById('panel-profit-percent');
        const rr = document.getElementById('panel-rr');
        const result = document.getElementById('panel-result');
        const strategy = document.getElementById('panel-strategy');
        const entryModel = document.getElementById('panel-entry-model');
        const session = document.getElementById('panel-session');
        const notes = document.getElementById('panel-notes');
        
        if (entryDate) entryDate.value = trade.entryDate || trade.date || '';
        if (exitDate) exitDate.value = trade.exitDate || trade.date || '';
        if (account) account.value = trade.accountId || '';
        if (pair) pair.value = trade.symbol || '';
        if (direction) direction.value = trade.direction || '';
        if (risk) risk.value = trade.risk || '';
        if (profit) profit.value = trade.profit || trade.pnl || '';
        if (profitPercent) profitPercent.value = trade.profitPercent || '';
        if (rr) rr.value = trade.rr || '';
        if (result) result.value = trade.result || '';
        if (strategy) strategy.value = trade.strategyId || trade.strategy || '';
        
        // Compatibility для entryModel - підтримка як ID так і name
        if (entryModel && trade.entryModelId) {
            // Спробувати знайти по ID
            let found = Array.from(entryModel.options).some(opt => opt.value === trade.entryModelId);
            if (found) {
                entryModel.value = trade.entryModelId;
            } else {
                // Якщо не знайдено по ID, спробувати знайти по name (legacy)
                const setupByName = this.setups.find(s => s.name === trade.entryModelId);
                if (setupByName) {
                    entryModel.value = setupByName.id;
                }
            }
        }
        
        if (session) session.value = trade.session || '';
        if (notes) notes.value = trade.notes || '';
        
        console.log('Trade panel filled successfully');
    }

    saveTradeFromPanel() {
        console.log('=== SAVE TRADE FROM PANEL START ===');
        console.log('Mode:', this.tradePanelMode, 'currentTradeId:', this.currentTradeId);
        
        const form = document.getElementById('trade-panel-form');
        console.log('Form found:', !!form);
        
        if (!form) {
            console.error('Form not found!');
            return;
        }
        
        if (!form.checkValidity()) {
            console.log('Form validation failed');
            form.reportValidity();
            return;
        }

        console.log('Form is valid, collecting data...');

        // Збираємо тільки ті дані які є в новій спрощеній формі
        const profitPercentValue = document.getElementById('panel-profit-percent')?.value || '';
        const strategyValue = document.getElementById('panel-strategy')?.value || '';
        const entryModelValue = document.getElementById('panel-entry-model')?.value || '';
        const sessionValue = document.getElementById('panel-session')?.value || '';
        
        const tradeData = {
            entryDate: document.getElementById('panel-entry-date')?.value || '',
            exitDate: document.getElementById('panel-exit-date')?.value || '',
            accountId: document.getElementById('panel-account')?.value || '',
            symbol: document.getElementById('panel-pair')?.value || '',
            direction: document.getElementById('panel-direction')?.value || '',
            risk: parseFloat(document.getElementById('panel-risk')?.value) || null,
            profit: parseFloat(document.getElementById('panel-profit')?.value) || null,
            pnl: parseFloat(document.getElementById('panel-profit')?.value) || null,
            profitPercent: profitPercentValue, // Зберігаємо як текст з %
            rr: parseFloat(document.getElementById('panel-rr')?.value) || null,
            result: document.getElementById('panel-result')?.value || '',
            strategyId: strategyValue || null,
            entryModelId: entryModelValue || null,
            session: sessionValue || null,
            notes: document.getElementById('panel-notes')?.value || ''
        };

        console.log('Trade data collected:', tradeData);

        if (this.tradePanelMode === 'edit' && this.currentTradeId) {
            // Редагування існуючого трейду
            console.log('MODE: Editing trade with ID:', this.currentTradeId);
            const tradeIndex = this.trades.findIndex(t => t.id === this.currentTradeId);
            console.log('Found trade at index:', tradeIndex);
            
            if (tradeIndex !== -1) {
                console.log('Old trade data:', this.trades[tradeIndex]);
                this.trades[tradeIndex] = { ...this.trades[tradeIndex], ...tradeData };
                console.log('New trade data:', this.trades[tradeIndex]);
                this.saveData();
                this.updateAllMetrics();
                this.updateAllTables();
                this.showNotification('Trade updated successfully', 'success');
                console.log('Trade updated and saved');
            } else {
                console.error('Trade not found for editing');
                this.showNotification('Trade not found', 'error');
            }
        } else {
            // Додавання нового трейду
            console.log('MODE: Adding new trade');
            const newTrade = {
                id: this.generateId(),
                ...tradeData,
                createdAt: new Date().toISOString()
            };
            console.log('New trade object:', newTrade);
            console.log('Current trades count before:', this.trades.length);
            this.trades.push(newTrade);
            console.log('Current trades count after:', this.trades.length);
            this.saveData();
            this.updateAllMetrics();
            this.updateAllTables();
            this.showNotification('Trade added successfully', 'success');
            console.log('Trade added and saved to localStorage');
        }

        console.log('=== SAVE TRADE FROM PANEL END ===');
        this.closeTradePanel();
    }

    handleTradeImageUpload(event) {
        const files = event.target.files;
        if (!files || files.length === 0) return;

        Array.from(files).forEach(file => {
            if (!file.type.startsWith('image/')) return;
            this.addImageToPreview(file);
        });
    }

    addImageToPreview(file) {
        const previewContainer = document.getElementById('panel-images');
        if (!previewContainer) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const imageItem = document.createElement('div');
            imageItem.className = 'side-panel-image-item';
            
            imageItem.innerHTML = `
                <img src="${e.target.result}" alt="Trade screenshot" onclick="window.app.openImageFullscreen('${e.target.result}')">
                <button class="side-panel-image-remove" type="button" onclick="this.parentElement.remove(); lucide.createIcons();">
                    <i data-lucide="x"></i>
                </button>
            `;
            
            previewContainer.appendChild(imageItem);
            lucide.createIcons();
        };
        reader.readAsDataURL(file);
    }

    addImageFromURL(url) {
        const previewContainer = document.getElementById('panel-images');
        if (!previewContainer || !url) return;

        const imageItem = document.createElement('div');
        imageItem.className = 'side-panel-image-item';
        
        imageItem.innerHTML = `
            <img src="${url}" alt="Trade screenshot" onclick="window.app.openImageFullscreen('${url}')" onerror="this.parentElement.remove()">
            <button class="side-panel-image-remove" type="button" onclick="this.parentElement.remove(); lucide.createIcons();">
                <i data-lucide="x"></i>
            </button>
        `;
        
        previewContainer.appendChild(imageItem);
        lucide.createIcons();
    }

    setupImagePasteListener() {
        const urlInput = document.getElementById('panel-image-url');
        if (!urlInput) return;

        // Підтримка Ctrl+V для зображень
        document.addEventListener('paste', (e) => {
            // Перевіряємо чи side panel відкрита
            const panel = document.getElementById('trade-side-panel');
            if (!panel || !panel.classList.contains('show')) return;

            const items = e.clipboardData?.items;
            if (!items) return;

            for (let item of items) {
                if (item.type.indexOf('image') !== -1) {
                    e.preventDefault();
                    const file = item.getAsFile();
                    if (file) {
                        this.addImageToPreview(file);
                    }
                }
            }
        });

        // Підтримка URL для зображень
        urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const url = urlInput.value.trim();
                if (url) {
                    this.addImageFromURL(url);
                    urlInput.value = '';
                }
            }
        });
    }

    openImageFullscreen(imageSrc) {
        // Створюємо fullscreen overlay
        const overlay = document.createElement('div');
        overlay.className = 'fullscreen-image-overlay';
        overlay.innerHTML = `
            <div class="fullscreen-image-container">
                <img src="${imageSrc}" alt="Screenshot">
                <button class="fullscreen-close" onclick="this.parentElement.parentElement.remove()">
                    <i data-lucide="x"></i>
                </button>
            </div>
        `;
        
        // Закриття при кліку на overlay
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
            }
        });
        
        document.body.appendChild(overlay);
        lucide.createIcons();
    }

    showAddAccountModal() {
        console.log('showAddAccountModal called - trying to open ACCOUNT modal');
        // Спочатку закриваємо всі інші модальні вікна
        this.closeAllModals();

        // Знаходимо модальне вікно для додавання рахунку
        const modal = document.getElementById('add-account-modal');
        if (modal) {
            console.log('Account modal element found:', modal);

            // Встановлюємо поточну дату як дату початку за замовчуванням
            const startDateInput = document.getElementById('account-start-date');
            if (startDateInput) {
                startDateInput.value = new Date().toISOString().split('T')[0];
            }

            modal.classList.add('show');                    // Показуємо модальне вікно
            document.body.style.overflow = 'hidden';       // Блокуємо прокрутку фону
            console.log('Account modal opened successfully');
        } else {
            console.error('Account modal not found in DOM');
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');

            // Перевіряємо чи є ще відкриті модальні вікна
            const openModals = document.querySelectorAll('.modal.show');
            if (openModals.length === 0) {
                document.body.style.overflow = '';
            }
        }

        if (modalId === 'add-trade-modal') {
            this.resetTradeForm();
        } else if (modalId === 'add-account-modal') {
            // Очищаємо форму акаунту
            const form = document.getElementById('add-account-form');
            if (form) form.reset();
        } else if (modalId === 'edit-account-modal') {
            // Очищаємо ID редагування
            this.currentEditAccountId = null;
        } else if (modalId === 'edit-trade-modal') {
            // Очищаємо ID редагування трейду
            this.currentEditTradeId = null;

        } else if (modalId === 'add-strategy-modal') {
            this.resetStrategyForm();
        } else if (modalId === 'entry-models-manager-modal') {
            // Reset form and editing state
            const form = document.getElementById('quick-entry-model-form');
            if (form) form.reset();
            this.currentEditEntryModelId = null;
            const button = document.querySelector('.btn-create-entry-model');
            if (button) {
                button.innerHTML = '<i data-lucide="plus"></i> Add';
            }
        } else if (modalId === 'profile-settings-modal') {
            // Reset any email editing states
            const emailInput = document.getElementById('profile-email');
            if (emailInput && !emailInput.hasAttribute('readonly')) {
                emailInput.setAttribute('readonly', true);
                const editBtn = emailInput.parentElement?.querySelector('.btn-secondary');
                if (editBtn) {
                    editBtn.textContent = 'Edit';
                    editBtn.onclick = () => this.editEmail();
                }
            }
        }
    }

    resetPayoutForm() {
        const form = document.getElementById('add-payout-form');
        if (form) form.reset();

        // Reset modal title and button text
        const modalTitle = document.querySelector('#add-payout-modal .modal-header h2');
        const submitButton = document.querySelector('#add-payout-modal button[type="submit"]');

        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="arrow-up-right"></i> Add New Payout';
        }
        if (submitButton) {
            submitButton.innerHTML = '<i data-lucide="save"></i> Add Payout';
        }

        this.currentEditPayoutId = null;
    }

    closeAllModals() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.classList.remove('show');
        });
        document.body.style.overflow = '';
    }

    // СКИДАННЯ ФОРМИ ТРЕЙДУ
    resetTradeForm() {
        const form = document.getElementById('add-trade-form');
        const preview = document.getElementById('screenshot-preview');
        const dateInput = document.getElementById('trade-entry-date');
        const profitCard = document.getElementById('profit-display-card');

        if (form) form.reset();
        if (preview) preview.innerHTML = '';
        if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
        if (profitCard) profitCard.style.display = 'none';
    }

    // SETUP RESIZABLE PANELS - removed vertical resize functionality
    setupResizablePanels() {
        // Vertical resize functionality has been removed
        // Panels now have fixed heights as defined in CSS
    }

    // ========================================
    // PROFILE MENU MANAGEMENT
    // ========================================
    toggleProfileMenu() {
        const dropdown = document.getElementById('profile-dropdown');
        const button = document.querySelector('.profile-btn');

        if (dropdown && button) {
            const isVisible = dropdown.classList.contains('show');

            if (isVisible) {
                this.closeProfileMenu();
            } else {
                this.openProfileMenu();
            }
        }
    }

    openProfileMenu() {
        const dropdown = document.getElementById('profile-dropdown');
        const button = document.querySelector('.profile-btn');

        if (dropdown && button) {
            dropdown.classList.add('show');
            button.classList.add('active');
        }
    }

    closeProfileMenu() {
        const dropdown = document.getElementById('profile-dropdown');
        const button = document.querySelector('.profile-btn');

        if (dropdown && button) {
            dropdown.classList.remove('show');
            button.classList.remove('active');
        }
    }

    // Theme toggle functionality
    toggleTheme() {
        const themeSwitch = document.querySelector('.theme-switch');
        const themeLabel = document.getElementById('theme-label');
        const handleIcon = document.querySelector('.handle-icon');
        const currentTheme = document.documentElement.getAttribute('data-theme');

        if (currentTheme === 'light') {
            // Switch to dark mode
            document.documentElement.setAttribute('data-theme', 'dark');
            if (themeSwitch) themeSwitch.classList.add('active');
            if (themeLabel) themeLabel.textContent = 'Dark Mode';
            if (handleIcon) {
                handleIcon.setAttribute('data-lucide', 'moon');
            }
            this.saveThemeSetting('dark');
        } else {
            // Switch to light mode
            document.documentElement.setAttribute('data-theme', 'light');
            if (themeSwitch) themeSwitch.classList.remove('active');
            if (themeLabel) themeLabel.textContent = 'Light Mode';
            if (handleIcon) {
                handleIcon.setAttribute('data-lucide', 'sun');
            }
            this.saveThemeSetting('light');
        }

        // Update lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    saveThemeSetting(theme) {
        try {
            localStorage.setItem('tradingAppTheme', theme);
        } catch (error) {
            console.error('Error saving theme setting:', error);
        }
    }

    loadThemeSetting() {
        try {
            const savedTheme = localStorage.getItem('tradingAppTheme') || 'dark';
            document.documentElement.setAttribute('data-theme', savedTheme);

            const themeSwitch = document.querySelector('.theme-switch');
            const themeLabel = document.getElementById('theme-label');
            const handleIcon = document.querySelector('.handle-icon');

            if (savedTheme === 'dark') {
                if (themeSwitch) themeSwitch.classList.add('active');
                if (themeLabel) themeLabel.textContent = 'Dark Mode';
                if (handleIcon) handleIcon.setAttribute('data-lucide', 'moon');
            } else {
                if (themeSwitch) themeSwitch.classList.remove('active');
                if (themeLabel) themeLabel.textContent = 'Light Mode';
                if (handleIcon) handleIcon.setAttribute('data-lucide', 'sun');
            }

            // Update lucide icons after setting
            if (typeof lucide !== 'undefined') {
                setTimeout(() => lucide.createIcons(), 100);
            }
        } catch (error) {
            console.error('Error loading theme setting:', error);
        }
    }

    // Profile menu actions
    showProfile() {
        this.closeProfileMenu();
        this.showProfileSettingsModal();
    }

    showProfileSettingsModal() {
        this.closeAllModals();
        const modal = document.getElementById('profile-settings-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';

            // Load current profile settings
            this.loadProfileSettings();
        }
    }

    loadProfileSettings() {
        try {
            const settings = JSON.parse(localStorage.getItem('tradingAppProfileSettings') || '{}');

            // Load saved values or use defaults
            const nameInput = document.getElementById('profile-name');
            const emailInput = document.getElementById('profile-email');
            const timezoneSelect = document.getElementById('profile-timezone');

            if (nameInput) nameInput.value = settings.name || 'Trading Pro';
            if (emailInput) emailInput.value = settings.email || 'trader@example.com';
            if (timezoneSelect) timezoneSelect.value = settings.timezone || 'UTC+02:00';

        } catch (error) {
            console.error('Error loading profile settings:', error);
        }
    }

    saveProfileSettings() {
        try {
            const nameInput = document.getElementById('profile-name');
            const emailInput = document.getElementById('profile-email');
            const timezoneSelect = document.getElementById('profile-timezone');

            const settings = {
                name: nameInput?.value || 'Trading Pro',
                email: emailInput?.value || 'trader@example.com',
                timezone: timezoneSelect?.value || 'UTC+02:00',
                lastUpdated: new Date().toISOString()
            };

            localStorage.setItem('tradingAppProfileSettings', JSON.stringify(settings));

            // Update profile display in header
            this.updateProfileDisplay(settings);

            this.showNotification('Profile settings saved successfully!', 'success');
            this.closeModal('profile-settings-modal');

        } catch (error) {
            console.error('Error saving profile settings:', error);
            this.showNotification('Error saving profile settings', 'error');
        }
    }

    updateProfileDisplay(settings) {
        // Update profile info in dropdown
        const profileName = document.querySelector('.profile-name');
        const profileEmail = document.querySelector('.profile-email');

        if (profileName) profileName.textContent = settings.name;
        if (profileEmail) profileEmail.textContent = settings.email;
    }

    editEmail() {
        const emailInput = document.getElementById('profile-email');
        if (emailInput) {
            emailInput.removeAttribute('readonly');
            emailInput.focus();
            emailInput.select();

            // Change button text
            const editBtn = emailInput.parentElement.querySelector('.btn-secondary');
            if (editBtn) {
                editBtn.textContent = 'Save';
                editBtn.onclick = () => this.saveEmail();
            }
        }
    }

    saveEmail() {
        const emailInput = document.getElementById('profile-email');
        if (emailInput) {
            emailInput.setAttribute('readonly', true);

            // Reset button
            const editBtn = emailInput.parentElement.querySelector('.btn-secondary');
            if (editBtn) {
                editBtn.textContent = 'Edit';
                editBtn.onclick = () => this.editEmail();
            }

            this.showNotification('Email updated successfully!', 'success');
        }
    }

    changePassword() {
        this.showNotification('Password change functionality coming soon!', 'success');
    }

    confirmDeleteAccount() {
        if (confirm('Are you sure you want to delete your account?\n\nThis action cannot be undone, but you can reactivate your account within 7 days.')) {
            if (confirm('This will permanently delete all your trading data, accounts, and strategies.\n\nAre you absolutely sure?')) {
                this.deleteAccount();
            }
        }
    }

    deleteAccount() {
        try {
            // Clear all application data
            localStorage.removeItem('tradingAppTrades');
            localStorage.removeItem('tradingAppAccounts');
            localStorage.removeItem('tradingAppPayouts');
            localStorage.removeItem('tradingAppStrategies');
            localStorage.removeItem('tradingAppEntryModels');
            localStorage.removeItem('tradingAppFavoritePairs');
            localStorage.removeItem('tradingAppProfileSettings');
            localStorage.removeItem('tradingAppTheme');

            // Set deletion timestamp for potential recovery
            localStorage.setItem('tradingAppAccountDeleted', new Date().toISOString());

            this.showNotification('Account deleted successfully. You have 7 days to reactivate.', 'success');

            // Reload the page to reset the application
            setTimeout(() => {
                window.location.reload();
            }, 2000);

        } catch (error) {
            console.error('Error deleting account:', error);
            this.showNotification('Error deleting account', 'error');
        }
    }

    loadAndApplyProfileSettings() {
        try {
            const settings = JSON.parse(localStorage.getItem('tradingAppProfileSettings') || '{}');

            // Apply settings to UI
            if (settings.name || settings.email) {
                this.updateProfileDisplay({
                    name: settings.name || 'Trading Pro',
                    email: settings.email || 'trader@example.com'
                });
            }

        } catch (error) {
            console.error('Error loading profile settings:', error);
        }
    }

    showReferrals() {
        this.closeProfileMenu();
        this.showReferralsModal();
    }

    showReferralsModal() {
        this.closeAllModals();
        const modal = document.getElementById('referrals-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
            this.loadReferralData();
        }
    }

    loadReferralData() {
        // Завантажуємо дані реферальної програми
        try {
            const referralData = JSON.parse(localStorage.getItem('tradingAppReferrals') || '{}');

            // Оновлюємо статистику
            document.getElementById('total-referrals').textContent = referralData.totalReferrals || 0;
            document.getElementById('active-referrals').textContent = referralData.activeReferrals || 0;
            document.getElementById('total-earnings').textContent = '$' + (referralData.totalEarnings || 0).toFixed(2);
            document.getElementById('this-month-earnings').textContent = '$' + (referralData.thisMonthEarnings || 0).toFixed(2);

            // Генеруємо унікальний реферальний код якщо його немає
            if (!referralData.referralCode) {
                referralData.referralCode = this.generateReferralCode();
                localStorage.setItem('tradingAppReferrals', JSON.stringify(referralData));
            }

            // Оновлюємо реферальне посилання
            document.getElementById('referral-link').value = `https://tradepro.app/ref/${referralData.referralCode}`;

            // Оновлюємо прогрес комісійних рівнів
            this.updateCommissionTiers(referralData.activeReferrals || 0);

            // Завантажуємо список рефералів
            this.loadReferralsList(referralData.referrals || []);

        } catch (error) {
            console.error('Error loading referral data:', error);
        }
    }

    generateReferralCode() {
        // Генеруємо унікальний код з 8 символів
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 8; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    updateCommissionTiers(activeReferrals) {
        // Оновлюємо прогрес для Premium рівня (10+ рефералів)
        const premiumProgress = Math.min((activeReferrals / 10) * 100, 100);
        const premiumFill = document.querySelector('.commission-tier:nth-child(2) .progress-fill');
        const premiumText = document.querySelector('.commission-tier:nth-child(2) .progress-text');

        if (premiumFill) premiumFill.style.width = premiumProgress + '%';
        if (premiumText) premiumText.textContent = `${activeReferrals}/10 referrals`;

        // Оновлюємо прогрес для Elite рівня (25+ рефералів)
        const eliteProgress = Math.min((activeReferrals / 25) * 100, 100);
        const eliteFill = document.querySelector('.commission-tier:nth-child(3) .progress-fill');
        const eliteText = document.querySelector('.commission-tier:nth-child(3) .progress-text');

        if (eliteFill) eliteFill.style.width = eliteProgress + '%';
        if (eliteText) eliteText.textContent = `${activeReferrals}/25 referrals`;
    }

    loadReferralsList(referrals) {
        const tableBody = document.getElementById('referrals-table-body');
        if (!tableBody) return;

        if (referrals.length === 0) {
            tableBody.innerHTML = `
                <tr class="empty-state">
                    <td colspan="6">
                        <div class="empty-message">
                            <i data-lucide="users"></i>
                            <p>No referrals yet</p>
                            <small>Start sharing your referral link to earn commissions!</small>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        let html = '';
        referrals.forEach(referral => {
            const statusBadge = this.getReferralStatusBadge(referral.status);
            const planBadge = this.getPlanBadge(referral.plan);

            html += `
                <tr>
                    <td>
                        <div class="user-info">
                            <div class="user-avatar">
                                <i data-lucide="user"></i>
                            </div>
                            <div class="user-details">
                                <div class="user-name">${referral.username || 'User'}</div>
                                <div class="user-email">${referral.email || 'N/A'}</div>
                            </div>
                        </div>
                    </td>
                    <td>${new Date(referral.joinedDate).toLocaleDateString()}</td>
                    <td>${statusBadge}</td>
                    <td>${planBadge}</td>
                    <td>${referral.commissionRate || 20}%</td>
                    <td class="pnl-positive">$${(referral.totalEarned || 0).toFixed(2)}</td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;

        // Re-create lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    getReferralStatusBadge(status) {
        const statusClass = status === 'active' ? 'win' : status === 'pending' ? 'be' : 'lose';
        const statusText = status === 'active' ? 'Active' : status === 'pending' ? 'Pending' : 'Inactive';
        return `<span class="status-badge ${statusClass}">${statusText}</span>`;
    }

    getPlanBadge(plan) {
        const planClass = plan === 'pro' ? 'primary' : plan === 'premium' ? 'warning' : 'secondary';
        const planText = plan === 'pro' ? 'Pro' : plan === 'premium' ? 'Premium' : 'Free';
        return `<span class="account-badge ${planClass}">${planText}</span>`;
    }

    copyReferralLink() {
        const linkInput = document.getElementById('referral-link');
        if (linkInput) {
            linkInput.select();
            linkInput.setSelectionRange(0, 99999); // Для мобільних пристроїв

            try {
                document.execCommand('copy');
                this.showNotification('Referral link copied to clipboard!', 'success');
            } catch (err) {
                // Fallback для сучасних браузерів
                navigator.clipboard.writeText(linkInput.value).then(() => {
                    this.showNotification('Referral link copied to clipboard!', 'success');
                }).catch(() => {
                    this.showNotification('Failed to copy link', 'error');
                });
            }
        }
    }

    showBillingSettings() {
        this.closeProfileMenu();
        this.showNotification('Billing settings coming soon!', 'success');
    }

    showNotificationSettings() {
        this.closeProfileMenu();
        this.showNotification('Notification settings coming soon!', 'success');
    }

    showPrivacySettings() {
        this.closeProfileMenu();
        this.showNotification('Privacy settings coming soon!', 'success');
    }

    showDataExport() {
        this.closeProfileMenu();
        this.exportData();
    }

    showHelp() {
        this.closeProfileMenu();
        this.showNotification('Help & Support coming soon!', 'success');
    }

    showFeedback() {
        this.closeProfileMenu();
        this.showNotification('Feedback form coming soon!', 'success');
    }

    showLogin() {
        this.closeProfileMenu();
        this.closeAllModals();
        const modal = document.getElementById('login-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    showRegister() {
        this.closeProfileMenu();
        this.closeAllModals();
        const modal = document.getElementById('register-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    showForgotPassword() {
        this.closeAllModals();
        const modal = document.getElementById('forgot-password-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    // AUTHENTICATION METHODS
    async submitLogin(formData) {
        try {
            // Підготовка даних для відправки на бекенд
            const loginData = {
                email: formData.get('email'),
                password: formData.get('password'),
                remember: formData.get('remember') === 'on',
                timestamp: new Date().toISOString(),
                userAgent: navigator.userAgent
            };

            console.log('Login data prepared for backend:', loginData);

            // TODO: Відправка на бекенд
            // const response = await fetch('/api/auth/login', {
            //     method: 'POST',
            //     headers: {
            //         'Content-Type': 'application/json',
            //     },
            //     body: JSON.stringify(loginData)
            // });

            // Тимчасова симуляція
            await this.simulateApiCall();

            // Зберігаємо стан автентифікації
            this.setAuthState({
                isAuthenticated: true,
                user: {
                    email: loginData.email,
                    name: 'Trading Pro',
                    loginTime: new Date().toISOString()
                }
            });

            this.showNotification('Successfully logged in!', 'success');
            this.closeModal('login-modal');
            this.updateAuthUI();

        } catch (error) {
            console.error('Login error:', error);
            this.showNotification('Login failed. Please try again.', 'error');
        }
    }

    async submitRegister(formData) {
        try {
            // Перевірка паролів
            const password = formData.get('password');
            const confirmPassword = formData.get('confirm-password');

            if (password !== confirmPassword) {
                this.showNotification('Passwords do not match', 'error');
                return;
            }

            if (password.length < 8) {
                this.showNotification('Password must be at least 8 characters long', 'error');
                return;
            }

            // Підготовка даних для відправки на бекенд
            const registerData = {
                name: formData.get('name'),
                email: formData.get('email'),
                password: password,
                terms: formData.get('terms') === 'on',
                newsletter: formData.get('newsletter') === 'on',
                timestamp: new Date().toISOString(),
                userAgent: navigator.userAgent,
                referralCode: this.getReferralCodeFromUrl()
            };

            console.log('Registration data prepared for backend:', registerData);

            // TODO: Відправка на бекенд
            // const response = await fetch('/api/auth/register', {
            //     method: 'POST',
            //     headers: {
            //         'Content-Type': 'application/json',
            //     },
            //     body: JSON.stringify(registerData)
            // });

            // Тимчасова симуляція
            await this.simulateApiCall();

            this.showNotification('Account created successfully! Please check your email for verification.', 'success');
            this.closeModal('register-modal');

            // Автоматично показуємо логін
            setTimeout(() => {
                this.showLogin();
            }, 1000);

        } catch (error) {
            console.error('Registration error:', error);
            this.showNotification('Registration failed. Please try again.', 'error');
        }
    }

    async submitForgotPassword(formData) {
        try {
            const forgotData = {
                email: formData.get('email'),
                timestamp: new Date().toISOString()
            };

            console.log('Forgot password data prepared for backend:', forgotData);

            // TODO: Відправка на бекенд
            // const response = await fetch('/api/auth/forgot-password', {
            //     method: 'POST',
            //     headers: {
            //         'Content-Type': 'application/json',
            //     },
            //     body: JSON.stringify(forgotData)
            // });

            // Тимчасова симуляція
            await this.simulateApiCall();

            this.showNotification('Password reset link sent to your email!', 'success');
            this.closeModal('forgot-password-modal');

        } catch (error) {
            console.error('Forgot password error:', error);
            this.showNotification('Failed to send reset link. Please try again.', 'error');
        }
    }

    // SOCIAL AUTHENTICATION
    async loginWithGoogle() {
        try {
            console.log('Google login initiated');
            // TODO: Інтеграція з Google OAuth
            // window.location.href = '/api/auth/google';

            await this.simulateApiCall();
            this.showNotification('Google login will be available soon!', 'success');
        } catch (error) {
            console.error('Google login error:', error);
            this.showNotification('Google login failed', 'error');
        }
    }

    async loginWithGithub() {
        try {
            console.log('GitHub login initiated');
            // TODO: Інтеграція з GitHub OAuth
            // window.location.href = '/api/auth/github';

            await this.simulateApiCall();
            this.showNotification('GitHub login will be available soon!', 'success');
        } catch (error) {
            console.error('GitHub login error:', error);
            this.showNotification('GitHub login failed', 'error');
        }
    }

    async registerWithGoogle() {
        await this.loginWithGoogle();
    }

    async registerWithGithub() {
        await this.loginWithGithub();
    }

    // UTILITY METHODS
    togglePassword(inputId) {
        const input = document.getElementById(inputId);
        const button = input?.parentElement?.querySelector('.password-toggle');
        const icon = button?.querySelector('i');

        if (input && button && icon) {
            if (input.type === 'password') {
                input.type = 'text';
                icon.setAttribute('data-lucide', 'eye-off');
            } else {
                input.type = 'password';
                icon.setAttribute('data-lucide', 'eye');
            }

            // Re-create lucide icons
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        }
    }

    getReferralCodeFromUrl() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('ref') || urlParams.get('referral') || null;
    }

    async simulateApiCall() {
        return new Promise(resolve => setTimeout(resolve, 1000));
    }

    setAuthState(authData) {
        try {
            localStorage.setItem('tradingAppAuth', JSON.stringify(authData));
            this.authState = authData;
        } catch (error) {
            console.error('Error saving auth state:', error);
        }
    }

    getAuthState() {
        try {
            const saved = localStorage.getItem('tradingAppAuth');
            return saved ? JSON.parse(saved) : { isAuthenticated: false };
        } catch (error) {
            console.error('Error loading auth state:', error);
            return { isAuthenticated: false };
        }
    }

    updateAuthUI() {
        const authState = this.getAuthState();

        if (authState.isAuthenticated) {
            // Оновлюємо профільне меню
            const profileName = document.querySelector('.profile-name');
            const profileEmail = document.querySelector('.profile-email');

            if (profileName && authState.user?.name) {
                profileName.textContent = authState.user.name;
            }
            if (profileEmail && authState.user?.email) {
                profileEmail.textContent = authState.user.email;
            }

            // Приховуємо кнопки логіну/реєстрації
            const loginBtn = document.querySelector('.profile-menu-item[onclick*="showLogin"]');
            const registerBtn = document.querySelector('.profile-menu-item[onclick*="showRegister"]');

            if (loginBtn) loginBtn.style.display = 'none';
            if (registerBtn) registerBtn.style.display = 'none';
        }
    }

    showTerms() {
        this.showNotification('Terms of Service will be available soon!', 'success');
    }

    showPrivacy() {
        this.showNotification('Privacy Policy will be available soon!', 'success');
    }

    logout() {
        this.closeProfileMenu();
        if (confirm('Are you sure you want to logout?')) {
            this.showNotification('Logout functionality coming soon!', 'success');
        }
    }

    // FAVORITE PAIRS MANAGEMENT
    loadFavoritePairs() {
        try {
            const saved = localStorage.getItem('tradingAppFavoritePairs');
            this.favoritePairs = saved ? JSON.parse(saved) : ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD'];
            console.log('Loaded favorite pairs:', this.favoritePairs);
        } catch (error) {
            console.error('Error loading favorite pairs:', error);
            this.favoritePairs = ['EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD'];
        }
    }

    saveFavoritePairs() {
        try {
            localStorage.setItem('tradingAppFavoritePairs', JSON.stringify(this.favoritePairs));
            console.log('Saved favorite pairs:', this.favoritePairs);
        } catch (error) {
            console.error('Error saving favorite pairs:', error);
        }
    }

    // COLUMN VISIBILITY MANAGEMENT
    loadColumnVisibility() {
        try {
            const saved = localStorage.getItem('tradingAppColumnVisibility');
            if (saved) {
                const savedVisibility = JSON.parse(saved);
                // Merge saved visibility with defaults - keep defaults for new columns
                Object.keys(this.columnVisibility).forEach(key => {
                    if (savedVisibility.hasOwnProperty(key)) {
                        this.columnVisibility[key] = savedVisibility[key];
                    }
                    // If key doesn't exist in saved, keep default value (true)
                });
            }
            console.log('Loaded column visibility:', this.columnVisibility);
        } catch (error) {
            console.error('Error loading column visibility:', error);
        }
    }

    saveColumnVisibility() {
        try {
            localStorage.setItem('tradingAppColumnVisibility', JSON.stringify(this.columnVisibility));
            console.log('Saved column visibility:', this.columnVisibility);
        } catch (error) {
            console.error('Error saving column visibility:', error);
        }
    }

    toggleColumnVisibility() {
        const dropdown = document.getElementById('column-visibility-dropdown');
        const filtersDropdown = document.getElementById('filtersDropdown');

        if (dropdown) {
            const isVisible = dropdown.style.display === 'block';
            
            // Close filters dropdown if open
            if (filtersDropdown) {
                filtersDropdown.style.display = 'none';
            }
            
            dropdown.style.display = isVisible ? 'none' : 'block';

            // Populate column list when opening
            if (!isVisible) {
                this.populateColumnVisibilityList();
            }
        }
    }

    populateColumnVisibilityList() {
        const list = document.getElementById('column-visibility-list');
        if (!list) return;

        const columnLabels = {
            tradeNumber: 'Trade #',
            date: 'Date',
            pair: 'Pair',
            direction: 'Direction',
            result: 'Result',
            profitDollar: 'Profit $',
            profitPercent: 'Profit %',
            rr: 'RR',
            risk: 'Risk',
            strategy: 'Strategy',
            setup: 'Setup',
            session: 'Session',
            notes: 'Notes',
            account: 'Account'
        };

        list.innerHTML = Object.entries(columnLabels).map(([key, label]) => {
            const isChecked = this.columnVisibility[key];
            return `
                <div class="column-visibility-item" onclick="event.stopPropagation(); window.app.toggleColumn('${key}')">
                    <div class="column-visibility-checkbox ${isChecked ? 'checked' : ''}">
                        <i data-lucide="check"></i>
                    </div>
                    <div class="column-visibility-label">${label}</div>
                </div>
            `;
        }).join('');

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    toggleColumn(columnKey) {
        this.columnVisibility[columnKey] = !this.columnVisibility[columnKey];
        this.saveColumnVisibility();
        this.populateColumnVisibilityList();
        this.updateAllTables();
        this.updateTableHeaders();
    }

    selectAllColumns() {
        Object.keys(this.columnVisibility).forEach(key => {
            this.columnVisibility[key] = true;
        });
        this.saveColumnVisibility();
        this.populateColumnVisibilityList();
        this.updateAllTables();
        this.updateTableHeaders();
    }

    deselectAllColumns() {
        Object.keys(this.columnVisibility).forEach(key => {
            this.columnVisibility[key] = false;
        });
        this.saveColumnVisibility();
        this.populateColumnVisibilityList();
        this.updateAllTables();
        this.updateTableHeaders();
    }

    updateTableHeaders() {
        const table = document.querySelector('.trades-table');
        if (!table) return;

        const thead = table.querySelector('thead tr');
        if (!thead) return;

        const headers = ['Trade #', 'Date', 'Pair', 'Direction', 'Result', 'Profit $', 'Profit %', 'RR', 'Risk (%)', 'Strategy', 'Setup', 'Session', 'Notes', 'Account'];
        const columnKeys = ['tradeNumber', 'date', 'pair', 'direction', 'result', 'profitDollar', 'profitPercent', 'rr', 'risk', 'strategy', 'setup', 'session', 'notes', 'account'];

        // Завантажити ширину колонок
        const savedWidths = this.loadColumnWidths();

        thead.innerHTML = headers.map((header, index) => {
            const key = columnKeys[index];
            const isVisible = this.columnVisibility[key];
            const width = savedWidths[key] || 'auto';
            const widthStyle = width !== 'auto' ? `width: ${width}px; min-width: ${width}px;` : '';
            
            return `<th data-column="${key}" style="display: ${isVisible ? 'table-cell' : 'none'}; ${widthStyle}">
                ${header}
                <div class="resize-handle"></div>
            </th>`;
        }).join('');

        // Ініціалізувати resize після рендерингу
        this.initColumnResize();
        // TODO: drag&drop вимагає переробки рендерингу tbody щоб колонки рендерились в збереженому порядку
        // this.initColumnDragDrop();
    }

    // ════════════════════════════════════════════════════════════════
    // ФУНКЦІЇ ДЛЯ РОБОТИ З ШИРИНОЮ ТА ПОРЯДКОМ КОЛОНОК (NOTION-STYLE)
    // ════════════════════════════════════════════════════════════════

    loadColumnWidths() {
        try {
            const saved = localStorage.getItem('tradingAppColumnWidths');
            return saved ? JSON.parse(saved) : {};
        } catch (error) {
            console.error('Error loading column widths:', error);
            return {};
        }
    }

    saveColumnWidths(widths) {
        try {
            localStorage.setItem('tradingAppColumnWidths', JSON.stringify(widths));
        } catch (error) {
            console.error('Error saving column widths:', error);
        }
    }

    loadColumnOrder() {
        try {
            const saved = localStorage.getItem('tradingAppColumnOrder');
            return saved ? JSON.parse(saved) : null;
        } catch (error) {
            console.error('Error loading column order:', error);
            return null;
        }
    }

    saveColumnOrder(order) {
        try {
            localStorage.setItem('tradingAppColumnOrder', JSON.stringify(order));
        } catch (error) {
            console.error('Error saving column order:', error);
        }
    }

    initColumnResize() {
        const table = document.querySelector('.trades-table');
        if (!table) return;

        const resizeHandles = table.querySelectorAll('.resize-handle');
        
        resizeHandles.forEach(handle => {
            handle.addEventListener('mousedown', (e) => {
                e.stopPropagation(); // Не дозволяти drag при resize
                const th = handle.parentElement;
                const startX = e.pageX;
                const startWidth = th.offsetWidth;
                
                th.classList.add('resizing');
                
                const onMouseMove = (e) => {
                    const newWidth = Math.max(80, startWidth + (e.pageX - startX));
                    th.style.width = `${newWidth}px`;
                    th.style.minWidth = `${newWidth}px`;
                };
                
                const onMouseUp = () => {
                    th.classList.remove('resizing');
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    
                    // Зберегти нову ширину
                    const columnKey = th.dataset.column;
                    const newWidth = parseInt(th.style.width);
                    const widths = this.loadColumnWidths();
                    widths[columnKey] = newWidth;
                    this.saveColumnWidths(widths);
                    
                    // Оновити всі таблиці з новою шириною
                    this.applyColumnWidthsToAllTables();
                };
                
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
        });
    }

    applyColumnWidthsToAllTables() {
        const widths = this.loadColumnWidths();
        const tables = document.querySelectorAll('.trades-table, .data-table');
        
        tables.forEach(table => {
            const headers = table.querySelectorAll('th[data-column]');
            
            // Застосувати ширину до заголовків
            headers.forEach(th => {
                const columnKey = th.dataset.column;
                if (widths[columnKey]) {
                    th.style.width = `${widths[columnKey]}px`;
                    th.style.minWidth = `${widths[columnKey]}px`;
                }
            });
            
            // Створити мапу заголовків один раз для таблиці
            const headerMapping = [];
            headers.forEach((header, headerIndex) => {
                headerMapping.push({
                    headerIndex,
                    columnKey: header.dataset.column,
                    isVisible: header.style.display !== 'none'
                });
            });
            
            // Застосувати ширину до td в tbody
            const tbody = table.querySelector('tbody');
            if (tbody) {
                const rows = tbody.querySelectorAll('tr:not(.empty-state)');
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    
                    // Застосувати ширину використовуючи headerIndex
                    // (клітинки в tbody мають ту ж саму позицію що й заголовки)
                    headerMapping.forEach(mapping => {
                        if (mapping.isVisible && widths[mapping.columnKey]) {
                            const cell = cells[mapping.headerIndex];
                            if (cell) {
                                cell.style.width = `${widths[mapping.columnKey]}px`;
                                cell.style.minWidth = `${widths[mapping.columnKey]}px`;
                            }
                        }
                    });
                });
            }
        });
    }

    initColumnDragDrop() {
        const table = document.querySelector('.trades-table');
        if (!table) return;

        const headers = table.querySelectorAll('th[draggable="true"]');
        let draggedElement = null;
        let draggedIndex = null;

        headers.forEach((header, index) => {
            header.addEventListener('dragstart', (e) => {
                draggedElement = header;
                draggedIndex = index;
                header.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/html', header.innerHTML);
            });

            header.addEventListener('dragover', (e) => {
                if (e.preventDefault) {
                    e.preventDefault();
                }
                e.dataTransfer.dropEffect = 'move';
                
                const targetHeader = e.target.closest('th');
                if (targetHeader && targetHeader !== draggedElement) {
                    targetHeader.classList.add('drag-over');
                }
                return false;
            });

            header.addEventListener('dragleave', (e) => {
                const targetHeader = e.target.closest('th');
                if (targetHeader) {
                    targetHeader.classList.remove('drag-over');
                }
            });

            header.addEventListener('drop', (e) => {
                if (e.stopPropagation) {
                    e.stopPropagation();
                }

                const targetHeader = e.target.closest('th');
                if (targetHeader && draggedElement && targetHeader !== draggedElement) {
                    const targetIndex = Array.from(headers).indexOf(targetHeader);
                    
                    // Зберегти новий порядок колонок
                    const currentOrder = this.loadColumnOrder();
                    const columnKeys = ['tradeNumber', 'date', 'pair', 'direction', 'result', 'profitDollar', 'profitPercent', 'rr', 'risk', 'strategy', 'setup', 'notes', 'account'];
                    const order = currentOrder && currentOrder.length === columnKeys.length ? currentOrder : columnKeys;
                    
                    // Переставити елементи
                    const [movedItem] = order.splice(draggedIndex, 1);
                    order.splice(targetIndex, 0, movedItem);
                    
                    this.saveColumnOrder(order);
                    
                    // Оновити таблицю
                    this.updateTableHeaders();
                    this.updateAllTables();
                }

                targetHeader.classList.remove('drag-over');
                return false;
            });

            header.addEventListener('dragend', (e) => {
                header.classList.remove('dragging');
                headers.forEach(h => h.classList.remove('drag-over'));
            });
        });
    }

    toggleFavoritePair(symbol) {
        const index = this.favoritePairs.indexOf(symbol);
        if (index > -1) {
            this.favoritePairs.splice(index, 1);
        } else {
            this.favoritePairs.push(symbol);
        }
        this.saveFavoritePairs();
        this.updatePairButtons();
    }

    updatePairButtons() {
        // Update button displays when favorite pairs change
        const addBtn = document.getElementById('trade-symbol-btn');
        const editBtn = document.getElementById('edit-trade-symbol-btn');

        // No need to update anything specific here since the modal content
        // will be regenerated each time it opens
    }

    showPairSelectionModal(hiddenInput, button) {
        // Close any existing modals first
        const existingModal = document.getElementById('pair-selection-modal');
        if (existingModal) {
            existingModal.remove();
        }

        // Create modal
        const modal = document.createElement('div');
        modal.id = 'pair-selection-modal';
        modal.className = 'pair-selection-modal';
        modal.style.zIndex = '100001'; // Higher than other modals
        modal.innerHTML = `
            <div class="pair-selection-content">
                <div class="pair-selection-header">
                    <h3>Select Trading Pair</h3>
                    <button class="pair-selection-close">
                        <i data-lucide="x"></i>
                    </button>
                </div>
                <div class="pair-selection-body">
                    ${this.generatePairSelectionContent()}
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Add event listeners
        const closeBtn = modal.querySelector('.pair-selection-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.classList.remove('show');
                setTimeout(() => {
                    if (modal.parentNode) {
                        modal.remove();
                    }
                }, 300);
            });
        }

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('show');
                setTimeout(() => {
                    if (modal.parentNode) {
                        modal.remove();
                    }
                }, 300);
            }
        });

        // Setup listeners for modal content
        this.setupPairSelectionListeners(modal, hiddenInput, button);

        // Re-create lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }

        // Update selection state
        const currentValue = hiddenInput.value;
        modal.querySelectorAll('.pair-option').forEach(option => {
            option.classList.remove('selected');
            if (option.dataset.pair === currentValue) {
                option.classList.add('selected');
            }

            // Update favorite state
            option.classList.remove('favorite');
            if (this.favoritePairs.includes(option.dataset.pair)) {
                option.classList.add('favorite');
            }
        });

        // Show modal
        modal.classList.add('show');
    }

    generatePairSelectionContent() {
        // All pairs without favorites filtering
        const allPairs = {
            'Major Pairs': ['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCAD', 'NZDUSD', 'USDCHF'],
            'Minor Pairs': ['EURGBP', 'EURJPY', 'EURCHF', 'EURAUD', 'EURCAD', 'EURNZD', 'GBPJPY', 'GBPCHF', 'GBPAUD', 'GBPCAD', 'GBPNZD', 'AUDJPY', 'AUDCHF', 'AUDCAD', 'AUDNZD', 'CADJPY', 'CADCHF', 'CHFJPY', 'NZDJPY', 'NZDCHF', 'NZDCAD'],
            'Indices': ['US30', 'SPX500', 'NAS100', 'GER40', 'UK100', 'FRA40', 'JPN225', 'AUS200', 'HK50'],
            'Commodities': ['XAUUSD', 'XAGUSD', 'XPTUSD', 'XPDUSD', 'USOIL', 'UKOIL', 'NATGAS', 'COPPER'],
            'Cryptocurrencies': ['BTCUSD', 'ETHUSD', 'LTCUSD', 'XRPUSD', 'ADAUSD', 'DOTUSD', 'LINKUSD', 'BNBUSD', 'SOLUSD', 'MATICUSD']
        };

        let html = '';

        // Add Favorites section first if we have any
        if (this.favoritePairs.length > 0) {
            html += `
                <div class="pair-group">
                    <div class="pair-group-title">⭐ Favorites</div>
                    <div class="pair-grid">
                        ${this.favoritePairs.map(pair => `
                            <div class="pair-option favorite" data-pair="${pair}">
                                <div class="pair-option-icon">
                                    ${this.renderCurrencyPairWithFlags(pair)}
                                </div>
                                <button type="button" class="pair-favorite-btn favorite-active" data-pair="${pair}" title="Remove from favorites">
                                    <i data-lucide="star" style="fill: currentColor;"></i>
                                </button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        // Add other groups, excluding pairs that are already in favorites
        Object.entries(allPairs).forEach(([groupName, pairs]) => {
            // Filter out pairs that are already in favorites
            const filteredPairs = pairs.filter(pair => !this.favoritePairs.includes(pair));

            if (filteredPairs.length > 0) {
                html += `
                    <div class="pair-group">
                        <div class="pair-group-title">${groupName}</div>
                        <div class="pair-grid">
                            ${filteredPairs.map(pair => `
                                <div class="pair-option" data-pair="${pair}">
                                    <div class="pair-option-icon">
                                        ${this.renderCurrencyPairWithFlags(pair)}
                                    </div>
                                    <button type="button" class="pair-favorite-btn" data-pair="${pair}" title="Add to favorites">
                                        <i data-lucide="star"></i>
                                    </button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
            }
        });

        return html;
    }

    setupPairSelectionListeners(modal, hiddenInput, button) {
        // Add pair selection listeners - click on pair area (excluding star button)
        modal.querySelectorAll('.pair-option').forEach(option => {
            option.addEventListener('click', (e) => {
                // If click is on star button, don't handle pair selection
                if (e.target.closest('.pair-favorite-btn')) {
                    return;
                }

                const pairValue = option.dataset.pair;
                if (pairValue) {
                    // Update hidden input
                    hiddenInput.value = pairValue;

                    // Update button display
                    const textSpan = button.querySelector('.pair-select-text');
                    if (textSpan) {
                        textSpan.textContent = pairValue;
                        textSpan.classList.add('has-value');
                    }

                    // Trigger change event on hidden input
                    const changeEvent = new Event('change', { bubbles: true });
                    hiddenInput.dispatchEvent(changeEvent);

                    modal.classList.remove('show');
                    setTimeout(() => {
                        if (modal.parentNode) {
                            modal.remove();
                        }
                    }, 300);
                }
            });
        });

        // Add favorite toggle listeners - only for star buttons
        modal.querySelectorAll('.pair-favorite-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent triggering pair selection
                e.preventDefault();

                const pairValue = btn.dataset.pair;
                if (pairValue) {
                    this.toggleFavoritePair(pairValue);

                    // Refresh the entire modal content to move pairs between sections
                    const modalBody = modal.querySelector('.pair-selection-body');
                    if (modalBody) {
                        modalBody.innerHTML = this.generatePairSelectionContent();

                        // Re-setup event listeners for the new content
                        this.setupPairSelectionListeners(modal, selector);

                        // Re-create icons
                        if (typeof lucide !== 'undefined') {
                            lucide.createIcons();
                        }

                        // Update selection state for current value
                        const currentValue = selector.value;
                        modal.querySelectorAll('.pair-option').forEach(opt => {
                            opt.classList.remove('selected');
                            if (opt.dataset.pair === currentValue) {
                                opt.classList.add('selected');
                            }
                        });
                    }
                }
            });
        });
    }

    updatePairSelector(selector) {
        this.populatePairSelector(selector);
    }

    // STRATEGIES MANAGEMENT
    loadStrategies() {
        try {
            const saved = localStorage.getItem('tradingAppStrategies');
            this.strategies = saved ? JSON.parse(saved) : [];
            console.log('Loaded strategies from localStorage:', this.strategies.length);
        } catch (error) {
            console.error('Error loading strategies:', error);
            this.strategies = [];
        }
    }

    saveStrategies() {
        try {
            localStorage.setItem('tradingAppStrategies', JSON.stringify(this.strategies));
            console.log('Strategies saved to localStorage');
        } catch (error) {
            console.error('Error saving strategies:', error);
        }
    }

    addStrategy() {
        const name = document.getElementById('strategy-name')?.value;
        const type = document.getElementById('strategy-type')?.value;
        const contextContent = document.getElementById('strategy-context')?.value || '';
        const entryContent = document.getElementById('strategy-entry')?.value || '';

        if (!name || !type) {
            this.showNotification('Please fill in strategy name and type', 'error');
            return;
        }

        // Збираємо вибрані таймфрейми для контексту
        const contextTimeframes = [];
        document.querySelectorAll('input[name="context-timeframes"]:checked').forEach(checkbox => {
            contextTimeframes.push(checkbox.value);
        });

        // Збираємо вибрані таймфрейми для ентрі
        const entryTimeframes = [];
        document.querySelectorAll('input[name="entry-timeframes"]:checked').forEach(checkbox => {
            entryTimeframes.push(checkbox.value);
        });

        // Збираємо скріншоти з контенту
        const contextImages = [];
        document.querySelectorAll('#context-images img').forEach(img => {
            contextImages.push(img.src);
        });

        const entryImages = [];
        document.querySelectorAll('#entry-images img').forEach(img => {
            entryImages.push(img.src);
        });

        // Check if we're editing an existing strategy
        if (this.currentEditStrategyId) {
            // Edit existing strategy
            const strategyIndex = this.strategies.findIndex(s => s.id === this.currentEditStrategyId);
            if (strategyIndex !== -1) {
                this.strategies[strategyIndex] = {
                    ...this.strategies[strategyIndex],
                    name: name,
                    type: type,
                    contextTimeframes: contextTimeframes,
                    entryTimeframes: entryTimeframes,
                    contextContent: contextContent,
                    entryContent: entryContent,
                    contextImages: contextImages,
                    entryImages: entryImages
                };
                this.showNotification('Strategy updated successfully!', 'success');
            }
            this.currentEditStrategyId = null;
        } else {
            // Add new strategy
            const newStrategy = {
                id: Date.now(),
                name: name,
                type: type,
                contextTimeframes: contextTimeframes,
                entryTimeframes: entryTimeframes,
                contextContent: contextContent,
                entryContent: entryContent,
                contextImages: contextImages,
                entryImages: entryImages,
                createdAt: new Date().toISOString(),
                lastUsed: null,
                isActive: true
            };

            this.strategies.push(newStrategy);
            this.showNotification('Strategy added successfully!', 'success');
        }

        this.saveStrategies();
        this.updateStrategiesDisplay();
        this.populateStrategiesSelect();
        this.closeModal('add-strategy-modal');
    }

    // ЗБІР СКРІНШОТІВ З КОНТЕЙНЕРА
    collectScreenshotsFromContainer(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return [];

        const screenshots = [];
        container.querySelectorAll('img').forEach(img => {
            screenshots.push(img.src);
        });
        return screenshots;
    }

    deleteStrategy(strategyId) {
        this.strategies = this.strategies.filter(strategy => strategy.id !== strategyId);
        this.saveStrategies();
        this.updateStrategiesDisplay();
        this.populateStrategiesSelect();
        this.showNotification('Strategy deleted successfully!', 'success');
    }

    updateStrategiesDisplay() {
        this.renderStrategiesGrid();
        this.updateStrategiesMetrics();
    }

    populateStrategiesSelect() {
        const strategySelects = document.querySelectorAll('.strategy-select');

        strategySelects.forEach(select => {
            if (select) {
                select.innerHTML = '<option value="">Select Strategy</option>';
                this.strategies.forEach(strategy => {
                    select.innerHTML += `<option value="${strategy.name}">${strategy.name} (${strategy.type})</option>`;
                });
            }
        });

        console.log('Populated strategy selects for', strategySelects.length, 'elements with', this.strategies.length, 'strategies');
    }

    // ═══════════════════════════════════════════════════════════════
    // SETUPS MANAGEMENT
    // ═══════════════════════════════════════════════════════════════
    loadSetups() {
        try {
            const saved = localStorage.getItem('tradingAppSetups');
            this.setups = saved ? JSON.parse(saved) : [];
            console.log('Loaded setups from localStorage:', this.setups.length);
        } catch (error) {
            console.error('Error loading setups:', error);
            this.setups = [];
        }
    }

    saveSetups() {
        try {
            localStorage.setItem('tradingAppSetups', JSON.stringify(this.setups));
            console.log('Setups saved to localStorage');
        } catch (error) {
            console.error('Error saving setups:', error);
        }
    }

    renderSetupsGrid() {
        console.log('renderSetupsGrid called, setups:', this.setups);
        const container = document.getElementById('setups-grid');
        if (!container) {
            console.error('Setups grid container not found');
            return;
        }

        console.log('Rendering', this.setups.length, 'setups');

        if (this.setups.length === 0) {
            container.innerHTML = `
                <div class="empty-setups">
                    <div class="empty-message">
                        <i data-lucide="target"></i>
                        <p>No setups yet</p>
                        <small>Create your first setup to track specific entry patterns</small>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        let html = '';

        this.setups.forEach(setup => {
            const setupTrades = this.trades.filter(trade => trade.entryModel === setup.name);
            const totalTrades = setupTrades.length;
            const winTrades = setupTrades.filter(trade => trade.result === 'Win').length;
            const winRate = totalTrades > 0 ? (winTrades / totalTrades) * 100 : 0;
            const totalPnl = setupTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const avgRR = totalTrades > 0 ? setupTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / totalTrades : 0;

            const lastUsedDate = setup.lastUsed ? new Date(setup.lastUsed).toLocaleDateString() : 'Never';

            html += `
                <div class="strategy-card">
                    <div class="strategy-card-header">
                        <div class="strategy-title-section">
                            <div class="strategy-name">${setup.name}</div>
                        </div>
                        <div class="action-menu-container">
                            <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.showActionMenu(this, 'setup', {setupId: '${setup.id}'})">
                                <i data-lucide="more-horizontal"></i>
                            </button>
                            <div class="action-menu" style="display: none;">
                                <div class="action-menu-item action-delete" onclick="event.stopPropagation(); window.app.deleteSetup('${setup.id}'); this.closest('.action-menu').style.display = 'none';">
                                    <i data-lucide="trash-2"></i>
                                    <span>Delete</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="strategy-metrics">
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${totalTrades}</div>
                            <div class="strategy-metric-label">TRADES</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${winRate.toFixed(0)}%</div>
                            <div class="strategy-metric-label">WIN RATE</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value ${totalPnl >= 0 ? 'positive' : 'negative'}">${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toFixed(0)}</div>
                            <div class="strategy-metric-label">TOTAL P&L</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${avgRR.toFixed(1)}</div>
                            <div class="strategy-metric-label">AVG RR</div>
                        </div>
                    </div>

                    ${setup.description ? `
                        <div class="strategy-content">
                            <div class="strategy-content-section">
                                <div class="strategy-content-label">DESCRIPTION</div>
                                <div class="strategy-content-text">${setup.description}</div>
                            </div>
                        </div>
                    ` : ''}

                    <div class="strategy-footer">
                        <div class="strategy-last-used">Last used: ${lastUsedDate}</div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    showAddSetupModal() {
        console.log('showAddSetupModal called');
        this.closeAllModals();

        const modal = document.getElementById('add-setup-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    handleAddSetup(event) {
        event.preventDefault();

        const name = document.getElementById('setup-name').value;
        const description = document.getElementById('setup-description').value;

        const setup = {
            id: 'setup-' + Date.now(),
            name: name,
            description: description || '',
            createdAt: new Date().toISOString()
        };

        this.setups.push(setup);
        this.saveSetups();
        this.renderSetupsGrid();
        this.closeModal('add-setup-modal');
        this.showNotification('Setup added successfully!', 'success');

        // Очистити форму
        document.getElementById('setup-name').value = '';
        document.getElementById('setup-description').value = '';
    }

    deleteSetup(setupId) {
        this.setups = this.setups.filter(setup => setup.id !== setupId);
        this.saveSetups();
        this.renderSetupsGrid();
        this.showNotification('Setup deleted successfully!', 'success');
    }

    renderStrategiesGrid() {
        console.log('renderStrategiesGrid called, strategies:', this.strategies);
        const container = document.getElementById('strategies-grid');
        if (!container) {
            console.error('Strategies grid container not found');
            return;
        }

        console.log('Rendering', this.strategies.length, 'strategies');

        if (this.strategies.length === 0) {
            container.innerHTML = `
                <div class="empty-strategies">
                    <div class="empty-message">
                        <i data-lucide="target"></i>
                        <p>No strategies yet</p>
                        <small>Create your first trading strategy to get started</small>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        let html = '';

        this.strategies.forEach(strategy => {
            const strategyTrades = this.trades.filter(trade => trade.strategy === strategy.name);
            const totalTrades = strategyTrades.length;
            const winTrades = strategyTrades.filter(trade => trade.result === 'Win').length;
            const winRate = totalTrades > 0 ? (winTrades / totalTrades) * 100 : 0;
            const totalPnl = strategyTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const avgRR = totalTrades > 0 ? strategyTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / totalTrades : 0;

            const lastUsedDate = strategy.lastUsed ? new Date(strategy.lastUsed).toLocaleDateString() : 'Never';

            // Формуємо відображення таймфреймів
            let timeframesDisplay = '';
            const contextTFs = strategy.contextTimeframes && strategy.contextTimeframes.length > 0 
                ? strategy.contextTimeframes.join(', ') 
                : 'Not set';
            const entryTFs = strategy.entryTimeframes && strategy.entryTimeframes.length > 0 
                ? strategy.entryTimeframes.join(', ') 
                : 'Not set';

            timeframesDisplay = `Context: ${contextTFs} | Entry: ${entryTFs}`;

            // Контент стратегії
            const contextContent = strategy.contextContent || strategy.description || '';
            const entryContent = strategy.entryContent || strategy.entryRules || '';

            html += `
                <div class="strategy-card">
                    <div class="strategy-card-header">
                        <div class="strategy-title-section">
                            <div class="strategy-name">${strategy.name}</div>
                            <div class="strategy-type-badge">${strategy.type}</div>
                        </div>
                        <div class="action-menu-container">
                            <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.showActionMenu(this, 'strategy', {strategyId: ${strategy.id}})">
                                <i data-lucide="more-horizontal"></i>
                            </button>
                            <div class="action-menu" style="display: none;">
                                <div class="action-menu-item action-edit">
                                    <i data-lucide="edit-2"></i>
                                    <span>Edit</span>
                                </div>
                                <div class="action-menu-item action-delete" onclick="event.stopPropagation(); window.app.deleteStrategy(${strategy.id}); this.closest('.action-menu').style.display = 'none';">
                                    <i data-lucide="trash-2"></i>
                                    <span>Delete</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="strategy-timeframes-section">
                        <div class="strategy-timeframes-label">Timeframes</div>
                        <div class="strategy-timeframes-display">${timeframesDisplay}</div>
                    </div>

                    <div class="strategy-metrics">
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${totalTrades}</div>
                            <div class="strategy-metric-label">TRADES</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${winRate.toFixed(0)}%</div>
                            <div class="strategy-metric-label">WIN RATE</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value ${totalPnl >= 0 ? 'positive' : 'negative'}">${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toFixed(0)}</div>
                            <div class="strategy-metric-label">TOTAL P&L</div>
                        </div>
                        <div class="strategy-metric">
                            <div class="strategy-metric-value">${avgRR.toFixed(1)}</div>
                            <div class="strategy-metric-label">AVG RR</div>
                        </div>
                    </div>

                    <div class="strategy-content">
                        ${contextContent ? `
                            <div class="strategy-content-section">
                                <div class="strategy-content-label">CONTEXT</div>
                                <div class="strategy-content-text">${contextContent}</div>
                            </div>
                        ` : ''}
                        ${entryContent ? `
                            <div class="strategy-content-section">
                                <div class="strategy-content-label">ENTRY & EXIT</div>
                                <div class="strategy-content-text">${entryContent}</div>
                            </div>
                        ` : ''}
                    </div>

                    <div class="strategy-footer">
                        <div class="strategy-last-used">Last used: ${lastUsedDate}</div>

                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
        console.log('Strategies rendered:', this.strategies.length);
    }

    updateStrategiesMetrics() {
        const totalStrategies = this.strategies.length;

        // Find best strategy by win rate
        let bestWinRate = 0;
        let mostUsedStrategy = '-';
        let mostProfitableStrategy = '-';

        if (totalStrategies > 0) {
            let maxUsage = 0;
            let maxProfit = -Infinity;

            this.strategies.forEach(strategy => {
                const strategyTrades = this.trades.filter(trade => trade.strategy === strategy.name);
                const totalTrades = strategyTrades.length;
                const winTrades = strategyTrades.filter(trade => trade.result === 'Win').length;
                const winRate = totalTrades > 0 ? (winTrades / totalTrades) * 100 : 0;
                const totalPnl = strategyTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

                if (winRate > bestWinRate) {
                    bestWinRate = winRate;
                }

                if (totalTrades > maxUsage) {
                    maxUsage = totalTrades;
                    mostUsedStrategy = strategy.name;
                }

                if (totalPnl > maxProfit) {
                    maxProfit = totalPnl;
                    mostProfitableStrategy = strategy.name;
                }
            });
        }

        this.updateElement('total-strategies', totalStrategies);
        this.updateElement('best-strategy-winrate', `${bestWinRate.toFixed(0)}%`);
        this.updateElement('most-used-strategy', mostUsedStrategy);
        this.updateElement('most-profitable-strategy', mostProfitableStrategy);
    }

    showAddStrategyModal() {
        console.log('showAddStrategyModal called');
        this.closeAllModals();

        const modal = document.getElementById('add-strategy-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    // Перемикання між вкладками Strategies та Setups
    switchStrategyTab(tabName) {
        console.log('Switching to tab:', tabName);

        // Оновити активну вкладку
        document.querySelectorAll('.strategy-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        // Показати відповідний контент
        document.querySelectorAll('.strategy-tab-content').forEach(content => {
            content.classList.remove('active');
        });
        const activeContent = document.querySelector(`[data-tab-content="${tabName}"]`);
        if (activeContent) {
            activeContent.classList.add('active');
        }

        // Оновити текст кнопки додавання
        const addBtn = document.getElementById('add-strategy-setup-btn');
        if (addBtn) {
            const icon = addBtn.querySelector('i');
            if (tabName === 'setups') {
                addBtn.innerHTML = '';
                if (icon) addBtn.appendChild(icon);
                addBtn.appendChild(document.createTextNode('Add Setup'));
                addBtn.onclick = () => this.showAddSetupModal();
            } else {
                addBtn.innerHTML = '';
                if (icon) addBtn.appendChild(icon);
                addBtn.appendChild(document.createTextNode('Add Strategy'));
                addBtn.onclick = () => this.showAddStrategyModal();
            }
        }

        // НЕ викликаємо render тут - контент вже відображений і залишається в DOM
        // Рендер відбувається тільки при додаванні/видаленні стратегій/сетапів

        // Оновити іконки Lucide
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    setupStrategyModalTabs() {
        // Tab switching
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('strategy-tab')) {
                const tabName = e.target.dataset.tab;

                // Remove active class from all tabs
                document.querySelectorAll('.strategy-tab').forEach(tab => {
                    tab.classList.remove('active');
                });

                // Add active class to clicked tab
                e.target.classList.add('active');

                // Hide all tab contents
                document.querySelectorAll('.strategy-tab-content').forEach(content => {
                    content.classList.remove('active');
                });

                // Show selected tab content
                const targetContent = document.getElementById(`${tabName}-tab`);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            }
        });

        // Timeframe selection
        document.addEventListener('click', (e) => {
            if (e.target.closest('.timeframe-option')) {
                const option = e.target.closest('.timeframe-option');
                const checkbox = option.querySelector('input[type="checkbox"]');

                if (e.target !== checkbox) {
                    checkbox.checked = !checkbox.checked;
                }

                if (checkbox.checked) {
                    option.classList.add('selected');
                } else {
                    option.classList.remove('selected');
                }
            }
        });

        // Combined content area paste handling
        document.addEventListener('paste', (e) => {
            const target = e.target;
            if (target.closest('.combined-content-area')) {
                const items = e.clipboardData.items;
                for (let item of items) {
                    if (item.type.indexOf('image') !== -1) {
                        const file = item.getAsFile();
                        const imagesContainer = target.closest('.combined-content-area').querySelector('.combined-content-images');
                        this.handleCombinedContentImage(file, imagesContainer);
                        e.preventDefault();
                        break;
                    }
                }
            }
        });
    }

    handleCombinedContentImage(file, imagesContainer) {
        if (!file || !file.type.startsWith('image/') || !imagesContainer) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const screenshotDiv = document.createElement('div');
            screenshotDiv.className = 'screenshot-item';
            screenshotDiv.innerHTML = `
                <img src="${e.target.result}" onclick="window.app.openScreenshotFullscreen('${e.target.result}')">
                <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
            `;
            imagesContainer.appendChild(screenshotDiv);
        };
        reader.readAsDataURL(file);
    }

    resetStrategyForm() {
        const form = document.getElementById('add-strategy-form');
        if (form) form.reset();

        // Reset modal title and button text
        const modalTitle = document.querySelector('#add-strategy-modal .modal-header h2');
        const submitButton = document.querySelector('#add-strategy-modal button[type="submit"]');

        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="target"></i> Add New Strategy';
        }
        if (submitButton) {
            submitButton.innerHTML = '<i data-lucide="save"></i> Add Strategy';
        }

        // Reset editing state
        this.currentEditStrategyId = null;

        // Reset tabs to first tab
        document.querySelectorAll('.strategy-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector('.strategy-tab[data-tab="context"]')?.classList.add('active');

        document.querySelectorAll('.strategy-tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById('context-tab')?.classList.add('active');

        // Clear timeframe selections
        document.querySelectorAll('.timeframe-option').forEach(option => {
            option.classList.remove('selected');
            const checkbox = option.querySelector('input[type="checkbox"]');
            if (checkbox) checkbox.checked = false;
        });

        // Clear images
        document.querySelectorAll('.combined-content-images').forEach(container => {
            container.innerHTML = '';
        });

        // Clear textareas
        document.querySelectorAll('.combined-content-textarea').forEach(textarea => {
            textarea.value = '';
        });

        // Re-create lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }

    editStrategy(strategyId) {
        const strategy = this.strategies.find(s => s.id === strategyId);
        if (!strategy) {
            this.showNotification('Strategy not found', 'error');
            return;
        }

        // Store the current edit strategy ID
        this.currentEditStrategyId = strategyId;

        // Fill the form with current data
        document.getElementById('strategy-name').value = strategy.name || '';
        document.getElementById('strategy-type').value = strategy.type || '';
        document.getElementById('strategy-context').value = strategy.contextContent || '';
        document.getElementById('strategy-entry').value = strategy.entryContent || '';

        // Set context timeframes
        document.querySelectorAll('input[name="context-timeframes"]').forEach(checkbox => {
            checkbox.checked = strategy.contextTimeframes && strategy.contextTimeframes.includes(checkbox.value);
            const option = checkbox.closest('.timeframe-option');
            if (checkbox.checked) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });

        // Set entry timeframes
        document.querySelectorAll('input[name="entry-timeframes"]').forEach(checkbox => {
            checkbox.checked = strategy.entryTimeframes && strategy.entryTimeframes.includes(checkbox.value);
            const option = checkbox.closest('.timeframe-option');
            if (checkbox.checked) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });

        // Handle context images
        const contextImages = document.getElementById('context-images');
        if (contextImages) {
            contextImages.innerHTML = '';
            if (strategy.contextImages && strategy.contextImages.length > 0) {
                strategy.contextImages.forEach(imageSrc => {
                    const screenshotDiv = document.createElement('div');
                    screenshotDiv.className = 'screenshot-item';
                    screenshotDiv.innerHTML = `
                        <img src="${imageSrc}" onclick="window.app.openScreenshotFullscreen('${imageSrc}')">
                        <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                    `;
                    contextImages.appendChild(screenshotDiv);
                });
            }
        }

        // Handle entry images
        const entryImages = document.getElementById('entry-images');
        if (entryImages) {
            entryImages.innerHTML = '';
            if (strategy.entryImages && strategy.entryImages.length > 0) {
                strategy.entryImages.forEach(imageSrc => {
                    const screenshotDiv = document.createElement('div');
                    screenshotDiv.className = 'screenshot-item';
                    screenshotDiv.innerHTML = `
                        <img src="${imageSrc}" onclick="window.app.openScreenshotFullscreen('${imageSrc}')">
                        <button type="button" class="screenshot-remove" onclick="this.parentElement.remove()" title="Remove">×</button>
                    `;
                    entryImages.appendChild(screenshotDiv);
                });
            }
        }

        // Change modal title and button text
        const modalTitle = document.querySelector('#add-strategy-modal .modal-header h2');
        const submitButton = document.querySelector('#add-strategy-modal button[type="submit"]');

        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="edit"></i> Edit Strategy';
        }
        if (submitButton) {
            submitButton.innerHTML = '<i data-lucide="save"></i> Save Changes';
        }

        // Re-create lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }

        // Open the modal
        this.showAddStrategyModal();
    }

    viewStrategyDetails(strategyId) {
        // TODO: Implement strategy details view
        console.log('View strategy details:', strategyId);
        this.showNotification('Strategy details view will be implemented soon', 'info');
    }

    // PAYOUTS MANAGEMENT
    showAddPayoutModal() {
        console.log('showAddPayoutModal called');
        this.closeAllModals();

        // Populate accounts before showing modal
        this.populatePayoutsAccountSelect();

        const modal = document.getElementById('add-payout-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';

            // Set current date as default
            const dateInput = document.getElementById('payout-date');
            if (dateInput) {
                dateInput.value = new Date().toISOString().split('T')[0];
            }
        }
    }

    addPayout() {
        const date = document.getElementById('payout-date')?.value;
        const accountId = document.getElementById('payout-account')?.value;
        const amount = document.getElementById('payout-amount')?.value;
        const notes = document.getElementById('payout-notes')?.value || '';

        if (!date || !accountId || !amount) {
            this.showNotification('Please fill in all required fields (Date, Account, Amount)', 'error');
            return;
        }

        // Find the account
        const account = this.accounts.find(acc => acc.id === parseInt(accountId));
        if (!account) {
            this.showNotification('Account not found', 'error');
            return;
        }

        const newPayout = {
            id: Date.now(),
            date: date,
            accountId: parseInt(accountId),
            accountName: account.name,
            amount: parseFloat(amount),
            notes: notes,
            createdAt: new Date().toISOString()
        };

        // Initialize payouts array if it doesn't exist
        if (!this.payouts) {
            this.payouts = [];
        }

        // Check if we're editing an existing payout
        if (this.currentEditPayoutId) {
            // Edit existing payout
            const payoutIndex = this.payouts.findIndex(p => p.id === this.currentEditPayoutId);
            if (payoutIndex !== -1) {
                const oldPayout = this.payouts[payoutIndex];
                const oldAccount = this.accounts.find(acc => acc.id === oldPayout.accountId);

                // Return old payout amount to old account
                if (oldAccount) {
                    oldAccount.currentBalance += oldPayout.amount;
                }

                // Update payout
                this.payouts[payoutIndex] = newPayout;

                // Subtract new payout amount from new account
                account.currentBalance -= parseFloat(amount);

                this.showNotification('Payout updated successfully!', 'success');
            }
            this.currentEditPayoutId = null;
        } else {
            // Add new payout
            this.payouts.push(newPayout);

            // Subtract payout amount from account balance
            account.currentBalance -= parseFloat(amount);

            this.showNotification('Payout added successfully!', 'success');
        }

        // Save data
        this.savePayouts();
        this.saveAccounts();

        // Update displays
        this.updatePayoutsDisplay();
        this.updateAccountsDisplay();
        this.updateAllMetrics();

        // Close modal and reset form
        this.closeModal('add-payout-modal');
        this.resetPayoutForm();
    }

    deletePayout(payoutId) {
        const payoutIndex = this.payouts.findIndex(p => p.id === payoutId);
        if (payoutIndex === -1) {
            this.showNotification('Payout not found', 'error');
            return;
        }

        const payout = this.payouts[payoutIndex];

        // Find the account and return the payout amount
        const account = this.accounts.find(acc => acc.id === payout.accountId);
        if (account) {
            account.currentBalance += payout.amount;
        }

        // Remove payout
        this.payouts.splice(payoutIndex, 1);

        // Save data
        this.savePayouts();
        this.saveAccounts();

        // Update displays
        this.updatePayoutsDisplay();
        this.updateAccountsDisplay();
        this.updateAllMetrics();

        this.showNotification('Payout deleted successfully!', 'success');
    }

    loadPayouts() {
        try {
            const saved = localStorage.getItem('tradingAppPayouts');
            this.payouts = saved ? JSON.parse(saved) : [];
            console.log('Loaded payouts from localStorage:', this.payouts.length);
        } catch (error) {
            console.error('Error loading payouts:', error);
            this.payouts = [];
        }
    }

    savePayouts() {
        try {
            localStorage.setItem('tradingAppPayouts', JSON.stringify(this.payouts));
            console.log('Payouts saved to localStorage');
        } catch (error) {
            console.error('Error saving payouts:', error);
        }
    }

    updatePayoutsDisplay() {
        this.populatePayoutsAccountSelect();
        this.renderPayoutsList();
        this.updatePayoutsSummary();
    }

    populatePayoutsAccountSelect() {
        const payoutAccountSelect = document.getElementById('payout-account');
        if (payoutAccountSelect) {
            payoutAccountSelect.innerHTML = '<option value="">Select Account</option>';
            this.accounts.forEach(account => {
                const statusDisplay = account.status || account.type;
                payoutAccountSelect.innerHTML += `<option value="${account.id}">${account.name} (${statusDisplay})</option>`;
            });
        }
    }

    renderPayoutsList() {
        const payoutsList = document.getElementById('payouts-list');
        if (!payoutsList) return;

        if (!this.payouts || this.payouts.length === 0) {
            payoutsList.innerHTML = `
                <div class="empty-payouts">
                    <div class="empty-message">
                        <i data-lucide="arrow-up-right"></i>
                        <p>No payouts yet</p>
                        <small>Add your first payout to get started</small>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Sort payouts by date (newest first)
        const sortedPayouts = [...this.payouts].sort((a, b) => {
            return new Date(b.date) - new Date(a.date);
        });

        payoutsList.innerHTML = sortedPayouts.map(payout => `
            <div class="payout-item" onclick="window.app.editPayout(${payout.id})" title="Click to edit payout">
                <div class="payout-item-content">
                    <div class="payout-item-left">
                        <div class="payout-account-name">${payout.accountName}</div>
                        <div class="payout-date">${this.formatDate(payout.date)}</div>
                    </div>
                    <div class="payout-item-right">
                        <div class="payout-amount">$${payout.amount.toFixed(2)}</div>
                        <button class="payout-delete-btn" onclick="event.stopPropagation(); window.app.deletePayout(${payout.id})" title="Delete payout">
                            <i data-lucide="x"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    updatePayoutsSummary() {
        if (!this.payouts) return;

        const totalPayouts = this.payouts.reduce((sum, payout) => sum + payout.amount, 0);
        const totalPayoutsCount = this.payouts.length;

        // Calculate this month's payouts
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth();
        const currentYear = currentDate.getFullYear();

        const monthPayouts = this.payouts.filter(payout => {
            const payoutDate = new Date(payout.date);
            return payoutDate.getMonth() === currentMonth && payoutDate.getFullYear() === currentYear;
        }).reduce((sum, payout) => sum + payout.amount, 0);

        // Last payout date
        let lastPayoutDate = 'Never';
        if (this.payouts.length > 0) {
            const sortedPayouts = [...this.payouts].sort((a, b) => new Date(b.date) - new Date(a.date));
            lastPayoutDate = this.formatDate(sortedPayouts[0].date);
        }

        // Update elements
        this.updateElement('total-payouts-count', totalPayoutsCount);
        this.updateElement('total-payouts-amount', `$${totalPayouts.toFixed(2)}`);
        this.updateElement('month-payouts-amount', `$${monthPayouts.toFixed(2)}`);
        this.updateElement('last-payout-date', lastPayoutDate);
    }

    editPayout(payoutId) {
        const payout = this.payouts.find(p => p.id === payoutId);
        if (!payout) {
            this.showNotification('Payout not found', 'error');
            return;
        }

        // Store the current edit payout ID
        this.currentEditPayoutId = payoutId;

        // Fill the form with current data
        document.getElementById('payout-date').value = payout.date;
        document.getElementById('payout-account').value = payout.accountId;
        document.getElementById('payout-amount').value = payout.amount;
        document.getElementById('payout-notes').value = payout.notes || '';

        // Change modal title and button text
        const modalTitle = document.querySelector('#add-payout-modal .modal-header h2');
        const submitButton = document.querySelector('#add-payout-modal button[type="submit"]');

        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="edit"></i> Edit Payout';
        }
        if (submitButton) {
            submitButton.innerHTML = '<i data-lucide="save"></i> Save Changes';
        }

        // Open the modal
        this.showAddPayoutModal();
    }

    showAddPayoutModal() {
        console.log('showAddPayoutModal called');
        this.closeAllModals();

        // Populate accounts before showing modal
        this.populatePayoutsAccountSelect();

        const modal = document.getElementById('add-payout-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';

            // Set current date as default
            const dateInput = document.getElementById('payout-date');
            if (dateInput) {
                dateInput.value = new Date().toISOString().split('T')[0];
            }
        }
    }

    // UPDATE ENTRY TIMEFRAMES WIDGET
    updateEntryTimeframesWidget() {
        const container = document.getElementById('entry-timeframes-list');
        if (!container) return;

        // Use filtered trades
        const filteredTrades = this.getFilteredTrades();

        // Group trades by entry timeframes
        const timeframeStats = {};

        filteredTrades.forEach(trade => {
            const timeframe = trade.entryTimeframes || 'Unknown';

            if (!timeframeStats[timeframe]) {
                timeframeStats[timeframe] = {
                    trades: [],
                    totalTrades: 0,
                    winTrades: 0,
                    totalPnl: 0
                };
            }

            timeframeStats[timeframe].trades.push(trade);
            timeframeStats[timeframe].totalTrades++;

            if (trade.result && (trade.result.toLowerCase() === 'win' || trade.result.toLowerCase() === 'winner')) {
                timeframeStats[timeframe].winTrades++;
            }

            timeframeStats[timeframe].totalPnl += (trade.pnl || 0);
        });

        // Sort timeframes by total trades (most used first)
        const sortedTimeframes = Object.entries(timeframeStats)
            .sort(([,a], [,b]) => b.totalTrades - a.totalTrades);

        if (sortedTimeframes.length === 0) {
            container.innerHTML = `
                <div class="empty-timeframes">
                    <div class="empty-message">
                        <i data-lucide="clock"></i>
                        <p>No entry timeframes data</p>
                        <small>Add trades with entry timeframes to see statistics</small>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        container.innerHTML = sortedTimeframes.map(([timeframe, stats]) => {
            const winRate = stats.totalTrades > 0 ? (stats.winTrades / stats.totalTrades) * 100 : 0;
            const avgPnl = stats.totalTrades > 0 ? stats.totalPnl / stats.totalTrades : 0;
            const winRateClass = winRate >= 50 ? 'positive' : 'negative';

            return `
                <div class="timeframe-item">
                    <div class="item-header">
                        <div class="item-symbol">${timeframe}</div>
                        <div class="item-trades">${stats.totalTrades} trade${stats.totalTrades !== 1 ? 's' : ''}</div>
                    </div>
                    <div class="item-metrics-grid">
                        <div class="item-stat">
                            <div class="stat-label">P&L</div>
                            <div class="stat-value ${stats.totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${stats.totalPnl >= 0 ? '+' : ''}$${Math.abs(stats.totalPnl).toFixed(0)}
                            </div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Win Rate</div>
                            <div class="stat-value ${winRateClass}">${winRate.toFixed(1)}%</div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Avg P&L</div>
                            <div class="stat-value ${avgPnl >= 0 ? 'positive' : 'negative'}">
                                ${avgPnl >= 0 ? '+' : ''}$${Math.abs(avgPnl).toFixed(0)}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    /* 
    ███████████████████████████████████████████████████████████████
    █                                                             █
    █  🎯 РОЗДІЛ: ENTRY MODELS (МОДЕЛІ ВХОДУ)                     █
    █  Управління кастомними моделями входу для трейдів           █
    █                                                             █
    ███████████████████████████████████████████████████████████████
    */

    // ┌─────────────────────────────────────────────────────────┐
    // │ 📊 ПІДРОЗДІЛ: ЗАВАНТАЖЕННЯ/ЗБЕРЕЖЕННЯ ENTRY MODELS     │
    // └─────────────────────────────────────────────────────────┘
    loadEntryModels() {
        try {
            const saved = localStorage.getItem('tradingAppEntryModels');
            this.entryModels = saved ? JSON.parse(saved) : this.getDefaultEntryModels();
            console.log('Loaded entry models from localStorage:', this.entryModels.length);
        } catch (error) {
            console.error('Error loading entry models:', error);
            this.entryModels = this.getDefaultEntryModels();
        }
    }

    getDefaultEntryModels() {
        return [
            {
                id: Date.now() + 1,
                name: 'Breakout Strategy',
                description: 'Entry on price breakout with volume confirmation',
                entryRules: 'Wait for price to break key levels with strong volume',
                exitRules: 'Take profit at next resistance, stop loss below support',
                riskManagement: 'Risk 1-2% per trade',
                timeframes: ['15m', '1h'],
                instruments: ['Forex', 'Indices'],
                winRate: 0,
                avgRR: 0,
                totalTrades: 0,
                createdAt: new Date().toISOString(),
                isActive: true
            },
            {
                id: Date.now() + 2,
                name: 'Trend Following',
                description: 'Follow the main trend with pullback entries',
                entryRules: 'Enter on pullbacks in trending markets',
                exitRules: 'Trail stop loss, exit on trend reversal signals',
                riskManagement: 'Risk 1-2% per trade',
                timeframes: ['1h', '4h'],
                instruments: ['Forex', 'Commodities'],
                winRate: 0,
                avgRR: 0,
                totalTrades: 0,
                createdAt: new Date().toISOString(),
                isActive: true
            },
            {
                id: Date.now() + 3,
                name: 'Reversal Pattern',
                description: 'Entry on reversal patterns at key levels',
                entryRules: 'Look for reversal candlestick patterns at support/resistance',
                exitRules: 'Target previous swing high/low, tight stop loss',
                riskManagement: 'Risk 1-2% per trade',
                timeframes: ['15m', '30m', '1h'],
                instruments: ['Forex', 'Indices'],
                winRate: 0,
                avgRR: 0,
                totalTrades: 0,
                createdAt: new Date().toISOString(),
                isActive: true
            }
        ];
    }

    saveEntryModels() {
        try {
            localStorage.setItem('tradingAppEntryModels', JSON.stringify(this.entryModels));
            console.log('Entry models saved to localStorage');
        } catch (error) {
            console.error('Error saving entry models:', error);
        }
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ ➕ ПІДРОЗДІЛ: СТВОРЕННЯ НОВОЇ ENTRY MODEL              │
    // └─────────────────────────────────────────────────────────┘
    createEntryModel(modelData) {
        const newModel = {
            id: Date.now(),
            name: modelData.name || 'New Entry Model',
            description: modelData.description || '',
            entryRules: modelData.entryRules || '',
            exitRules: modelData.exitRules || '',
            riskManagement: modelData.riskManagement || '',
            timeframes: modelData.timeframes || [],
            instruments: modelData.instruments || [],
            winRate: 0, // Буде розраховуватись автоматично
            avgRR: 0, // Буде розраховуватись автоматично
            totalTrades: 0,
            createdAt: new Date().toISOString(),
            isActive: true
        };

        if (!this.entryModels) {
            this.entryModels = [];
        }

        this.entryModels.push(newModel);
        this.saveEntryModels();
        this.updateEntryModelsDisplay();
        this.populateEntryModelsSelect();

        return newModel;
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ 🗑️ ПІДРОЗДІЛ: ВИДАЛЕННЯ ENTRY MODEL                   │
    // └─────────────────────────────────────────────────────────┘
    deleteEntryModel(modelId) {
        if (!this.entryModels) return;

        this.entryModels = this.entryModels.filter(model => model.id !== modelId);
        this.saveEntryModels();
        this.updateEntryModelsDisplay();
        this.populateEntryModelsSelect();

        this.showNotification('Entry model deleted successfully!', 'success');
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ 🎨 ПІДРОЗДІЛ: ВІДОБРАЖЕННЯ ENTRY MODELS               │
    // └─────────────────────────────────────────────────────────┘
    updateEntryModelsDisplay() {
        this.renderEntryModelsGrid();
        this.populateEntryModelsSelect();
    }

    renderEntryModelsGrid() {
        const container = document.getElementById('entry-models-grid');
        if (!container) return;

        if (!this.entryModels || this.entryModels.length === 0) {
            container.innerHTML = `
                <div class="empty-entry-models">
                    <div class="empty-message">
                        <i data-lucide="target"></i>
                        <p>No entry models yet</p>
                        <small>Create your first entry model to standardize your trading approach</small>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        let html = '';
        this.entryModels.forEach(model => {
            // Розрахунок статистики для моделі
            const modelTrades = this.trades.filter(trade => trade.entryModel === model.name);
            const totalTrades = modelTrades.length;
            const winTrades = modelTrades.filter(trade => trade.result === 'Win').length;
            const winRate = totalTrades > 0 ? (winTrades / totalTrades) * 100 : 0;
            const totalPnl = modelTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const avgRR = totalTrades > 0 ? modelTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / totalTrades : 0;

            html += `
                <div class="entry-model-card">
                    <div class="entry-model-header">
                        <div class="entry-model-title">
                            <h3>${model.name}</h3>
                            <span class="entry-model-type">${model.type}</span>
                        </div>
                        <div class="action-menu-container">
                            <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.showActionMenu(this, 'entryModel', {modelId: ${model.id}})">
                                <i data-lucide="more-horizontal"></i>
                            </button>
                            <div class="action-menu" style="display: none;">
                                <div class="action-menu-item action-edit">
                                    <i data-lucide="edit-2"></i>
                                    <span>Edit</span>
                                </div>
                                <div class="action-menu-item action-delete">
                                    <i data-lucide="trash-2"></i>
                                    <span>Delete</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="entry-model-stats">
                        <div class="model-stat">
                            <span class="stat-value">${totalTrades}</span>
                            <span class="stat-label">Trades</span>
                        </div>
                        <div class="model-stat">
                            <span class="stat-value">${winRate.toFixed(1)}%</span>
                            <span class="stat-label">Win Rate</span>
                        </div>
                        <div class="model-stat">
                            <span class="stat-value ${totalPnl >= 0 ? 'positive' : 'negative'}">${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toFixed(0)}</span>
                            <span class="stat-label">Total P&L</span>
                        </div>
                        <div class="model-stat">
                            <span class="stat-value">${avgRR.toFixed(1)}</span>
                            <span class="stat-label">Avg RR</span>
                        </div>
                    </div>

                    <div class="entry-model-content">
                        ${model.description ? `<p class="model-description">${model.description}</p>` : ''}
                        ${model.entryRules ? `
                            <div class="model-rules">
                                <h4>Entry Rules</h4>
                                <p>${model.entryRules}</p>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ 📝 ПІДРОЗДІЛ: ЗАПОВНЕННЯ СЕЛЕКТІВ                      │
    // └─────────────────────────────────────────────────────────┘
    populateEntryModelsSelect() {
        const selects = document.querySelectorAll('.entry-model-select');

        selects.forEach(select => {
            if (select) {
                select.innerHTML = '<option value="">Select Entry Model</option>';
                if (this.setups && this.setups.length > 0) {
                    this.setups.forEach(setup => {
                        select.innerHTML += `<option value="${setup.name}">${setup.name}</option>`;
                    });
                }
            }
        });

        console.log('Populated entry model selects for', selects.length, 'elements with', this.setups ? this.setups.length : 0, 'setups');
    }



    // ┌─────────────────────────────────────────────────────────┐
    // │ ✏️ ПІДРОЗДІЛ: РЕДАГУВАННЯ ENTRY MODEL                  │
    // └─────────────────────────────────────────────────────────┘
    editEntryModel(modelId) {
        const model = this.entryModels.find(m => m.id === modelId);
        if (!model) {
            this.showNotification('Entry model not found', 'error');
            return;
        }

        // Тут можна додати модальне вікно для редагування або інший функціонал
        this.showNotification('Entry model editing will be implemented soon', 'info');
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ 📊 ПІДРОЗДІЛ: СТАТИСТИКА ENTRY MODELS                  │
    // └─────────────────────────────────────────────────────────┘
    updateEntryModelStats(modelId) {
        const model = this.entryModels.find(m => m.id === modelId);
        if (!model) return;

        // Знайти всі трейди з цією entry model
        const modelTrades = this.trades.filter(trade => trade.entryModel === model.name);

        // Оновити статистику моделі
        model.totalTrades = modelTrades.length;

        if (modelTrades.length > 0) {
            const winTrades = modelTrades.filter(trade => trade.result === 'Win').length;
            model.winRate = (winTrades / modelTrades.length) * 100;

            const totalRR = modelTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0);
            model.avgRR = totalRR / modelTrades.length;
        } else {
            model.winRate = 0;
            model.avgRR = 0;
        }

        this.saveEntryModels();
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ 🔄 ПІДРОЗДІЛ: ОНОВЛЕННЯ ВСІХ ENTRY MODEL СТАТИСТИК     │
    // └─────────────────────────────────────────────────────────┘
    updateAllEntryModelsStats() {
        if (!this.entryModels || this.entryModels.length === 0) return;

        this.entryModels.forEach(model => {
            this.updateEntryModelStats(model.id);
        });
    }

    // ┌─────────────────────────────────────────────────────────┐
    // │ 🎨 ПІДРОЗДІЛ: РЕНДЕРИНГ ENTRY MODELS ДЛЯ ШВИДКОГО ВИБОРУ │
    // └─────────────────────────────────────────────────────────┘
    renderEntryModelsQuickSelect() {
        const container = document.getElementById('entry-models-list');
        if (!container) return;

        if (!this.entryModels || this.entryModels.length === 0) {
            container.innerHTML = `
                <div class="entry-models-empty">
                    <div class="empty-message">
                        <i data-lucide="target"></i>
                        <p>No entry models yet</p>
                        <small>Create your first entry model above</small>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        let html = '';
        this.entryModels.forEach(model => {
            // Розрахунок статистики для моделі
            const modelTrades = this.trades.filter(trade => trade.entryModel === model.name);
            const totalTrades = modelTrades.length;
            const winTrades = modelTrades.filter(trade => trade.result === 'Win').length;
            const winRate = totalTrades > 0 ? (winTrades / totalTrades) * 100 : 0;

            html += `
                <div class="entry-model-item">
                    <div class="entry-model-header">
                        <div class="entry-model-info">
                            <div class="entry-model-name">${model.name}</div>
                            <div class="entry-model-type">${model.type}</div>
                        </div>
                        <div class="entry-model-actions">
                            <button type="button" class="btn-entry-model-edit" onclick="window.app.editEntryModel(${model.id})" title="Edit">
                                <i data-lucide="edit-2"></i>
                            </button>
                            <button type="button" class="btn-entry-model-delete" onclick="window.app.deleteEntryModel(${model.id})" title="Delete">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </div>
                    </div>
                    ${model.description ? `<div class="entry-model-description">${model.description}</div>` : ''}
                    <div class="entry-model-stats">
                        <div class="entry-model-stat">Trades: ${totalTrades}</div>
                        <div class="entry-model-stat">Win Rate: ${winRate.toFixed(1)}%</div>
                    </div>
                    <button type="button" class="btn-secondary btn-sm" onclick="window.app.selectEntryModel('${model.name}')" style="width: 100%; margin-top: 8px;">
                        <i data-lucide="check"></i>
                        Select This Model
                    </button>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    // SETUP DIRECTION FILTERS - залишаємо оригінальну функцію
    setupDirectionFilters() {
        document.querySelectorAll('.direction-filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const direction = btn.dataset.direction;
                const container = btn.closest('.dashboard-widget');

                // Remove active class from all buttons in this container
                container.querySelectorAll('.direction-filter-btn').forEach(b => {
                    b.classList.remove('active');
                });

                // Add active class to clicked button
                btn.classList.add('active');

                // Update instruments display based on direction
                this.updateInstrumentsWidget(direction);
            });
        });
    }



    // SETUP WIDGET DRAG AND DROP
    setupWidgetDragAndDrop() {
        const widgetsGrid = document.querySelector('.dashboard-widgets-grid');
        if (!widgetsGrid) return;

        let draggedWidget = null;
        let draggedOverWidget = null;
        let previewSwapTimeout = null;
        let hasPreviewSwapped = false;

        // Load saved widget order
        this.loadWidgetOrder();

        // Add event listeners to all widgets
        const widgets = widgetsGrid.querySelectorAll('.dashboard-widget');
        widgets.forEach(widget => {
            // Drag start
            widget.addEventListener('dragstart', (e) => {
                draggedWidget = widget;
                widget.classList.add('dragging');
                hasPreviewSwapped = false;
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/html', widget.outerHTML);

                // Create a custom drag image to prevent jumping
                const rect = widget.getBoundingClientRect();
                const offsetX = e.clientX - rect.left;
                const offsetY = e.clientY - rect.top;

                // Set drag image with proper offset
                e.dataTransfer.setDragImage(widget, offsetX, offsetY);
            });

            // Drag end
            widget.addEventListener('dragend', (e) => {
                // Clear any pending preview swap
                if (previewSwapTimeout) {
                    clearTimeout(previewSwapTimeout);
                    previewSwapTimeout = null;
                }

                // Remove all animation classes
                widgets.forEach(w => {
                    w.classList.remove('dragging', 'drag-over', 'drag-swap', 'widget-animating');
                });

                // If we haven't already swapped via preview, do it now
                if (draggedOverWidget && draggedOverWidget !== draggedWidget && !hasPreviewSwapped) {
                    this.animatedSwapWidgets(draggedWidget, draggedOverWidget);
                    this.saveWidgetOrder();
                }

                draggedWidget = null;
                draggedOverWidget = null;
                hasPreviewSwapped = false;
            });

            // Drag over
            widget.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';

                if (widget !== draggedWidget && widget !== draggedOverWidget) {
                    // Clear previous timeout
                    if (previewSwapTimeout) {
                        clearTimeout(previewSwapTimeout);
                    }

                    // Remove previous drag-over effects
                    widgets.forEach(w => {
                        w.classList.remove('drag-over', 'drag-swap');
                    });

                    // Add drag-over effect immediately
                    widget.classList.add('drag-over');

                    // Set up preview swap with delay
                    previewSwapTimeout = setTimeout(() => {
                        if (widget !== draggedWidget && !hasPreviewSwapped) {
                            this.previewSwapWidgets(draggedWidget, widget);
                            draggedOverWidget = widget;
                            hasPreviewSwapped = true;
                        }
                    }, 300); // 300ms delay before preview swap

                    draggedOverWidget = widget;
                }
            });

            // Drag enter
            widget.addEventListener('dragenter', (e) => {
                e.preventDefault();
            });

            // Drag leave
            widget.addEventListener('dragleave', (e) => {
                // Only remove drag-over if we're actually leaving the widget
                if (!widget.contains(e.relatedTarget)) {
                    // Clear timeout if leaving
                    if (previewSwapTimeout && draggedOverWidget === widget) {
                        clearTimeout(previewSwapTimeout);
                        previewSwapTimeout = null;
                    }

                    widget.classList.remove('drag-over');
                }
            });

            // Drop
            widget.addEventListener('drop', (e) => {
                e.preventDefault();
                widget.classList.remove('drag-over');
            });
        });

        // Handle drag over grid gaps
        widgetsGrid.addEventListener('dragover', (e) => {
            e.preventDefault();

            // If we're not over a widget, remove all drag-over classes
            if (!e.target.closest('.dashboard-widget')) {
                if (previewSwapTimeout) {
                    clearTimeout(previewSwapTimeout);
                    previewSwapTimeout = null;
                }
                widgets.forEach(w => w.classList.remove('drag-over', 'drag-swap'));
                draggedOverWidget = null;
            }
        });
    }

    previewSwapWidgets(widget1, widget2) {
        if (!widget1 || !widget2 || widget1 === widget2) return;

        // Add animation classes
        widget1.classList.add('widget-animating');
        widget2.classList.add('widget-animating', 'drag-swap');

        // Perform the actual DOM swap
        const grid = widget1.parentNode;
        const temp = document.createElement('div');

        // Insert temp before widget1
        grid.insertBefore(temp, widget1);

        // Move widget1 to widget2's position
        grid.insertBefore(widget1, widget2);

        // Move widget2 to temp's position
        grid.insertBefore(widget2, temp);

        // Remove temp
        temp.remove();

        // Remove animation classes after animation completes
        setTimeout(() => {
            widget1.classList.remove('widget-animating');
            widget2.classList.remove('widget-animating', 'drag-swap');
        }, 400);

        console.log('Preview swapped widgets:', widget1.dataset.widgetId, '↔', widget2.dataset.widgetId);
    }

    animatedSwapWidgets(widget1, widget2) {
        if (!widget1 || !widget2 || widget1 === widget2) return;

        // Add animation classes
        widget1.classList.add('widget-animating');
        widget2.classList.add('widget-animating');

        // Perform the actual DOM swap
        const grid = widget1.parentNode;
        const temp = document.createElement('div');

        // Insert temp before widget1
        grid.insertBefore(temp, widget1);

        // Move widget1 to widget2's position
        grid.insertBefore(widget1, widget2);

        // Move widget2 to temp's position
        grid.insertBefore(widget2, temp);

        // Remove temp
        temp.remove();

        // Remove animation classes after animation completes
        setTimeout(() => {
            widget1.classList.remove('widget-animating');
            widget2.classList.remove('widget-animating');
        }, 400);

        console.log('Animated swap completed:', widget1.dataset.widgetId, '↔', widget2.dataset.widgetId);
    }

    swapWidgets(widget1, widget2) {
        // Get parent grid
        const grid = widget1.parentNode;

        // Create temporary marker
        const temp = document.createElement('div');

        // Insert temp before widget1
        grid.insertBefore(temp, widget1);

        // Move widget1 to widget2's position
        grid.insertBefore(widget1, widget2);

        // Move widget2 to temp's position
        grid.insertBefore(widget2, temp);

        // Remove temp
        temp.remove();

        console.log('Widgets swapped:', widget1.dataset.widgetId, '↔', widget2.dataset.widgetId);
    }

    saveWidgetOrder() {
        const widgets = document.querySelectorAll('.dashboard-widget');
        const order = Array.from(widgets).map(widget => widget.dataset.widgetId);
        localStorage.setItem('dashboardWidgetOrder', JSON.stringify(order));
        console.log('Saved widget order:', order);
    }

    loadWidgetOrder() {
        const savedOrder = localStorage.getItem('dashboardWidgetOrder');
        const grid = document.querySelector('.dashboard-widgets-grid');
        if (!grid) return;

        const widgets = Array.from(grid.querySelectorAll('.dashboard-widget'));
        
        // If no saved order, use current DOM order
        if (!savedOrder) {
            console.log('No saved widget order, using default DOM order');
            return;
        }

        try {
            const order = JSON.parse(savedOrder);
            
            // Find widgets that exist in DOM but not in saved order (new widgets)
            const widgetIds = widgets.map(w => w.dataset.widgetId);
            const newWidgets = widgetIds.filter(id => !order.includes(id));
            
            // Add new widgets to the end of order
            const updatedOrder = [...order, ...newWidgets];
            
            // Sort widgets according to updated order
            updatedOrder.forEach(widgetId => {
                const widget = widgets.find(w => w.dataset.widgetId === widgetId);
                if (widget) {
                    grid.appendChild(widget);
                }
            });
            
            // Save updated order if there were new widgets
            if (newWidgets.length > 0) {
                localStorage.setItem('dashboardWidgetOrder', JSON.stringify(updatedOrder));
                console.log('Added new widgets to order:', newWidgets);
            }

            console.log('Loaded widget order:', updatedOrder);
        } catch (e) {
            console.error('Failed to load widget order:', e);
        }
    }



    // Helper method to update element text content
    updateElement(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = value;
        }
    }

    // Helper method to format date
    formatDate(dateStr) {
        if (!dateStr) return 'Unknown';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }

    // Helper function to calculate account duration
    calculateAccountDuration(startDate) {
        if (!startDate) return 'Unknown';

        const start = new Date(startDate);
        const now = new Date();
        const diffTime = Math.abs(now - start);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays < 7) {
            return `${diffDays} day${diffDays > 1 ? 's' : ''}`;
        } else if (diffDays < 30) {
            const weeks = Math.floor(diffDays / 7);
            return `${weeks} week${weeks > 1 ? 's' : ''}`;
        } else if (diffDays < 365) {
            const months = Math.floor(diffDays / 30);
            return `${months} month${months > 1 ? 's' : ''}`;
        } else {
            const years = Math.floor(diffDays / 365);
            const remainingDays = diffDays % 365;
            const months = Math.floor(remainingDays / 30);
            if (months > 0) {
                return `${years}y ${months}m`;
            }
            return `${years} year${years > 1 ? 's' : ''}`;
        }
    }

    // Format date for display
    formatDateForDisplay(dateStr) {
        if (!dateStr) return 'Unknown';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }

    // АКАУНТИ
    addAccount() {
        console.log('addAccount called - new implementation');

        // Отримуємо значення з форми
        const name = document.getElementById('account-name')?.value;
        const type = document.getElementById('account-type')?.value;
        const balance = document.getElementById('account-balance')?.value;
        const currency = document.getElementById('account-currency')?.value || 'USD';
        const broker = document.getElementById('account-broker')?.value || '';
        const description = document.getElementById('account-description')?.value || '';
        const startDate = document.getElementById('account-start-date')?.value || new Date().toISOString().split('T')[0];

        console.log('Form data:', { name, type, balance, currency, broker, description, startDate });

        // Перевіряємо обов'язкові поля
        if (!name || !type || !balance) {
            this.showNotification('Please fill in all required fields (Name, Type, Balance)', 'error');
            return;
        }

        // Статус тепер є тип акаунту
        const status = type;

        // Створюємо новий акаунт
        const newAccount = {
            id: Date.now(),
            name: name,
            type: type,
            status: status,
            startingBalance: parseFloat(balance),
            currentBalance: parseFloat(balance),
            currency: currency,
            broker: broker,
            description: description,
            createdDate: new Date().toISOString().split('T')[0],
            startDate: startDate,
            isActive: true
        };

        console.log('Creating new account:', newAccount);

        // Додаємо до масиву
        this.accounts.push(newAccount);

        // Зберігаємо та оновлюємо
        this.saveAccounts();
        this.updateAccountsDisplay();
        this.updateAllMetrics();
        this.populateAccountsSelect();

        // Закриваємо модальне вікно
        this.closeModal('add-account-modal');

        // Очищуємо форму
        const form = document.getElementById('add-account-form');
        if (form) form.reset();

        this.showNotification('Account added successfully!', 'success');
        console.log('Account added and saved successfully');
    }

    updateAccount() {
        if (!this.currentEditAccountId) {
            this.showNotification('No account selected for editing', 'error');
            return;
        }

        const accountIndex = this.accounts.findIndex(acc => acc.id === this.currentEditAccountId);
        if (accountIndex === -1) {
            this.showNotification('Account not found', 'error');
            return;
        }

        // Отримуємо значення з форми редагування
        const name = document.getElementById('edit-account-name')?.value;
        const type = document.getElementById('edit-account-type')?.value;
        const balance = document.getElementById('edit-account-balance')?.value;
        const currency = document.getElementById('edit-account-currency')?.value || 'USD';
        const broker = document.getElementById('edit-account-broker')?.value || '';
        const description = document.getElementById('edit-account-description')?.value || '';
        const startDate = document.getElementById('edit-account-start-date')?.value;

        // Перевіряємо обов'язкові поля
        if (!name || !type || !balance) {
            this.showNotification('Please fill in all required fields', 'error');
            return;
        }

        // Зберігаємо початковий баланс та дату початку
        const originalStartingBalance = this.accounts[accountIndex].startingBalance;
        const originalStartDate = this.accounts[accountIndex].startDate;

        // Оновлюємо акаунт
        this.accounts[accountIndex] = {
            ...this.accounts[accountIndex],
            name: name,
            type: type,
            status: type, // Статус = тип
            currentBalance: parseFloat(balance),
            currency: currency,
            broker: broker,
            description: description,
            startingBalance: originalStartingBalance,
            startDate: startDate || originalStartDate
        };

        // Зберігаємо та оновлюємо
        this.saveAccounts();
        this.updateAccountsDisplay();
        this.updateAllMetrics();
        this.populateAccountsSelect();

        // Закриваємо модальне вікно
        this.closeModal('edit-account-modal');

        this.showNotification('Account updated successfully!', 'success');

        // Очищуємо ID редагування
        this.currentEditAccountId = null;
    }

    editAccount(accountId) {
        console.log('Editing account:', accountId);

        const account = this.accounts.find(acc => acc.id === accountId);
        if (!account) {
            this.showNotification('Account not found', 'error');
            return;
        }

        // Зберігаємо ID акаунту для редагування
        this.currentEditAccountId = accountId;

        // Заповнюємо форму поточними даними
        document.getElementById('edit-account-name').value = account.name;
        document.getElementById('edit-account-type').value = account.status || account.type; // Використовуємо статус як тип
        document.getElementById('edit-account-balance').value = account.currentBalance;
        document.getElementById('edit-account-currency').value = account.currency;
        document.getElementById('edit-account-broker').value = account.broker || '';
        document.getElementById('edit-account-description').value = account.description || '';
        document.getElementById('edit-account-start-date').value = account.startDate || account.createdDate;

        // Відкриваємо модальне вікно
        this.showEditAccountModal();
    }

    showEditAccountModal() {
        this.closeAllModals();
        const modal = document.getElementById('edit-account-modal');
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }



    deleteAccount(accountId) {
        console.log('Deleting account:', accountId);

        this.accounts = this.accounts.filter(acc => acc.id !== accountId);
        this.saveAccounts();
        this.updateAccountsDisplay();
        this.updateAllMetrics();
        this.populateAccountsSelect();
        this.showNotification('Account deleted successfully!', 'success');
    }

    toggleAccountSection(status) {
        const section = document.querySelector(`[data-status="${status}"]`);
        if (section) {
            section.classList.toggle('collapsed');

            // Toggle the chevron rotation
            const chevron = section.querySelector('.accounts-section-toggle i[data-lucide="chevron-down"]');
            if (chevron) {
                const isCollapsed = section.classList.contains('collapsed');
                chevron.style.transform = isCollapsed ? 'rotate(-90deg)' : 'rotate(0deg)';
            }
        }
    }

    updateAccountsDisplay() {
        console.log('Updating accounts display');
        this.updateAccountsOverview();
        this.renderAccountsByStatus();
    }

    updateAccountsOverview() {
        const filteredAccounts = this.getFilteredAccounts();

        if (filteredAccounts.length === 0) {
            this.updateElement('total-accounts-capital', '$0.00');
            this.updateElement('overview-live-capital', '$0.00');
            this.updateElement('overview-challenge-capital', '$0.00');
            this.updateElement('best-performer-account', '-');
            this.updateElement('average-growth-percent', '0.0%');
            this.updateElement('total-accounts-pnl', '$0.00');
            return;
        }

        // Calculate real capital including trades P&L for each account
        let totalCapital = 0;
        let totalPnl = 0;
        let totalStartingBalance = 0;
        let liveCapital = 0;
        let challengeCapital = 0;
        let bestPerformer = null;
        let bestPnl = -Infinity;

        filteredAccounts.forEach(account => {
            // Get all trades for this account
            const accountTrades = this.trades.filter(trade => trade.accountId === account.id);
            const tradesPnl = accountTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

            // Get all payouts for this account
            const accountPayouts = this.payouts ? this.payouts.filter(payout => payout.accountId === account.id) : [];
            const payoutAmount = accountPayouts.reduce((sum, payout) => sum + (payout.amount || 0), 0);

            // Calculate real current balance including trades and subtracting payouts
            const realCurrentBalance = account.startingBalance + tradesPnl - payoutAmount;
            // Net P&L should only include trades, not payouts
            const accountPnl = tradesPnl;

            totalCapital += realCurrentBalance;
            totalPnl += accountPnl;
            totalStartingBalance += account.startingBalance;

            // Split by account types
            if (account.type === 'Live') {
                liveCapital += realCurrentBalance;
            } else {
                challengeCapital += realCurrentBalance;
            }

            // Find best performer based on trades P&L only
            if (accountPnl > bestPnl) {
                bestPnl = accountPnl;
                bestPerformer = account;
            }
        });

        // Calculate average growth
        const averageGrowth = totalStartingBalance > 0 ? (totalPnl / totalStartingBalance) * 100 : 0;

        // Update elements with proper positive/negative styling
        this.updateElement('total-accounts-capital', `$${totalCapital.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
        this.updateElement('overview-live-capital', `$${liveCapital.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
        this.updateElement('overview-challenge-capital', `$${challengeCapital.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);

        if (bestPerformer) {
            this.updateElement('best-performer-account', bestPerformer.name);
        } else {
            this.updateElement('best-performer-account', '-');
        }

        // Update P&L with styling
        const pnlElement = document.getElementById('total-accounts-pnl');
        if (pnlElement) {
            pnlElement.textContent = `${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            pnlElement.className = 'metric-value ' + (totalPnl >= 0 ? 'positive' : 'negative');
        }

        // Update growth with styling
        const growthElement = document.getElementById('average-growth-percent');
        if (growthElement) {
            growthElement.textContent = `${averageGrowth >= 0 ? '+' : ''}${averageGrowth.toFixed(1)}%`;
            growthElement.className = 'metric-value ' + (averageGrowth >= 0 ? 'positive' : 'negative');
        }
    }

    renderAccountsByStatus() {
        const container = document.getElementById('accounts-sections');
        if (!container) {
            console.error('Accounts sections container not found');
            return;
        }

        // Use filtered accounts for display
        const filteredAccounts = this.getFilteredAccounts();

        if (filteredAccounts.length === 0) {
            container.innerHTML = `
                <div class="empty-accounts-state">
                    <div class="empty-message">
                        <i data-lucide="filter"></i>
                        <h3>No matching accounts</h3>
                        <p>Adjust your account filter to see accounts</p>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Розподіляємо ВІДФІЛЬТРОВАНІ акаунти за статусами в правильному порядку
        const accountsByStatus = {
            'Live': filteredAccounts.filter(acc => acc.type === 'Live' || acc.status === 'Live'),
            'Phase 2': filteredAccounts.filter(acc => acc.status === 'Phase 2'),
            'Phase 1': filteredAccounts.filter(acc => acc.status === 'Phase 1' || (acc.type === 'Challenge' && !acc.status)),
            'Passed': filteredAccounts.filter(acc => acc.status === 'Passed'),
            'Failed': filteredAccounts.filter(acc => acc.status === 'Failed')
        };

        let html = '';

        // Створюємо секції тільки для тих статусів, де є акаунти
        Object.entries(accountsByStatus).forEach(([status, accounts]) => {
            if (accounts.length > 0) {
                const statusClass = status.toLowerCase().replace(' ', '');
                html += `
                    <div class="accounts-section" data-status="${status}">
                        <div class="accounts-section-header" onclick="window.app.toggleAccountSection('${status}')">
                            <div class="section-badge ${statusClass}-badge">
                                <i data-lucide="circle"></i>
                                ${status}
                            </div>
                            <button class="accounts-section-toggle">
                                <i data-lucide="chevron-down"></i>
                            </button>
                        </div>
                        <div class="accounts-list">
                            ${accounts.map(account => this.renderAccountCard(account)).join('')}
                        </div>
                    </div>
                `;
            }
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
        console.log('Accounts rendered by status with', this.accounts.length, 'total accounts');
    }

    renderAccountCard(account) {
        // Get all trades (main + subtrades) for this account
        const allAccountTrades = this.trades.filter(trade => trade.accountId === account.id);

        // Calculate current balance including all profits/losses from trades and subtrades, minus payouts
        const totalTradesPnl = allAccountTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        const accountPayouts = this.payouts ? this.payouts.filter(payout => payout.accountId === account.id) : [];
        const payoutAmount = accountPayouts.reduce((sum, payout) => sum + (payout.amount || 0), 0);
        const currentBalance = account.startingBalance + totalTradesPnl - payoutAmount;

        // Calculate net P&L from trades only (excluding payouts)
        const netPnl = totalTradesPnl;
        const netPnlPercent = account.startingBalance > 0 ? (netPnl / account.startingBalance) * 100 : 0;
        const pnlClass = netPnl >= 0 ? 'positive' : 'negative';

        // Real statistics from actual trades and subtrades for this account
        const totalTrades = allAccountTrades.length;

        const winTrades = allAccountTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        }).length;

        const lossTrades = allAccountTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        }).length;

        // Win rate calculation (exclude BE trades)
        const tradesForWinRate = winTrades + lossTrades;
        const winRate = tradesForWinRate > 0 ? (winTrades / tradesForWinRate) * 100 : 0;

        // Average RR from actual trades and subtrades
        const totalRR = allAccountTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0);
        const avgRR = allAccountTrades.length > 0 ? totalRR / allAccountTrades.length : 0;

        // Calculate max drawdown based on running balance through trades and subtrades
        let maxDrawdown = 0;
        let runningBalance = account.startingBalance;
        let peak = account.startingBalance;

        const sortedTrades = allAccountTrades.sort((a, b) => {
            const dateA = new Date(a.date || a.entryDate);
            const dateB = new Date(b.date || b.entryDate);
            return dateA.getTime() - dateB.getTime();
        });

        sortedTrades.forEach(trade => {
            runningBalance += (trade.pnl || 0);
            if (runningBalance > peak) peak = runningBalance;
            const drawdown = peak > 0 ? ((peak - runningBalance) / peak) * 100 : 0;
            if (drawdown > maxDrawdown) maxDrawdown = drawdown;
        });

        // Duration and date calculations
        const duration = this.calculateAccountDuration(account.startDate);
        const startDateFormatted = this.formatDateForDisplay(account.startDate);

        return `
            <div class="account-card-sleek">
                <div class="account-card-header">
                    <div class="account-title-section">
                        <div class="account-name">${account.name}</div>
                        <div class="account-type-badge ${account.type.toLowerCase().replace(' ', '')}">
                            <div class="badge-indicator"></div>
                            ${account.type}
                        </div>
                    </div>
                    <div class="action-menu-container">
                        <button class="action-menu-btn" onclick="event.stopPropagation(); window.app.showActionMenu(this, 'account', {accountId: ${account.id}})">
                            <i data-lucide="more-horizontal"></i>
                        </button>
                        <div class="action-menu" style="display: none;">
                            <div class="action-menu-item action-edit" onclick="event.stopPropagation(); window.app.editAccount(${account.id}); this.closest('.action-menu').style.display = 'none';">
                                <i data-lucide="edit-2"></i>
                                <span>Edit</span>
                            </div>
                            <div class="action-menu-item action-delete" onclick="event.stopPropagation(); window.app.deleteAccount(${account.id}); this.closest('.action-menu').style.display = 'none';">
                                <i data-lucide="trash-2"></i>
                                <span>Delete</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="account-balance-section">
                    <div class="balance-amount">$${currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    <div class="balance-change ${pnlClass}">
                        ${netPnl >= 0 ? '+' : ''}$${Math.abs(netPnl).toFixed(2)} (${netPnlPercent >= 0 ? '+' : ''}${netPnlPercent.toFixed(1)}%)
                    </div>
                </div>

                <div class="account-timeline">
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <i data-lucide="calendar"></i>
                        </div>
                        <div class="timeline-content">
                            <div class="timeline-label">Started</div>
                            <div class="timeline-value">${startDateFormatted}</div>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-icon">
                            <i data-lucide="clock"></i>
                        </div>
                        <div class="timeline-content">
                            <div class="timeline-label">Duration</div>
                            <div class="timeline-value">${duration}</div>
                        </div>
                    </div>
                </div>

                <div class="account-stats-grid">
                    <div class="stat-item">
                        <div class="stat-value">${totalTrades}</div>
                        <div class="stat-label">Trades</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${winRate.toFixed(0)}%</div>
                        <div class="stat-label">Win Rate</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${avgRR.toFixed(1)}</div>
                        <div class="stat-label">Avg RR</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value negative">-${maxDrawdown.toFixed(1)}%</div>
                        <div class="stat-label">Max DD</div>
                    </div>
                </div>

                <div class="account-broker-tag">
                    <i data-lucide="building"></i>
                    ${account.broker || 'No Broker'}
                </div>
            </div>
        `;
    }

    // Заповнення селекту акаунтів
    populateAccountsSelect() {
        const accountSelects = document.querySelectorAll('.trade-account-select');

        accountSelects.forEach(select => {
            if (select) {
                select.innerHTML = '<option value="">Select Account</option>';
                this.accounts.forEach(account => {
                    const statusDisplay = account.status || account.type;
                    select.innerHTML += `<option value="${account.id}">${account.name} (${statusDisplay})</option>`;
                });
            }
        });

        console.log('Populated account selects for', accountSelects.length, 'elements with', this.accounts.length, 'accounts');
    }

    // ТРЕЙДИ
    getNextTradeNumber() {
        // Find the highest trade number and add 1
        const maxTradeNumber = this.trades.reduce((max, trade) => {
            return Math.max(max, trade.tradeNumber || 0);
        }, 0);
        return maxTradeNumber + 1;
    }

    addTrade() {
        const symbolEl = document.getElementById('trade-symbol');
        const directionEl = document.getElementById('trade-direction');
        const strategyEl = document.getElementById('trade-strategy');
        const resultEl = document.getElementById('trade-result');
        const entryDateEl = document.getElementById('trade-entry-date');
        const exitDateEl = document.getElementById('trade-exit-date');
        const pnlEl = document.getElementById('trade-pnl');
        const riskEl = document.getElementById('trade-risk');
        const rrEl = document.getElementById('trade-rr');
        const accountEl = document.getElementById('trade-account');
        const notesEl = document.getElementById('trade-notes');
        const sessionEl = document.getElementById('trade-session');

        if (!symbolEl?.value || !directionEl?.value || !strategyEl?.value || !resultEl?.value || !entryDateEl?.value || !pnlEl?.value || !riskEl?.value) {
            this.showNotification('Please fill in required fields (Pair, Direction, Strategy, Result, Entry Date, Risk, Profit)', 'error');
            return;
        }

        if (!accountEl?.value) {
            this.showNotification('Please select an account for this trade', 'error');
            return;
        }

        const pnl = parseFloat(pnlEl.value) || 0;
        const risk = parseFloat(riskEl.value) || 0;

        // Assign next trade number
        const nextTradeNumber = this.getNextTradeNumber();

        const entryTimeframesEl = document.getElementById('trade-entry-timeframes');

        const trade = {
            id: Date.now(),
            tradeNumber: nextTradeNumber,
            symbol: symbolEl.value,
            direction: directionEl.value,
            strategy: strategyEl.value,
            result: resultEl.value,
            entryDate: entryDateEl.value,
            exitDate: exitDateEl?.value || entryDateEl.value,
            pnl: pnl,
            risk: risk,
            riskReward: parseFloat(rrEl?.value) || 0,
            notes: notesEl?.value || '',
            screenshot: null,
            date: entryDateEl.value,
            accountId: parseInt(accountEl.value) || null,
            entryTimeframes: entryTimeframesEl?.value || '',
            session: sessionEl?.value || null
        };

        // Обробка скріншотів (множинні)
        const preview = document.getElementById('screenshot-preview');
        const imgs = preview?.querySelectorAll('img');
        const screenshots = [];
        if (imgs && imgs.length > 0) {
            imgs.forEach(img => {
                screenshots.push(img.src);
            });
        }
        trade.screenshots = screenshots;
        trade.screenshot = screenshots.length > 0 ? screenshots[0] : null; // Зберігаємо для сумісності

        this.trades.push(trade);

        // Update strategy last used date
        if (trade.strategy) {
            const strategy = this.strategies.find(s => s.name === trade.strategy);
            if (strategy) {
                strategy.lastUsed = new Date().toISOString();
                this.saveStrategies();
            }
        }

        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateCharts();
        this.renderCalendar();
        this.populateFilters();
        this.updateStrategiesDisplay();
        this.updateEntryTimeframesWidget();
        this.closeModal('add-trade-modal');
        this.showNotification('Trade added successfully!', 'success');
    }

    deleteTrade(tradeId) {
        this.trades = this.trades.filter(trade => trade.id !== tradeId);
        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateCharts();
        this.renderCalendar();
        this.populateFilters();
        this.updateEntryTimeframesWidget();
        this.showNotification('Trade deleted successfully!', 'success');
    }

    editTrade(tradeId) {
        console.log('Editing trade:', tradeId);

        // First, try to find trade in main trades array
        let trade = this.trades.find(t => t.id === tradeId);

        // Check if it's a subtrade (standalone entry with parentTradeId)
        if (trade && trade.parentTradeId) {
            console.log('Found standalone subtrade with parentTradeId:', trade.parentTradeId);
            this.editSubtradeDirectly(trade);
            return;
        }

        // If not found in main array, check if it's a subtrade in parent trades
        if (!trade) {
            console.log('Trade not found in main array, checking subtrades...');
            for (const parentTrade of this.trades) {
                if (parentTrade.subtrades && parentTrade.subtrades.length > 0) {
                    const subtrade = parentTrade.subtrades.find(st => st.id === tradeId);
                    if (subtrade) {
                        console.log('Found subtrade in parent trade:', parentTrade.id);
                        // Found subtrade, create a temporary trade object for editing
                        trade = {
                            ...subtrade,
                            parentTradeId: parentTrade.id
                        };
                        this.editSubtradeDirectly(trade);
                        return;
                    }
                }
            }
        }

        if (!trade) {
            console.log('Trade with ID', tradeId, 'not found anywhere');
            console.log('Available trades:', this.trades.map(t => ({ id: t.id, parentTradeId: t.parentTradeId })));

            // Спробуємо ще раз перевірити всі трейди включаючи субтрейди
            const allTradesFlat = [];
            this.trades.forEach(mainTrade => {
                allTradesFlat.push(mainTrade);
                if (mainTrade.subtrades) {
                    mainTrade.subtrades.forEach(sub => {
                        allTradesFlat.push({...sub, parentTradeId: mainTrade.id});
                    });
                }
            });

            const foundTrade = allTradesFlat.find(t => t.id === tradeId);
            if (foundTrade) {
                console.log('Found trade in flattened search:', foundTrade);
                if (foundTrade.parentTradeId) {
                    this.editSubtradeDirectly(foundTrade);
                } else {
                    trade = foundTrade;
                }
            } else {
                this.showNotification('Trade not found. It may have been deleted.', 'error');
                this.updateAllTables();
                return;
            }
        }

        // Зберігаємо ID трейду для редагування
        this.currentEditTradeId = tradeId;
        this.currentEditingTrade = tradeId;
        this.currentEditSubtradeId = null;
        
        // Відкриваємо side panel для редагування
        this.openTradePanel('edit', trade);
    }

    showEditTradeModal() {
        console.log('Opening edit trade side panel...');
        if (this.currentEditingTrade) {
            const trade = this.trades.find(t => t.id === this.currentEditingTrade);
            if (trade) {
                this.openTradePanel('edit', trade);
            }
        }
    }

    updateTrade() {
        if (!this.currentEditTradeId) {
            this.showNotification('No trade selected for editing', 'error');
            return;
        }

        // Check if we're editing a subtrade
        if (this.currentEditSubtradeId) {
            return this.updateSubtrade();
        }

        const tradeIndex = this.trades.findIndex(trade => trade.id === this.currentEditTradeId);
        if (tradeIndex === -1) {
            this.showNotification('Trade not found', 'error');
            return;
        }

        // Отримуємо значення з форми редагування
        const entryDate = document.getElementById('edit-trade-entry-date')?.value;
        const exitDate = document.getElementById('edit-trade-exit-date')?.value;
        const symbol = document.getElementById('edit-trade-symbol')?.value;
        const direction = document.getElementById('edit-trade-direction')?.value;
        const strategy = document.getElementById('edit-trade-strategy')?.value;
        const result = document.getElementById('edit-trade-result')?.value;
        const risk = document.getElementById('edit-trade-risk')?.value;
        const pnl = document.getElementById('edit-trade-pnl')?.value;
        const rr = document.getElementById('edit-trade-rr')?.value;
        const accountId = document.getElementById('edit-trade-account')?.value;
        const notes = document.getElementById('edit-trade-notes')?.value;
        const entryTimeframes = document.getElementById('edit-trade-entry-timeframes')?.value;
        const session = document.getElementById('edit-trade-session')?.value;

        // Перевіряємо обов'язкові поля
        if (!entryDate || !symbol || !direction || !strategy || !result || !pnl || !risk) {
            this.showNotification('Please fill in required fields (Entry Date, Pair, Direction, Strategy, Result, Risk, Profit)', 'error');
            return;
        }

        if (!accountId) {
            this.showNotification('Please select an account for this trade', 'error');
            return;
        }

        // Обробка скріншотів (множинні)
        const editPreview = document.getElementById('edit-screenshot-preview');
        const imgs = editPreview?.querySelectorAll('img');
        const screenshots = [];
        if (imgs && imgs.length > 0) {
            imgs.forEach(img => {
                screenshots.push(img.src);
            });
        }
        let screenshot = screenshots.length > 0 ? screenshots[0] : null;

        // Оновлюємо трейд
        this.trades[tradeIndex] = {
            ...this.trades[tradeIndex],
            entryDate: entryDate,
            exitDate: exitDate || entryDate,
            symbol: symbol,
            direction: direction,
            strategy: strategy,
            result: result,
            risk: parseFloat(risk) || 1,
            pnl: parseFloat(pnl) || 0,
            riskReward: parseFloat(rr) || 0,
            accountId: parseInt(accountId) || null,
            notes: notes || '',
            screenshot: screenshot,
            screenshots: screenshots,
            date: entryDate, // Також оновлюємо поле date для сумісності
            entryTimeframes: entryTimeframes || '',
            session: session || null
        };

        // Зберігаємо та оновлюємо
        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateCharts();
        this.renderCalendar();
        this.populateFilters();
        this.updateEntryTimeframesWidget();

        // Закриваємо модальне вікно
        this.closeModal('edit-trade-modal');

        this.showNotification('Trade updated successfully!', 'success');

        // Очищуємо ID редагування
        this.currentEditTradeId = null;
    }

    updateSubtrade() {
        if (!this.currentEditTradeId || !this.currentEditSubtradeId) {
            this.showNotification('No subtrade selected for editing', 'error');
            return;
        }

        // Знаходимо батьківський трейд
        const trade = this.trades.find(t => t.id === this.currentEditTradeId);

        // Знаходимо субтрейд в основному масиві
        const mainTradeIndex = this.trades.findIndex(t => t.id === this.currentEditSubtradeId && t.parentTradeId === this.currentEditTradeId);

        // Знаходимо субтрейд в батьківському масиві (якщо існує)
        let subtradeIndex = -1;
        if (trade && trade.subtrades) {
            subtradeIndex = trade.subtrades.findIndex(st => st.id === this.currentEditSubtradeId);
        }

        if (mainTradeIndex === -1 && subtradeIndex === -1) {
            this.showNotification('Subtrade not found in any location', 'error');
            return;
        }

        // Отримуємо значення з форми редагування
        const entryDate = document.getElementById('edit-trade-entry-date')?.value;
        const exitDate = document.getElementById('edit-trade-exit-date')?.value;
        const symbol = document.getElementById('edit-trade-symbol')?.value;
        const direction = document.getElementById('edit-trade-direction')?.value;
        const strategy = document.getElementById('edit-trade-strategy')?.value;
        const result = document.getElementById('edit-trade-result')?.value;
        const accountId = document.getElementById('edit-trade-account')?.value;
        const risk = document.getElementById('edit-trade-risk')?.value;
        const pnl = document.getElementById('edit-trade-pnl')?.value;
        const rr = document.getElementById('edit-trade-rr')?.value;
        const notes = document.getElementById('edit-trade-notes')?.value;
        const entryTimeframes = document.getElementById('edit-trade-entry-timeframes')?.value;

        // Перевіряємо обов'язкові поля
        if (!entryDate || !symbol || !direction || !strategy || !result || !pnl || !risk) {
            this.showNotification('Please fill in required fields (Entry Date, Pair, Direction, Strategy, Result, Risk, Profit)', 'error');
            return;
        }

        if (!accountId) {
            this.showNotification('Please select an account for this subtrade', 'error');
            return;
        }

        // Обробка скріншоту
        const editPreview = document.getElementById('edit-screenshot-preview');
        const imgs = editPreview?.querySelectorAll('img');
        const screenshots = [];
        if (imgs && imgs.length > 0) {
            imgs.forEach(img => {
                screenshots.push(img.src);
            });
        }
        let screenshot = screenshots.length > 0 ? screenshots[0] : null;

        // Update subtrade data
        const updatedSubtradeData = {
            entryDate: entryDate,
            exitDate: exitDate || entryDate,
            symbol: symbol,
            direction: direction,
            strategy: strategy,
            result: result,
            accountId: parseInt(accountId) || null,
            risk: parseFloat(risk) || 1,
            pnl: parseFloat(pnl) || 0,
            riskReward: parseFloat(rr) || 0,
            notes: notes || '',
            screenshot: screenshot,
            screenshots: screenshots,
            entryTimeframes: entryTimeframes || ''
        };

        // Оновлюємо субтрейд у батьківському трейді (якщо існує)
        if (trade && trade.subtrades && subtradeIndex !== -1) {
            trade.subtrades[subtradeIndex] = {
                ...trade.subtrades[subtradeIndex],
                ...updatedSubtradeData
            };
        }

        // Оновлюємо субтрейд у основному масиві trades (завжди має існувати)
        if (mainTradeIndex !== -1) {
            this.trades[mainTradeIndex] = {
                ...this.trades[mainTradeIndex],
                ...updatedSubtradeData,
                date: entryDate, // Also update date field for compatibility
                parentTradeId: this.currentEditTradeId // Ensure parentTradeId is preserved
            };
        } else {
            // Якщо не знайшли в основному масиві, створюємо новий запис
            const newSubtradeEntry = {
                id: this.currentEditSubtradeId,
                parentTradeId: this.currentEditTradeId,
                date: entryDate,
                tradeNumber: trade.subtrades ? trade.subtrades.length : 1,
                ...updatedSubtradeData
            };
            this.trades.push(newSubtradeEntry);
        }

        // Зберігаємо та оновлюємо
        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateCharts();
        this.renderCalendar();
        this.populateFilters();
        this.updateEntryTimeframesWidget();

        // Закриваємо модальне вікно
        this.closeModal('edit-trade-modal');

        this.showNotification('Subtrade updated successfully!', 'success');

        // Очищуємо ID редагування
        this.currentEditTradeId = null;
        this.currentEditSubtradeId = null;

        // Reset modal title
        const modalTitle = document.querySelector('#edit-trade-modal .modal-header h2');
        if (modalTitle) {
            modalTitle.innerHTML = '<i data-lucide="edit"></i> Edit Trade';
        }

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }



    // ОНОВЛЕННЯ ВІДОБРАЖЕННЯ
    updateAllMetrics() {
        const stats = this.calculateStats();

        // Update dashboard widgets with real data
        this.updateDashboardWidgets();

        this.updateElement('total-trades', stats.totalTrades.toString());
        this.updateElement('win-rate', `${stats.winRate.toFixed(1)}%`);
        this.updateElement('net-profit', `$${stats.totalPnl.toFixed(2)}`);
        this.updateElement('average-rr', stats.avgRiskReward.toFixed(2));
        this.updateElement('max-drawdown', `${stats.maxDrawdown.toFixed(2)}%`);

        // Заголовок з правильними відсотками
        this.updateElement('today-pnl', `${stats.todayPnl >= 0 ? '+' : ''}$${stats.todayPnl.toFixed(2)} (${stats.todayPnlPercent >= 0 ? '+' : ''}${stats.todayPnlPercent.toFixed(2)}%)`);
        this.updateElement('month-pnl', `$${stats.monthPnl.toFixed(2)} (${stats.monthPnlPercent >= 0 ? '+' : ''}${stats.monthPnlPercent.toFixed(2)}%)`);
        this.updateElement('header-win-rate', `${stats.winRate.toFixed(1)}%`);

        // Капітал - новий розрахунок з урахуванням акаунтів та профіту трейдів
        const capitalData = this.calculateCapitalMetrics();
        this.updateElement('live-capital', `$${capitalData.liveCapital.toFixed(2)}`);
        this.updateElement('challenge-capital', `$${capitalData.challengeCapital.toFixed(2)}`);

        // Розподіл
        this.updateElement('winning-count', `${stats.winCount} wins`);
        this.updateElement('losing-count', `${stats.lossCount} losses`);
        this.updateElement('breakeven-count', `${stats.beCount} BE`);

        // ✅ Trades page metrics panel - використовуємо ті ж статистики включаючи субтрейди та фільтрацію
        this.updateElement('trades-total-trades', stats.totalTrades.toString());
        this.updateElement('trades-win-rate', `${stats.winRate.toFixed(1)}%`);
        this.updateElement('trades-net-profit', `$${stats.totalPnl.toFixed(2)} (${stats.totalPnlPercent >= 0 ? '+' : ''}${stats.totalPnlPercent.toFixed(2)}%)`);

        // Capital in trades section
        this.updateElement('trades-capital-total', `$${capitalData.totalCapital.toFixed(2)}`);
        const tradesCapitalEl = document.getElementById('trades-capital-total');
        if (tradesCapitalEl) {
            tradesCapitalEl.className = 'metric-value ' + (capitalData.totalCapital >= 0 ? 'positive' : 'negative');
        }

        // Color coding for trades metrics
        const tradesNetProfitEl = document.getElementById('trades-net-profit');
        if (tradesNetProfitEl) {
            tradesNetProfitEl.className = 'metric-value ' + (stats.totalPnl >= 0 ? 'positive' : 'negative');
        }

        // Update capital metrics
        this.updateCapitalMetrics();

        // Update equity chart if container exists
        const container = document.getElementById('equity-curve-chart');
        if (container && typeof d3 !== 'undefined') {
            this.updateEquityCurve();
        }

        // Update entry timeframes widget
        this.updateEntryTimeframesWidget();
    }



    calculateCapitalMetrics() {
        // Use filtered accounts and trades
        const filteredAccounts = this.getFilteredAccounts();
        const selectedAccountIds = this.getSelectedAccountIds();

        // Розрахунок капіталу акаунтів по типах
        const liveAccounts = filteredAccounts.filter(acc => 
            acc.type === 'Live' || acc.status === 'Live'
        );
        const challengeAccounts = filteredAccounts.filter(acc => 
            acc.type === 'Phase 1' || acc.status === 'Phase 1' || 
            acc.type === 'Phase 2' || acc.status === 'Phase 2'
        );

        // Сумарний капітал з акаунтів (без профіту з трейдів)
        const liveCapitalFromAccounts = liveAccounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);
        const challengeCapitalFromAccounts = challengeAccounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);

        // Просто використовуємо відфільтровані трейди (основні + субтрейди)
        const allTrades = this.getFilteredTrades();

        // Загальний профіт з трейдів та субтрейдів (з відфільтрованих)
        const totalTradesPnl = allTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

        // ОСНОВНЕ ЧИСЛО: сума всіх акаунтів + профіт з трейдів
        const totalAccountsCapital = liveCapitalFromAccounts + challengeCapitalFromAccounts;
        const totalCapital = totalAccountsCapital + totalTradesPnl;

        // РОЗПОДІЛ для відображення Live/Challenge внизу
        // Live: тільки Live акаунти + їх частка профіту
        let liveProfitShare = 0;
        let challengeProfitShare = 0;

        if (totalAccountsCapital > 0) {
            // Розподіляємо профіт пропорційно капіталу акаунтів
            liveProfitShare = (liveCapitalFromAccounts / totalAccountsCapital) * totalTradesPnl;
            challengeProfitShare = (challengeCapitalFromAccounts / totalAccountsCapital) * totalTradesPnl;
        } else {
            // Якщо немає акаунтів, весь профіт йде в challenge
            challengeProfitShare = totalTradesPnl;
        }

        const liveCapital = liveCapitalFromAccounts + liveProfitShare;
        const challengeCapital = challengeCapitalFromAccounts + challengeProfitShare;

        return {
            liveCapital,
            challengeCapital,
            totalCapital,
            totalTradesPnl,
            liveAccounts: liveAccounts.length,
            challengeAccounts: challengeAccounts.length
        };
    }

    calculateStats() {
        const today = new Date().toISOString().split('T')[0];
        const thisMonth = new Date().getMonth();
        const thisYear = new Date().getFullYear();

        // Використовуємо відфільтровані трейди (основні + субтрейди)
        const allTrades = this.getFilteredTrades();

        if (!allTrades || allTrades.length === 0) {
            return {
                totalPnl: 0, totalTrades: 0, winCount: 0, lossCount: 0, beCount: 0,
                winRate: 0, todayPnl: 0, monthPnl: 0, avgRiskReward: 0,
                maxDrawdown: 0, totalPnlPercent: 0, todayPnlPercent: 0, monthPnlPercent: 0
            };
        }

        // Отримуємо початкові баланси відфільтрованих акаунтів
        const filteredAccounts = this.getFilteredAccounts();
        const totalStartingBalance = filteredAccounts.reduce((sum, acc) => sum + (acc.startingBalance || 0), 0) || 10000;

        // Total P&L
        const totalPnl = allTrades.reduce((sum, trade) => {
            const pnl = trade.pnl;
            return sum + (pnl !== undefined && pnl !== null ? pnl : 0);
        }, 0);
        const totalTrades = allTrades.length;

        // Розрахунок профіту у відсотках від початкових балансів
        const totalPnlPercent = totalStartingBalance > 0 ? (totalPnl / totalStartingBalance) * 100 : 0;

        // Розрахунок win rate на основі статусу трейду
        const winCount = allTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        }).length;

        const lossCount = allTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        }).length;

        const beCount = allTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'be' || result.toLowerCase() === 'breakeven');
        }).length;

        // BE угоди не враховуються у win rate - тільки wins та losses
        const tradesForWinRate = winCount + lossCount;
        const winRate = tradesForWinRate > 0 ? (winCount / tradesForWinRate) * 100 : 0;

        // Today P&L
        const todayTrades = allTrades.filter(trade => 
            (trade.date === today) || (trade.entryDate === today)
        );
        const todayPnl = todayTrades.reduce((sum, trade) => {
            const pnl = trade.pnl;
            return sum + (pnl !== undefined && pnl !== null ? pnl : 0);
        }, 0);
        const todayPnlPercent = totalStartingBalance > 0 ? (todayPnl / totalStartingBalance) * 100 : 0;

        // Month P&L
        const monthTrades = allTrades.filter(trade => {
            const date = new Date(trade.date || trade.entryDate);
            return date.getMonth() === thisMonth && date.getFullYear() === thisYear;
        });
        const monthPnl = monthTrades.reduce((sum, trade) => {
            const pnl = trade.pnl;
            return sum + (pnl !== undefined && pnl !== null ? pnl : 0);
        }, 0);
        const monthPnlPercent = totalStartingBalance > 0 ? (monthPnl / totalStartingBalance) * 100 : 0;

        // Average Risk Reward
        const avgRiskReward = allTrades.length > 0 ?
            allTrades.reduce((sum, trade) => {
                const rr = trade.riskReward;
                return sum + (rr !== undefined && rr !== null ? rr : 0);
            }, 0) / allTrades.length : 0;

        // Максимальне просідання
        let maxDrawdown = 0;
        const startingBalance = totalStartingBalance;
        let peak = startingBalance;
        let running = startingBalance;

        const sortedTrades = allTrades.sort((a, b) => {
            try {
                const dateA = new Date(a.date || a.entryDate);
                const dateB = new Date(b.date || b.entryDate);
                return dateA.getTime() - dateB.getTime();
            } catch {
                return 0;
            }
        });

        sortedTrades.forEach(trade => {
            const pnl = trade.pnl;
            const tradePnl = pnl !== undefined && pnl !== null ? pnl : 0;
            running += tradePnl;
            if (running > peak) peak = running;
            const drawdown = peak > 0 ? ((peak - running) / peak) * 100 : 0;
            if (drawdown > maxDrawdown) maxDrawdown = drawdown;
        });

        return {
            totalPnl, totalTrades, winCount, lossCount, beCount, winRate,
            todayPnl, monthPnl, avgRiskReward, maxDrawdown,
            totalPnlPercent, todayPnlPercent, monthPnlPercent
        };
    }

    updateElement(id, text) {
        const element = document.getElementById(id);
        if (element) element.textContent = text;
    }

    updateCapitalMetrics() {
        const filteredAccounts = this.getFilteredAccounts();
        const capitalData = this.calculateCapitalMetrics();

        // Update total capital
        this.updateElement('capital-total-display', `$${capitalData.totalCapital.toFixed(2)}`);

        // Calculate account breakdowns
        const liveAccounts = filteredAccounts.filter(acc => acc.type === 'Live' || acc.status === 'Live');
        const phase2Accounts = filteredAccounts.filter(acc => acc.type === 'Phase 2' || acc.status === 'Phase 2');
        const phase1Accounts = filteredAccounts.filter(acc => 
            acc.type === 'Phase 1' || acc.status === 'Phase 1' || 
            (acc.type === 'Challenge' && !acc.status)
        );

        // Calculate capital amounts
        const liveCapital = liveAccounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);
        const phase2Capital = phase2Accounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);
        const phase1Capital = phase1Accounts.reduce((sum, acc) => sum + (acc.currentBalance || 0), 0);

        // Get DOM elements for capital items
        const liveItem = document.querySelector('.capital-item.live');
        const phase2Item = document.querySelector('.capital-item.phase2');
        const phase1Item = document.querySelector('.capital-item.phase1');

        // Show/hide capital items based on whether they have capital > 0
        if (liveItem) {
            if (liveCapital > 0) {
                liveItem.style.display = 'flex';
                this.updateElement('capital-live-amount', `$${liveCapital.toFixed(2)}`);
                this.updateElement('capital-live-accounts', `${liveAccounts.length} account${liveAccounts.length !== 1 ? 's' : ''}`);
            } else {
                liveItem.style.display = 'none';
            }
        }

        if (phase2Item) {
            if (phase2Capital > 0) {
                phase2Item.style.display = 'flex';
                this.updateElement('capital-phase2-amount', `$${phase2Capital.toFixed(2)}`);
                this.updateElement('capital-phase2-accounts', `${phase2Accounts.length} account${phase2Accounts.length !== 1 ? 's' : ''}`);
            } else {
                phase2Item.style.display = 'none';
            }
        }

        if (phase1Item) {
            if (phase1Capital > 0) {
                phase1Item.style.display = 'flex';
                this.updateElement('capital-phase1-amount', `$${phase1Capital.toFixed(2)}`);
                this.updateElement('capital-phase1-accounts', `${phase1Accounts.length} account${phase1Accounts.length !== 1 ? 's' : ''}`);
            } else {
                phase1Item.style.display = 'none';
            }
        }

        // Update progress bar - only show segments for accounts with capital > 0
        const totalCapital = liveCapital + phase2Capital + phase1Capital;
        if (totalCapital > 0) {
            const livePercent = liveCapital > 0 ? (liveCapital / totalCapital) * 100 : 0;
            const phase2Percent = phase2Capital > 0 ? (phase2Capital / totalCapital) * 100 : 0;
            const phase1Percent = phase1Capital > 0 ? (phase1Capital / totalCapital) * 100 : 0;

            const liveProgress = document.getElementById('progress-live');
            const phase2Progress = document.getElementById('progress-phase2');
            const phase1Progress = document.getElementById('progress-phase1');

            if (liveProgress) {
                liveProgress.style.width = `${livePercent}%`;
                liveProgress.style.display = liveCapital > 0 ? 'block' : 'none';
            }
            if (phase2Progress) {
                phase2Progress.style.width = `${phase2Percent}%`;
                phase2Progress.style.display = phase2Capital > 0 ? 'block' : 'none';
            }
            if (phase1Progress) {
                phase1Progress.style.width = `${phase1Percent}%`;
                phase1Progress.style.display = phase1Capital > 0 ? 'block' : 'none';
            }
        }
    }

    updateAllTables() {
        this.updateTradesTable('recent-trades-body', 5);
        this.updateTradesTable('all-trades-body');
        
        // Застосувати ширину колонок після рендерингу
        setTimeout(() => this.applyColumnWidthsToAllTables(), 0);
    }

    updateTradesTable(tableBodyId, limit = null) {
        const tbody = document.getElementById(tableBodyId);
        if (!tbody) return;

        // Use filtered trades instead of all trades
        let trades = [...this.getFilteredTrades()].sort((a, b) => {
            const dateA = new Date(a.date || a.entryDate);
            const dateB = new Date(b.date || b.entryDate);
            if (dateA.getTime() !== dateB.getTime()) {
                return dateB.getTime() - dateA.getTime();
            }

            // For trades with same date, apply different sorting logic
            // Main trades vs subtrades: main trades first
            if (!a.parentTradeId && b.parentTradeId) return -1;
            if (a.parentTradeId && !b.parentTradeId) return 1;

            // If both are main trades (no parentTradeId), sort by creation time (newer first)
            if (!a.parentTradeId && !b.parentTradeId) {
                return b.id - a.id;
            }

            // If both are subtrades, keep original order
            if (a.parentTradeId && b.parentTradeId) {
                return a.id - b.id;
            }

            return 0;
        });

        if (limit) trades = trades.slice(0, limit);

        if (trades.length === 0) {
            tbody.innerHTML = `
                <tr class="empty-state">
                    <td colspan="${tableBodyId === 'recent-trades-body' ? '7' : '13'}">
                        <div class="empty-message">
                            <i data-lucide="inbox"></i>
                            <p>No trades found. Start by adding your first trade!</p>
                        </div>
                    </td>
                </tr>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Group trades by month for full table, use normal view for recent trades
        if (tableBodyId === 'all-trades-body') {
            this.renderGroupedTradesTable(tbody, trades);
        } else {
            this.renderSimpleTradesTable(tbody, trades, limit);
        }
    }

    renderSimpleTradesTable(tbody, trades, limit) {
        tbody.innerHTML = trades.map((trade, index) => {
            const pnl = trade.profit || trade.pnl || 0;

            // Використовуємо збережений profitPercent або розраховуємо
            const account = this.accounts.find(acc => acc.id === trade.accountId);
            let pnlPercent = trade.profitPercent || '0%';
            
            // Якщо profitPercent не збережений, розраховуємо від балансу
            if (!trade.profitPercent && account && account.balance > 0) {
                const calculatedPercent = (pnl / account.balance) * 100;
                pnlPercent = calculatedPercent.toFixed(2) + '%';
            }
            
            // Видаляємо знак % для розрахунків кольору
            const pnlPercentValue = parseFloat(pnlPercent.replace('%', ''));

            const pnlClass = pnl >= 0 ? 'pnl-positive' : 'pnl-negative';
            const accountName = account ? account.name : '-';

            // Форматування дат
            const startDate = this.formatDateShort(trade.entryDate || trade.date);
            const endDate = this.formatDateShort(trade.exitDate || trade.date);
            const dateRange = `${startDate} → ${endDate}`;
            
            // RR та Risk
            const rr = trade.rr || trade.riskReward || 0;
            const risk = trade.risk || 0;

            // Strategy, Setup, Notes
            let strategy = '-';
            if (trade.strategyId) {
                // Порівнюємо з конверсією до строки для сумісності
                const strategyObj = this.strategies.find(s => String(s.id) === String(trade.strategyId));
                strategy = strategyObj ? strategyObj.name : '-';
            }
            
            let setup = '-';
            if (trade.entryModelId) {
                // Порівнюємо з конверсією до строки для сумісності
                const setupObj = this.setups.find(s => String(s.id) === String(trade.entryModelId));
                setup = setupObj ? setupObj.name : '-';
            }
            
            const notes = trade.notes ? (trade.notes.length > 30 ? trade.notes.substring(0, 30) + '...' : trade.notes) : '-';

            if (tableBodyId === 'recent-trades-body') {
                return `
                    <tr onclick="window.app.editTrade(${trade.id})" style="cursor: pointer;">
                        <td>${this.formatDate(trade.date || trade.entryDate)}</td>
                        <td>${trade.symbol || '-'}</td>
                        <td class="${pnlClass}">$${pnl.toFixed(2)}</td>
                        <td class="${pnlClass}">${pnlPercent}</td>
                        <td>${rr.toFixed(2)}</td>
                        <td onclick="event.stopPropagation();">
                            <button class="btn-secondary" onclick="window.app.viewTradeDetails(${trade.id})" style="padding: 6px 12px; font-size: 12px;">
                                <i data-lucide="eye"></i>
                            </button>
                            <button class="btn-danger" onclick="window.app.deleteTrade(${trade.id})" style="padding: 6px 12px; font-size: 12px; margin-left: 4px;">
                                <i data-lucide="trash-2"></i>
                            </button>
                        </td>
                    </tr>
                `;
            } else {
                // Отримуємо іконку валютної пари
                const symbol = trade.symbol || 'EURUSD';
                const baseCurrency = symbol.substring(0, 3).toLowerCase();
                const quoteCurrency = symbol.substring(3, 6).toLowerCase();
                
                // Конвертуємо direction: buy -> Long, sell -> Short
                const directionMap = {
                    'buy': 'Long',
                    'sell': 'Short',
                    'long': 'Long',
                    'short': 'Short',
                    'Long': 'Long',
                    'Short': 'Short'
                };
                const displayDirection = directionMap[trade.direction] || trade.direction || 'Long';

                return `
                    <tr onclick="window.app.editTrade(${trade.id})" style="cursor: pointer;">
                        <td style="display: ${this.columnVisibility.tradeNumber ? 'table-cell' : 'none'}"><span class="trade-number">#${trade.tradeNumber || (trades.length - index)}</span></td>
                        <td style="display: ${this.columnVisibility.date ? 'table-cell' : 'none'}">
                            <div class="trade-date-range">
                                <div class="trade-date-entry">${startDate}</div>
                                <div class="trade-date-exit">→ ${endDate}</div>
                            </div>
                        </td>
                        <td style="display: ${this.columnVisibility.pair ? 'table-cell' : 'none'}">
                            <div class="currency-pair">
                                ${this.renderCurrencyPairWithFlags(symbol)}
                            </div>
                        </td>
                        <td style="display: ${this.columnVisibility.session ? 'table-cell' : 'none'}"><span class="session-badge">${trade.session || '-'}</span></td>
                        <td style="display: ${this.columnVisibility.direction ? 'table-cell' : 'none'}">
                            <span class="direction-badge direction-${displayDirection.toLowerCase()}">${displayDirection}</span>
                        </td>
                        <td style="display: ${this.columnVisibility.result ? 'table-cell' : 'none'}">
                            <span class="result-badge ${(trade.result || 'Win').toLowerCase()}">
                                <div class="result-dot"></div>
                                ${trade.result || 'Win'}
                            </span>
                        </td>
                        <td style="display: ${this.columnVisibility.profitDollar ? 'table-cell' : 'none'}">
                            <div class="profit-cell">
                                <div class="${pnlClass}"><strong>${pnl >= 0 ? '+' : ''}$${pnl.toFixed(0)}</strong></div>
                            </div>
                        </td>
                        <td class="${pnlClass}" style="display: ${this.columnVisibility.profitPercent ? 'table-cell' : 'none'}"><strong>${pnlPercent}</strong></td>
                        <td style="display: ${this.columnVisibility.rr ? 'table-cell' : 'none'}"><span class="rrr-value">${rr.toFixed(1)}</span></td>
                        <td style="display: ${this.columnVisibility.risk ? 'table-cell' : 'none'}"><span class="risk-value">${risk > 0 ? risk.toFixed(1) + '%' : '-'}</span></td>
                        <td style="display: ${this.columnVisibility.strategy ? 'table-cell' : 'none'}"><span class="strategy-badge">${strategy}</span></td>
                        <td style="display: ${this.columnVisibility.setup ? 'table-cell' : 'none'}"><span class="setup-badge">${setup}</span></td>
                        <td style="display: ${this.columnVisibility.notes ? 'table-cell' : 'none'}"><span class="notes-preview" title="${trade.notes || ''}">${notes}</span></td>
                        <td style="display: ${this.columnVisibility.account ? 'table-cell' : 'none'}">
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <span class="account-badge" title="${accountName}">${accountName}</span>
                                <div class="action-menu-container" onclick="event.stopPropagation();">
                                    <button class="action-menu-btn" data-trade-id="${trade.id}" onclick="window.app.showActionMenu(this, 'trade')">
                                        <i data-lucide="more-horizontal"></i>
                                    </button>
                                    <div class="action-menu" style="display: none;">
                                        <div class="action-menu-item action-edit">
                                            <i data-lucide="edit-2"></i>
                                            <span>Edit</span>
                                        </div>
                                        <div class="action-menu-item action-delete">
                                            <i data-lucide="trash-2"></i>
                                            <span>Delete</span>
                                        </div>
                                        <div class="action-menu-item action-add-subtrade">
                                            <i data-lucide="plus"></i>
                                            <span>Add Subtrade</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                `;
            }
        }).join('');

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    // Генерує заголовок групи залежно від фільтру періоду
    getGroupHeaderTitle(monthKey, monthDate) {
        const period = this.globalTimePeriod;
        
        if (period === '1d') {
            return 'This Day';
        } else if (period === '1w') {
            return 'This Week';
        } else if (period === 'custom' && this.customDateRange.start && this.customDateRange.end) {
            const startDate = new Date(this.customDateRange.start);
            const endDate = new Date(this.customDateRange.end);
            const options = { month: 'short', day: 'numeric' };
            const startStr = startDate.toLocaleDateString('en-US', options);
            const endStr = endDate.toLocaleDateString('en-US', options);
            const year = endDate.getFullYear();
            return `${startStr} - ${endStr}, ${year}`;
        } else {
            // Для 'all' та '1m' показуємо місяць
            return monthDate.toLocaleDateString('en-US', { 
                month: 'long', 
                year: 'numeric' 
            });
        }
    }

    renderGroupedTradesTable(tbody, trades) {
        // Use filtered trades if no trades parameter provided
        const tradesToRender = trades || this.getFilteredTrades();

        // Group trades by month
        const tradesByMonth = this.groupTradesByMonth(tradesToRender);

        // Clear the current table body
        tbody.innerHTML = '';

        // Get the table container
        const tableContainer = tbody.closest('.table-container');

        // Clear any existing month sections
        const existingMonthSections = tableContainer.parentNode.querySelectorAll('.month-section');
        existingMonthSections.forEach(section => section.remove());

        Object.entries(tradesByMonth).forEach(([monthKey, monthTrades]) => {
            const monthDate = new Date(monthKey + '-01');
            const monthName = this.getGroupHeaderTitle(monthKey, monthDate);

            // Skip month if no trades to show
            if (monthTrades.length === 0) {
                return;
            }

            // Calculate month statistics
            const monthPnL = monthTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const monthPnLClass = monthPnL >= 0 ? 'positive' : 'negative';

            const monthWins = monthTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
            }).length;

            const monthLosses = monthTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
            }).length;

            const monthTradesForWinRate = monthWins + monthLosses;
            const monthWinRate = monthTradesForWinRate > 0 ? (monthWins / monthTradesForWinRate) * 100 : 0;

            // Calculate percentage from filtered accounts capital (відфільтровані акаунти)
            const filteredAccounts = this.getFilteredAccounts();
            const totalCapital = filteredAccounts.length > 0 ? 
                filteredAccounts.reduce((sum, acc) => sum + (acc.startingBalance || 0), 0) : 10000;
            const monthProfitPercent = totalCapital > 0 ? (monthPnL / totalCapital) * 100 : 0;

            const monthTotalTrades = monthTrades.length;
            const monthTotalRR = monthTrades.reduce((sum, trade) => sum + (trade.rr || trade.riskReward || 0), 0);

            // Create month section container
            const monthSection = document.createElement('div');
            monthSection.className = 'month-section';
            monthSection.setAttribute('data-month', monthKey);

            // Month header
            const monthHeader = document.createElement('div');
            monthHeader.className = 'month-section-header';
            monthHeader.innerHTML = `
                <button class="month-toggle-btn" onclick="window.app.toggleMonth('${monthKey}')">
                    <i data-lucide="chevron-down" class="month-chevron"></i>
                </button>
                <div class="month-info">
                    <span class="month-title">${monthName}</span>
                    <div class="month-stats">
                        <span class="month-trades">
                            ${monthTotalTrades} trades
                        </span>
                        <span class="month-pnl ${monthPnLClass}">
                            ${monthPnL >= 0 ? '+' : ''}$${monthPnL.toFixed(2)}
                        </span>
                        <span class="month-percent ${monthPnLClass}">
                            ${monthProfitPercent >= 0 ? '+' : ''}${monthProfitPercent.toFixed(1)}%
                        </span>
                        <span class="month-rr">
                            ${monthTotalRR.toFixed(1)} RR
                        </span>
                        <span class="month-winrate">
                            ${monthWinRate.toFixed(1)}% WR
                        </span>
                    </div>
                </div>
            `;

            // Create table
            const monthTable = document.createElement('div');
            monthTable.className = 'month-table-container';
            
            // Build thead dynamically based on column visibility
            const visibleHeaders = [];
            const headerMap = {
                tradeNumber: 'Trade #',
                date: 'Date',
                pair: 'Pair',
                session: 'Session',
                direction: 'Direction',
                result: 'Result',
                profitDollar: 'Profit $',
                profitPercent: 'Profit %',
                rr: 'RR',
                risk: 'Risk (%)',
                strategy: 'Strategy',
                setup: 'Setup',
                notes: 'Notes',
                account: 'Account'
            };
            
            Object.entries(headerMap).forEach(([key, label]) => {
                if (this.columnVisibility[key]) {
                    visibleHeaders.push(`<th>${label}</th>`);
                }
            });
            
            monthTable.innerHTML = `
                <table class="data-table month-trades-table">
                    <thead>
                        <tr>
                            ${visibleHeaders.join('')}
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            `;

            const monthTbody = monthTable.querySelector('tbody');

            // Sort trades by date and type (main trades first, then subtrades)
            monthTrades.sort((a, b) => {
                const dateA = new Date(a.entryDate || a.date);
                const dateB = new Date(b.entryDate || b.date);
                if (dateA.getTime() !== dateB.getTime()) {
                    return dateB.getTime() - dateA.getTime();
                }

                // For trades with same date, apply different sorting logic
                // Main trades vs subtrades: main trades first
                if (!a.parentTradeId && b.parentTradeId) return -1;
                if (a.parentTradeId && !b.parentTradeId) return 1;

                // If both are main trades (no parentTradeId), sort by creation time (newer first)
                if (!a.parentTradeId && !b.parentTradeId && a.id !== b.id) {
                    return b.id - a.id; // Higher ID means later creation time
                }

                // If both are subtrades, keep original order (don't sort by ID)
                if (a.parentTradeId && b.parentTradeId) {
                    // Sort subtrades by their original creation order (ascending ID)
                    return a.id - b.id;
                }

                return 0;
            });

            // Render each trade
            monthTrades.forEach(trade => {
                const pnl = trade.profit || trade.pnl || 0;
                const account = this.accounts.find(acc => acc.id === trade.accountId);
                
                // Використовуємо збережений profitPercent або розраховуємо
                let pnlPercent = trade.profitPercent || '0%';
                if (!trade.profitPercent && account && account.balance > 0) {
                    const calculatedPercent = (pnl / account.balance) * 100;
                    pnlPercent = calculatedPercent.toFixed(2) + '%';
                }
                
                // Видаляємо знак % для чисельних розрахунків
                const pnlPercentValue = parseFloat(pnlPercent.toString().replace('%', ''));

                const pnlClass = pnl >= 0 ? 'pnl-positive' : 'pnl-negative';
                const accountName = account ? account.name : '-';
                const startDate = this.formatDateShort(trade.entryDate || trade.date);
                const endDate = this.formatDateShort(trade.exitDate || trade.date);
                const symbol = trade.symbol || 'EURUSD';
                
                // Strategy, Setup, Notes
                let strategy = '-';
                if (trade.strategyId) {
                    // Порівнюємо з конверсією до строки для сумісності
                    const strategyObj = this.strategies.find(s => String(s.id) === String(trade.strategyId));
                    strategy = strategyObj ? strategyObj.name : '-';
                }
                
                let setup = '-';
                if (trade.entryModelId) {
                    // Порівнюємо з конверсією до строки для сумісності
                    const setupObj = this.setups.find(s => String(s.id) === String(trade.entryModelId));
                    setup = setupObj ? setupObj.name : '-';
                }
                
                const notes = trade.notes ? (trade.notes.length > 30 ? trade.notes.substring(0, 30) + '...' : trade.notes) : '-';

                const tradeRow = document.createElement('tr');
                tradeRow.onclick = () => window.app.editTrade(trade.id);
                tradeRow.style.cursor = 'pointer';

                let tradeNumberDisplay;
                let hasSubtrades = false;
                let isSubtrade = false;

                if (!trade.parentTradeId) {
                    // Main trade - check if it has subtrades
                    const subtrades = monthTrades.filter(t => t.parentTradeId === trade.id);
                    hasSubtrades = subtrades.length > 0;
                    tradeNumberDisplay = `#${trade.tradeNumber || 'N/A'}`;
                    tradeRow.setAttribute('data-trade-id', trade.id);
                    if (hasSubtrades) {
                        tradeRow.classList.add('has-subtrades');
                    }
                } else {
                    // Subtrade
                    isSubtrade = true;
                    tradeRow.classList.add('subtrade-row');
                    tradeRow.setAttribute('data-parent-id', trade.parentTradeId);
                    tradeNumberDisplay = `Sub${trade.tradeNumber || 'N/A'}`;
                }

                // Build row cells based on column visibility
                const cells = [];
                
                if (this.columnVisibility.tradeNumber) {
                    cells.push(`
                        <td>
                            <div class="trade-number-container">
                                ${!trade.parentTradeId && hasSubtrades ? `
                                    <button class="subtrade-toggle" onclick="event.stopPropagation(); window.app.toggleSubtrades(${trade.id})" data-trade-id="${trade.id}">
                                        <i data-lucide="chevron-down" class="subtrade-arrow"></i>
                                    </button>
                                ` : ''}
                                <span class="trade-number">${tradeNumberDisplay}</span>
                            </div>
                        </td>
                    `);
                }
                
                if (this.columnVisibility.date) {
                    cells.push(`
                        <td>
                            <div class="trade-date-range">
                                <div class="trade-date-entry">${startDate}</div>
                                <div class="trade-date-exit">→ ${endDate}</div>
                            </div>
                        </td>
                    `);
                }
                
                if (this.columnVisibility.pair) {
                    cells.push(`
                        <td>
                            <div class="currency-pair">
                                ${this.renderCurrencyPairWithFlags(symbol)}
                            </div>
                        </td>
                    `);
                }
                
                if (this.columnVisibility.session) {
                    cells.push(`
                        <td><span class="session-badge">${trade.session || '-'}</span></td>
                    `);
                }
                
                if (this.columnVisibility.direction) {
                    // Конвертуємо direction: buy -> Long, sell -> Short
                    const directionMap = {
                        'buy': 'Long',
                        'sell': 'Short',
                        'long': 'Long',
                        'short': 'Short',
                        'Long': 'Long',
                        'Short': 'Short'
                    };
                    const displayDirection = directionMap[trade.direction] || trade.direction || 'Long';
                    cells.push(`
                        <td>
                            <span class="direction-badge direction-${displayDirection.toLowerCase()}">${displayDirection}</span>
                        </td>
                    `);
                }
                
                if (this.columnVisibility.result) {
                    cells.push(`
                        <td>
                            <span class="result-badge ${(trade.result || 'Win').toLowerCase()}">
                                <div class="result-dot"></div>
                                ${trade.result || 'Win'}
                            </span>
                        </td>
                    `);
                }
                
                if (this.columnVisibility.profitDollar) {
                    cells.push(`
                        <td>
                            <div class="profit-cell">
                                <div class="${pnlClass}"><strong>${pnl >= 0 ? '+' : ''}$${pnl.toFixed(0)}</strong></div>
                            </div>
                        </td>
                    `);
                }
                
                if (this.columnVisibility.profitPercent) {
                    cells.push(`<td class="${pnlClass}"><strong>${pnlPercent}</strong></td>`);
                }
                
                if (this.columnVisibility.rr) {
                    cells.push(`<td><span class="rrr-value">${(trade.rr || trade.riskReward || 0).toFixed(1)}</span></td>`);
                }
                
                if (this.columnVisibility.risk) {
                    cells.push(`<td><span class="risk-value">${trade.risk ? trade.risk.toFixed(1) + '%' : '-'}</span></td>`);
                }
                
                if (this.columnVisibility.strategy) {
                    cells.push(`<td><span class="strategy-badge">${strategy}</span></td>`);
                }
                
                if (this.columnVisibility.setup) {
                    cells.push(`<td><span class="setup-badge">${setup}</span></td>`);
                }
                
                if (this.columnVisibility.notes) {
                    cells.push(`<td><span class="notes-preview" title="${trade.notes || ''}">${notes}</span></td>`);
                }
                
                if (this.columnVisibility.account) {
                    cells.push(`
                    <td>
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <span class="account-badge" title="${accountName}">${accountName}</span>
                            <div class="action-menu-container" onclick="event.stopPropagation();">
                                <button class="action-menu-btn" ${isSubtrade ? `data-trade-id="${trade.parentTradeId}" data-subtrade-id="${trade.id}"` : `data-trade-id="${trade.id}"`} onclick="window.app.showActionMenu(this, '${isSubtrade ? 'subtrade' : 'trade'}')">
                                    <i data-lucide="more-horizontal"></i>
                                </button>
                                <div class="action-menu" style="display: none;">
                                    <div class="action-menu-item action-edit">
                                        <i data-lucide="edit-2"></i>
                                        <span>Edit</span>
                                    </div>
                                    <div class="action-menu-item action-delete">
                                        <i data-lucide="trash-2"></i>
                                        <span>Delete</span>
                                    </div>
                                    ${!trade.parentTradeId ? `
                                        <div class="action-menu-item action-add-subtrade">
                                            <i data-lucide="plus"></i>
                                            <span>Add Subtrade</span>
                                        </div>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                    </td>
                    `);
                }
                
                tradeRow.innerHTML = cells.join('');
                monthTbody.appendChild(tradeRow);
            });

            // Assemble month section
            monthSection.appendChild(monthHeader);
            monthSection.appendChild(monthTable);

            // Insert month section before the original table container
            tableContainer.parentNode.insertBefore(monthSection, tableContainer);
        });

        // Hide the original table
        tableContainer.style.display = 'none';

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    groupTradesByMonth(trades) {
        const grouped = {};

        trades.forEach(trade => {
            try {
                const date = new Date(trade.date || trade.entryDate);
                const monthKey = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;

                if (!grouped[monthKey]) {
                    grouped[monthKey] = [];
                }
                grouped[monthKey].push(trade);
            } catch (e) {
                console.error('Invalid date in trade:', trade);
            }
        });

        // Sort months in descending order
        const sortedGrouped = {};
        Object.keys(grouped).sort((a, b) => b.localeCompare(a)).forEach(key => {
            sortedGrouped[key] = grouped[key];
        });

        return sortedGrouped;
    }

    toggleMonth(monthKey) {
        const monthSection = document.querySelector(`.month-section[data-month="${monthKey}"]`);
        const chevron = monthSection?.querySelector('.month-chevron');
        const monthTable = monthSection?.querySelector('.month-table-container');

        if (!monthSection || !chevron || !monthTable) return;

        const isCollapsed = monthTable.style.display === 'none';

        // Toggle table visibility
        monthTable.style.display = isCollapsed ? 'block' : 'none';

        // Rotate chevron
        if (isCollapsed) {
            chevron.style.transform = 'rotate(0deg)';
        } else {
            chevron.style.transform = 'rotate(-90deg)';
        }
    }

    toggleSubtrades(tradeId) {
        // Find all subtrade rows for this trade
        const subtradeRows = document.querySelectorAll(`tr[data-parent-id="${tradeId}"]`);
        const toggleButton = document.querySelector(`.subtrade-toggle[data-trade-id="${tradeId}"]`);
        const arrow = toggleButton?.querySelector('.subtrade-arrow');

        if (!subtradeRows.length || !toggleButton || !arrow) return;

        // Check current state - if any subtrade is visible, we'll hide all, otherwise show all
        const firstSubtrade = subtradeRows[0];
        const isCurrentlyVisible = firstSubtrade.style.display !== 'none';

        subtradeRows.forEach(row => {
            if (isCurrentlyVisible) {
                row.style.display = 'none';
            } else {
                row.style.display = 'table-row';
            }
        });

        // Rotate arrow
        if (isCurrentlyVisible) {
            arrow.style.transform = 'rotate(-90deg)';
            toggleButton.classList.remove('expanded');
        } else {
            arrow.style.transform = 'rotate(0deg)';
            toggleButton.classList.add('expanded');
        }
    }

    viewTradeDetails(tradeId) {
        const trade = this.trades.find(t => t.id === tradeId);
        if (!trade) return;

        const content = `
            <div style="display: grid; gap: 24px;">
                <div style="background: var(--bg-tertiary, #f8f9fa); padding: 20px; border-radius: 8px;">
                    <h3 style="margin-bottom: 16px;">Trade Information</h3>
                    <div style="display: grid; gap: 12px;">
                        <div style="display: flex; justify-content: space-between;">
                            <span>Symbol:</span>
                            <span style="font-weight: 600;">${trade.symbol || '-'}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Entry Date:</span>
                            <span style="font-weight: 600;">${this.formatDate(trade.entryDate || trade.date)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Exit Date:</span>
                            <span style="font-weight: 600;">${this.formatDate(trade.exitDate || trade.date)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Direction:</span>
                            <span style="font-weight: 600;">${trade.type || 'Long'}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>P&L (USD):</span>
                            <span class="${(trade.pnl || 0) >= 0 ? 'positive' : 'negative'}" style="font-weight: 600;">$${(trade.pnl || 0).toFixed(2)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>P&L (%):</span>
                            <span class="${(trade.pnlPercent || 0) >= 0 ? 'positive' : 'negative'}" style="font-weight: 600;">${(trade.pnlPercent || 0).toFixed(2)}%</span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span>Risk/Reward:</span>
                            <span style="font-weight: 600;">${(trade.riskReward || 0).toFixed(2)}</span>
                        </div>
                    </div>
                </div>
                ${trade.screenshot ? `
                <div style="background: var(--bg-tertiary, #f8f9fa); padding: 20px; border-radius: 8px;">
                    <h3 style="margin-bottom: 16px;">Screenshot</h3>
                    <img src="${trade.screenshot}" style="max-width: 100%; border-radius: 8px; border: 1px solid #ddd;">
                </div>
                ` : ''}
            </div>
        `;

        const detailContent = document.getElementById('trade-detail-content');
        const detailModal = document.getElementById('trade-detail-modal');

        if (detailContent && detailModal) {
            detailContent.innerHTML = content;
            detailModal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    formatDate(dateString) {
        if (!dateString) return '-';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString();
        } catch {
            return dateString;
        }
    }

    formatDateShort(dateString) {
        if (!dateString) return '-';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-GB', { 
                day: '2-digit', 
                month: '2-digit', 
                year: '2-digit' 
            });
        } catch {
            return dateString;
        }
    }

    // ФІЛЬТРИ
    populateFilters() {
        const symbols = [...new Set(this.trades.map(trade => trade.symbol).filter(Boolean))].sort();
        const symbolFilter = document.getElementById('symbol-filter');
        if (symbolFilter) {
            symbolFilter.innerHTML = '<option value="">All Symbols</option>';
            symbols.forEach(symbol => {
                symbolFilter.innerHTML += `<option value="${symbol}">${symbol}</option>`;
            });
        }

        // ЗАПОВНЕННЯ ФІЛЬТРУ МІСЯЦІВ
        const months = [...new Set(this.trades.map(trade => {
            try {
                if (!trade.date && !trade.entryDate) return null;
                return (trade.date || trade.entryDate).substring(0, 7);
            } catch {
                return null;
            }
        }).filter(Boolean))].sort();

        const monthFilter = document.getElementById('month-filter');

        if (monthFilter) {
            monthFilter.innerHTML = '<option value="">All Months</option>';
            months.forEach(month => {
                try {
                    const date = new Date(month + '-01');
                    if (!isNaN(date.getTime())) {
                        const monthName = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
                        monthFilter.innerHTML += `<option value="${month}">${monthName}</option>`;
                    } else {
                        monthFilter.innerHTML += `<option value="${month}">${month}</option>`;
                    }
                } catch {
                    monthFilter.innerHTML += `<option value="${month}">${month}</option>`;
                }
            });
        }
    }

    // ЗАСТОСУВАННЯ ФІЛЬТРІВ
    applyFilters() {
        const symbolFilter = document.getElementById('symbol-filter');
        const statusFilter = document.getElementById('status-filter');
        const monthFilter = document.getElementById('month-filter');

        if (!symbolFilter || !statusFilter || !monthFilter) return;

        const symbolValue = symbolFilter.value;
        const statusValue = statusFilter.value;
        const monthValue = monthFilter.value;

        const filteredTrades = this.trades.filter(trade => {
            if (symbolValue && trade.symbol !== symbolValue) return false;
            if (statusValue === 'win' && (trade.pnl || 0) <= 0) return false;
            if (statusValue === 'loss' && (trade.pnl || 0) > 0) return false;
            if (monthValue && !(trade.date || trade.entryDate).startsWith(monthValue)) return false;
            return true;
        });

        this.updateFilteredTradesTable(filteredTrades);
    }

    // ОНОВЛЕННЯ ТАБЛИЦІ ВІДФІЛЬТРОВАНИХ ТРЕЙДІВ
    updateFilteredTradesTable(trades) {
        const tbody = document.getElementById('all-trades-body');
        if (!tbody) return;

        const sortedTrades = trades.sort((a, b) => {
            try {
                const dateA = new Date(a.date || a.entryDate);
                const dateB = new Date(b.date || b.entryDate);
                return dateB.getTime() - dateA.getTime();
            } catch {
                return 0;
            }
        });

        if (sortedTrades.length === 0) {
            tbody.innerHTML = `
                <tr class="empty-state">
                    <td colspan="10">
                        <div class="empty-message">
                            <i data-lucide="search"></i>
                            <p>No trades match the selected filters.</p>
                        </div>
                    </td>
                </tr>
            `;
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
            return;
        }

        // Use grouped rendering for filtered trades too
        this.renderGroupedTradesTable(tbody, sortedTrades);
    }

    toggleFiltersPanel() {
        const dropdown = document.getElementById('filtersDropdown');
        const columnDropdown = document.getElementById('column-visibility-dropdown');
        
        if (dropdown) {
            const isVisible = dropdown.style.display === 'block';
            
            // Close column dropdown if open
            if (columnDropdown) {
                columnDropdown.style.display = 'none';
            }
            
            dropdown.style.display = isVisible ? 'none' : 'block';
        }
    }

    toggleAccountFilter() {
        const dropdown = document.getElementById('account-filter-dropdown');
        const toggle = document.querySelector('.account-filter-toggle');

        if (dropdown && toggle) {
            dropdown.classList.toggle('show');
            toggle.classList.toggle('active');

            // Populate accounts filter when opening
            if (dropdown.classList.contains('show')) {
                this.populateAccountsFilter();
            }
        }
    }

    populateAccountsFilter() {
        const filterList = document.getElementById('account-filter-list');
        if (!filterList) return;

        if (this.accounts.length === 0) {
            filterList.innerHTML = '<div style="text-align: center; color: var(--text-secondary); padding: 16px;">No accounts found</div>';
            return;
        }

        // Get current selected account IDs
        const currentlySelected = this.getSelectedAccountIds();

        filterList.innerHTML = this.accounts.map(account => {
            // Calculate actual current balance including trades and payouts (same logic as renderAccountCard)
            const allAccountTrades = this.trades.filter(trade => trade.accountId === account.id);
            const totalTradesPnl = allAccountTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const accountPayouts = this.payouts ? this.payouts.filter(payout => payout.accountId === account.id) : [];
            const payoutAmount = accountPayouts.reduce((sum, payout) => sum + (payout.amount || 0), 0);
            const actualCurrentBalance = account.startingBalance + totalTradesPnl - payoutAmount;

            // Check if this account should be active based on current selection
            const isActive = currentlySelected.includes(account.id);
            return `
                <div class="account-filter-item" data-account-id="${account.id}">
                    <div class="account-toggle ${isActive ? 'active' : ''}" onclick="window.app.toggleAccountSelection(${account.id})"></div>
                    <div class="account-filter-info">
                        <div class="account-filter-name">${account.name}</div>
                        <div class="account-filter-balance">$${actualCurrentBalance.toFixed(2)}</div>
                    </div>
                    <div class="account-filter-type ${account.type.toLowerCase().replace(' ', '')}">${account.type}</div>
                </div>
            `;
        }).join('');

        // Update summary after populating
        this.updateAccountFilterSummary();
    }

    toggleAccountSelection(accountId) {
        const item = document.querySelector(`[data-account-id="${accountId}"]`);
        const toggle = item?.querySelector('.account-toggle');

        if (toggle) {
            toggle.classList.toggle('active');
        }

        this.updateAccountFilterSummary();
    }

    updateAccountFilterSummary() {
        const activeToggles = document.querySelectorAll('.account-filter-item .account-toggle.active');
        const summary = document.getElementById('account-filter-summary');

        // Update stored state
        const selectedIds = [];
        activeToggles.forEach(toggle => {
            const accountItem = toggle.closest('.account-filter-item');
            const accountId = parseInt(accountItem.getAttribute('data-account-id'));
            if (!isNaN(accountId)) {
                selectedIds.push(accountId);
            }
        });

        this.selectedAccountIds = selectedIds.length > 0 ? selectedIds : this.accounts.map(acc => acc.id);

        if (summary) {
            if (activeToggles.length === 0) {
                summary.textContent = 'No Accounts';
            } else if (activeToggles.length === this.accounts.length) {
                summary.textContent = 'All Accounts';
            } else {
                summary.textContent = `${activeToggles.length} Accounts`;
            }
        }

        // Apply filter and update statistics
        this.applyAccountFilter();
    }

    getSelectedAccountIds() {
        // If we have stored selected accounts, use them
        if (this.selectedAccountIds !== null) {
            return this.selectedAccountIds;
        }

        // Otherwise, check the DOM
        const activeToggles = document.querySelectorAll('.account-filter-item .account-toggle.active');
        const selectedIds = [];

        activeToggles.forEach(toggle => {
            const accountItem = toggle.closest('.account-filter-item');
            const accountId = parseInt(accountItem.getAttribute('data-account-id'));
            if (!isNaN(accountId)) {
                selectedIds.push(accountId);
            }
        });

        // If no accounts selected and no stored state, return all account IDs
        if (selectedIds.length === 0 && this.selectedAccountIds === null) {
            this.selectedAccountIds = this.accounts.map(acc => acc.id);
            return this.selectedAccountIds;
        }

        // Store the current selection
        this.selectedAccountIds = selectedIds.length > 0 ? selectedIds : this.accounts.map(acc => acc.id);
        return this.selectedAccountIds;
    }

    getFilteredTrades() {
        const selectedAccountIds = this.getSelectedAccountIds();

        // Збираємо всі трейди (основні + субтрейди) які відповідають фільтру акаунтів
        const allFilteredTrades = [];

        this.trades.forEach(trade => {
            // Включаємо основні трейди якщо вони відповідають фільтру
            if (!trade.parentTradeId && (!trade.accountId || selectedAccountIds.includes(trade.accountId))) {
                allFilteredTrades.push(trade);
            }

            // Включаємо субтрейди якщо ВОНИ відповідають фільтру (незалежно від основного трейду)
            if (trade.parentTradeId && (!trade.accountId || selectedAccountIds.includes(trade.accountId))) {
                allFilteredTrades.push(trade);
            }
        });

        // Фільтрація за часовим періодом
        return this.filterTradesByTimePeriod(allFilteredTrades);
    }

    filterTradesByTimePeriod(trades) {
        if (this.globalTimePeriod === 'all') {
            return trades;
        }

        const now = new Date();
        let startDate;
        let endDate;

        if (this.globalTimePeriod === '1d') {
            // Поточний день (від початку до кінця дня)
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
            endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
        } else if (this.globalTimePeriod === '1w') {
            // Поточний тиждень з понеділка до неділі
            const dayOfWeek = now.getDay();
            const diff = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // якщо неділя (0), то -6 днів, інакше до понеділка
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - diff, 0, 0, 0, 0);
            // Кінець тижня - неділя
            endDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + (6 - diff), 23, 59, 59, 999);
        } else if (this.globalTimePeriod === '1m') {
            // Поточний місяць (від першого до останнього дня)
            startDate = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
            // Останній день місяця
            endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
        } else if (this.globalTimePeriod === 'custom') {
            // Кастомний діапазон
            if (!this.customDateRange.from || !this.customDateRange.to) {
                return trades; // Якщо діапазон не встановлений, показуємо всі трейди
            }
            startDate = new Date(this.customDateRange.from);
            startDate.setHours(0, 0, 0, 0);
            endDate = new Date(this.customDateRange.to);
            endDate.setHours(23, 59, 59, 999);
        } else {
            // Невідомий період - повертаємо всі трейди
            return trades;
        }

        // Фільтруємо трейди за діапазоном дат
        return trades.filter(trade => {
            const tradeDate = new Date(trade.date || trade.entryDate);
            return tradeDate >= startDate && tradeDate <= endDate;
        });
    }

    getFilteredAccounts() {
        const selectedAccountIds = this.getSelectedAccountIds();
        return this.accounts.filter(acc => selectedAccountIds.includes(acc.id));
    }

    applyAccountFilter() {
        console.log('Applying account filter...');
        // Update all metrics and displays based on filtered data
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateAccountsDisplay();

        // Force reinitialize equity chart and update all charts
        setTimeout(() => {
            console.log('Updating charts after account filter...');
            this.initEquityCurveChart(); // Reinitialize equity chart
            this.updateCharts();
        }, 100);
    }

    // ═══════════════════════════════════════════════════════════
    // 🕐 РОЗДІЛ: ГЛОБАЛЬНИЙ ФІЛЬТР ЧАСОВОГО ПЕРІОДУ
    // ═══════════════════════════════════════════════════════════
    
    setGlobalTimePeriod(period) {
        console.log('Setting global time period:', period);
        this.globalTimePeriod = period;

        // Оновити активну кнопку
        document.querySelectorAll('.global-time-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.getAttribute('data-period') === period) {
                btn.classList.add('active');
            }
        });

        // Динамічне відображення метрик залежно від періоду
        this.updatePeriodMetricsVisibility(period);

        // Якщо це не custom, сховати календар та оновити метрики
        if (period !== 'custom') {
            this.hideCustomDatePicker();
            this.applyTimePeriodFilter();
        }
    }

    updatePeriodMetricsVisibility(period) {
        const periodMetrics = document.querySelectorAll('.period-metric');
        
        periodMetrics.forEach(metric => {
            const minPeriod = metric.getAttribute('data-period-min');
            let shouldShow = false;

            // Визначаємо які метрики показувати для кожного періоду
            if (period === '1d') {
                // 1D: тільки This Day
                shouldShow = minPeriod === '1d';
            } else if (period === '1w') {
                // 1W: This Day і This Week
                shouldShow = minPeriod === '1d' || minPeriod === '1w';
            } else if (period === '1m') {
                // 1M: This Day, This Week і This Month
                shouldShow = minPeriod === '1d' || minPeriod === '1w' || minPeriod === '1m';
            } else {
                // All або Custom: показати всі
                shouldShow = true;
            }

            metric.style.display = shouldShow ? 'flex' : 'none';
        });
    }

    showCustomDatePicker() {
        const picker = document.getElementById('custom-date-picker');
        if (picker) {
            picker.style.display = 'block';
            
            // Встановити поточну дату як значення за замовчуванням
            const today = new Date().toISOString().split('T')[0];
            const fromInput = document.getElementById('custom-date-from');
            const toInput = document.getElementById('custom-date-to');
            
            if (fromInput && !fromInput.value) {
                // За замовчуванням: останній місяць
                const lastMonth = new Date();
                lastMonth.setMonth(lastMonth.getMonth() - 1);
                fromInput.value = lastMonth.toISOString().split('T')[0];
            }
            
            if (toInput && !toInput.value) {
                toInput.value = today;
            }
        }
    }

    hideCustomDatePicker() {
        const picker = document.getElementById('custom-date-picker');
        if (picker) {
            picker.style.display = 'none';
        }
    }

    applyCustomDateRange() {
        const fromInput = document.getElementById('custom-date-from');
        const toInput = document.getElementById('custom-date-to');

        if (!fromInput || !toInput || !fromInput.value || !toInput.value) {
            this.showNotification('Please select both start and end dates', 'error');
            return;
        }

        const fromDate = new Date(fromInput.value);
        const toDate = new Date(toInput.value);

        if (fromDate > toDate) {
            this.showNotification('Start date must be before end date', 'error');
            return;
        }

        this.customDateRange.from = fromInput.value;
        this.customDateRange.to = toInput.value;

        this.hideCustomDatePicker();
        this.applyTimePeriodFilter();
    }

    applyTimePeriodFilter() {
        console.log('Applying time period filter:', this.globalTimePeriod);
        // Оновити всі метрики та відображення на основі відфільтрованих даних
        this.updateAllMetrics();
        this.updateAllTables();
        this.updateAccountsDisplay();

        // Оновити графіки
        setTimeout(() => {
            console.log('Updating charts after time period filter...');
            this.initEquityCurveChart();
            this.updateCharts();
        }, 100);
    }

    selectAllAccounts() {
        document.querySelectorAll('.account-filter-item .account-toggle').forEach(toggle => {
            toggle.classList.add('active');
        });
        this.selectedAccountIds = this.accounts.map(acc => acc.id);
        this.updateAccountFilterSummary();
    }

    deselectAllAccounts() {
        document.querySelectorAll('.account-filter-item .account-toggle').forEach(toggle => {
            toggle.classList.remove('active');
        });
        this.selectedAccountIds = [];
        this.updateAccountFilterSummary();
    }

    // ========================================
    // DASHBOARD WIDGETS DATA FUNCTIONS
    // ========================================

    // Get instruments results from real trades data
    getInstrumentsResults(direction = 'overall') {
        const filteredTrades = this.getFilteredTrades();
        const instrumentsData = {};

        filteredTrades.forEach(trade => {
            // Filter by direction if specified
            if (direction !== 'overall' && trade.direction && trade.direction.toLowerCase() !== direction.toLowerCase()) {
                return;
            }

            const symbol = trade.symbol || 'Unknown';
            if (!instrumentsData[symbol]) {
                instrumentsData[symbol] = {
                    symbol: symbol,
                    totalTrades: 0,
                    wins: 0,
                    losses: 0,
                    totalPnl: 0,
                    winRate: 0,
                    avgPnl: 0
                };
            }

            const data = instrumentsData[symbol];
            data.totalTrades++;
            data.totalPnl += (trade.pnl || 0);

            const result = trade.result;
            if (result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner')) {
                data.wins++;
            } else if (result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser')) {
                data.losses++;
            }

            // Calculate win rate (exclude BE trades)
            const tradesForWinRate = data.wins + data.losses;
            data.winRate = tradesForWinRate > 0 ? (data.wins / tradesForWinRate) * 100 : 0;
            data.avgPnl = data.totalTrades > 0 ? data.totalPnl / data.totalTrades : 0;
        });

        // Convert to array and sort by total P&L
        return Object.values(instrumentsData).sort((a, b) => b.totalPnl - a.totalPnl);
    }

    // Get return analysis data
    getReturnAnalysisData() {
        const filteredTrades = this.getFilteredTrades();
        const filteredAccounts = this.getFilteredAccounts();

        const totalStartingBalance = filteredAccounts.reduce((sum, acc) => sum + (acc.startingBalance || 0), 0) || 10000;
        const totalReturn = filteredTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        const totalReturnPercent = totalStartingBalance > 0 ? (totalReturn / totalStartingBalance) * 100 : 0;

        const avgReturnPerTrade = filteredTrades.length > 0 ? totalReturn / filteredTrades.length : 0;

        // Calculate daily return (simplified - total return divided by days since first trade)
        let dailyReturn = 0;
        if (filteredTrades.length > 0) {
            const sortedTrades = [...filteredTrades].sort((a, b) => {
                const dateA = new Date(a.date || a.entryDate);
                const dateB = new Date(b.date || b.entryDate);
                return dateA.getTime() - dateB.getTime();
            });

            const firstTradeDate = new Date(sortedTrades[0].date || sortedTrades[0].entryDate);
            const today = new Date();
            const daysDiff = Math.max(1, Math.ceil((today - firstTradeDate) / (1000 * 60 * 60 * 24)));
            dailyReturn = totalReturn / daysDiff;
        }

        // Calculate return on winners and losers
        const winningTrades = filteredTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        });
        const losingTrades = filteredTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        });

        const returnOnWinners = winningTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        const returnOnLosers = losingTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

        // Calculate best and worst single trade
        let bestTrade = 0;
        let worstTrade = 0;
        if (filteredTrades.length > 0) {
            const pnlValues = filteredTrades.map(trade => trade.pnl || 0);
            bestTrade = Math.max(...pnlValues);
            worstTrade = Math.min(...pnlValues);
        }

        // Calculate profit factor (positive P&L / absolute value of negative P&L)
        const positiveReturn = winningTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        const negativeReturn = Math.abs(losingTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0));
        const profitFactor = negativeReturn > 0 ? positiveReturn / negativeReturn : (positiveReturn > 0 ? positiveReturn : 0);

        return {
            totalReturn,
            totalReturnPercent,
            avgReturnPerTrade,
            dailyReturn,
            returnOnWinners,
            returnOnLosers,
            bestTrade,
            worstTrade,
            profitFactor
        };
    }

    // Get calendar data for a specific month
    getCalendarData(year, month) {
        const filteredTrades = this.getFilteredTrades();
        const calendarData = {};

        filteredTrades.forEach(trade => {
            const tradeDate = new Date(trade.date || trade.entryDate);
            if (tradeDate.getFullYear() === year && tradeDate.getMonth() === month) {
                const dateKey = tradeDate.getDate();

                if (!calendarData[dateKey]) {
                    calendarData[dateKey] = {
                        totalTrades: 0,
                        wins: 0,
                        losses: 0,
                        totalReturn: 0,
                        longTrades: 0,
                        shortTrades: 0
                    };
                }

                const dayData = calendarData[dateKey];
                dayData.totalTrades++;
                dayData.totalReturn += (trade.pnl || 0);

                const result = trade.result;
                if (result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner')) {
                    dayData.wins++;
                } else if (result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser')) {
                    dayData.losses++;
                }

                if (trade.direction && trade.direction.toLowerCase() === 'long') {
                    dayData.longTrades++;
                } else if (trade.direction && trade.direction.toLowerCase() === 'short') {
                    dayData.shortTrades++;
                }

                // Calculate win rate
                const tradesForWinRate = dayData.wins + dayData.losses;
                dayData.winRate = tradesForWinRate > 0 ? (dayData.wins / tradesForWinRate) * 100 : 0;

                // Calculate return on winners and losers
                const dayWinners = filteredTrades.filter(t => {
                    const tDate = new Date(t.date || t.entryDate);
                    const tResult = t.result;
                    return tDate.getFullYear() === year && 
                           tDate.getMonth() === month && 
                           tDate.getDate() === dateKey &&
                           tResult && (tResult.toLowerCase() === 'win' || tResult.toLowerCase() === 'winner');
                });
                const dayLosers = filteredTrades.filter(t => {
                    const tDate = new Date(t.date || t.entryDate);
                    const tResult = t.result;
                    return tDate.getFullYear() === year && 
                           tDate.getMonth() === month && 
                           tDate.getDate() === dateKey &&
                           tResult && (tResult.toLowerCase() === 'loss' || tResult.toLowerCase() === 'lose' || tResult.toLowerCase() === 'loser');
                });

                dayData.returnOnWinners = dayWinners.reduce((sum, t) => sum + (t.pnl || 0), 0);
                dayData.returnOnLosers = dayLosers.reduce((sum, t) => sum + (t.pnl || 0), 0);
            }
        });

        return calendarData;
    }

    // Update dashboard widgets with real data
    updateDashboardWidgets() {
        this.updateInstrumentsWidget();
        this.updateReturnAnalysisWidget();
        this.updateCapitalOverviewWidget();
        this.updateInteractiveCalendarWidget();
        this.updateStrategyOverviewWidget();
        this.updateSetupOverviewWidget();
        this.updateSessionsWidget();
        this.updateWeekdaysPnlWidget();

        // Setup equity controls after widgets are updated
        setTimeout(() => {
            this.setupEquityControls();
        }, 100);
    }

    // Update strategy list widget
    updateStrategyOverviewWidget() {
        const container = document.getElementById('strategy-list-container');
        if (!container) return;

        if (this.strategies.length === 0) {
            container.innerHTML = `
                <div class="strategy-list-empty">
                    <div>
                        <i data-lucide="target"></i>
                        <div>No strategies created yet</div>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Get filtered trades for strategy analysis
        const filteredTrades = this.getFilteredTrades();

        let html = '';

        // Analyze each strategy and build HTML
        this.strategies.forEach(strategy => {
            const strategyTrades = filteredTrades.filter(trade => trade.strategy === strategy.name);

            // Calculate metrics
            const totalTrades = strategyTrades.length;
            const winTrades = strategyTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
            }).length;

            const lossTrades = strategyTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
            }).length;

            const tradesForWinRate = winTrades + lossTrades;
            const winRate = tradesForWinRate > 0 ? (winTrades / tradesForWinRate) * 100 : 0;
            const totalPnl = strategyTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const avgRR = totalTrades > 0 ? 
                strategyTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / totalTrades : 0;

            html += `
                <div class="strategy-list-item">
                    <div class="item-header">
                        <div class="item-symbol">${strategy.name}</div>
                        <div class="item-trades">${totalTrades} trade${totalTrades !== 1 ? 's' : ''}</div>
                    </div>
                    <div class="item-metrics-grid">
                        <div class="item-stat">
                            <div class="stat-label">P&L</div>
                            <div class="stat-value ${totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toFixed(0)}
                            </div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Win Rate</div>
                            <div class="stat-value">${winRate.toFixed(0)}%</div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Avg RR</div>
                            <div class="stat-value">${avgRR.toFixed(1)}</div>
                        </div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    // Update setup list widget
    updateSetupOverviewWidget() {
        const container = document.getElementById('setup-list-container');
        if (!container) return;

        // Get setups from the Setups tab (same as Strategies & Setups page)
        if (this.setups.length === 0) {
            container.innerHTML = `
                <div class="strategy-list-empty">
                    <div>
                        <i data-lucide="layout-grid"></i>
                        <div>No setups created yet</div>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Get filtered trades for setup analysis
        const filteredTrades = this.getFilteredTrades();

        let html = '';

        // Analyze each setup and build HTML
        this.setups.forEach(setup => {
            // Filter trades by this setup (using entryModel field)
            const setupTrades = filteredTrades.filter(trade => trade.entryModel === setup.name);

            // Calculate metrics
            const totalTrades = setupTrades.length;
            const winTrades = setupTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
            }).length;

            const lossTrades = setupTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
            }).length;

            const tradesForWinRate = winTrades + lossTrades;
            const winRate = tradesForWinRate > 0 ? (winTrades / tradesForWinRate) * 100 : 0;
            const totalPnl = setupTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const avgRR = totalTrades > 0 ? 
                setupTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / totalTrades : 0;

            html += `
                <div class="strategy-list-item">
                    <div class="item-header">
                        <div class="item-symbol">${setup.name}</div>
                        <div class="item-trades">${totalTrades} trade${totalTrades !== 1 ? 's' : ''}</div>
                    </div>
                    <div class="item-metrics-grid">
                        <div class="item-stat">
                            <div class="stat-label">P&L</div>
                            <div class="stat-value ${totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toFixed(0)}
                            </div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Win Rate</div>
                            <div class="stat-value">${winRate.toFixed(0)}%</div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Avg RR</div>
                            <div class="stat-value">${avgRR.toFixed(1)}</div>
                        </div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    // Update trading sessions widget
    updateSessionsWidget() {
        const container = document.getElementById('sessions-list-container');
        if (!container) return;

        // Define available sessions
        const sessions = ['Asia', 'Frankfurt', 'London', 'New-York'];

        // Get filtered trades for session analysis
        const filteredTrades = this.getFilteredTrades();

        if (filteredTrades.length === 0) {
            container.innerHTML = `
                <div class="strategy-list-empty">
                    <div>
                        <i data-lucide="clock"></i>
                        <div>No trading data available</div>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        let html = '';

        // Analyze each session and build HTML
        sessions.forEach(session => {
            // Filter trades by this session
            const sessionTrades = filteredTrades.filter(trade => trade.session === session);

            // Calculate metrics
            const totalTrades = sessionTrades.length;
            const winTrades = sessionTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
            }).length;

            const lossTrades = sessionTrades.filter(trade => {
                const result = trade.result;
                return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
            }).length;

            const tradesForWinRate = winTrades + lossTrades;
            const winRate = tradesForWinRate > 0 ? (winTrades / tradesForWinRate) * 100 : 0;
            const totalPnl = sessionTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
            const avgRR = totalTrades > 0 ? 
                sessionTrades.reduce((sum, trade) => sum + (trade.riskReward || 0), 0) / totalTrades : 0;

            html += `
                <div class="strategy-list-item">
                    <div class="item-header">
                        <div class="item-symbol">${session}</div>
                        <div class="item-trades">${totalTrades} trade${totalTrades !== 1 ? 's' : ''}</div>
                    </div>
                    <div class="item-metrics-grid">
                        <div class="item-stat">
                            <div class="stat-label">P&L</div>
                            <div class="stat-value ${totalPnl >= 0 ? 'positive' : 'negative'}">
                                ${totalPnl >= 0 ? '+' : ''}$${Math.abs(totalPnl).toFixed(0)}
                            </div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Win Rate</div>
                            <div class="stat-value">${winRate.toFixed(0)}%</div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Avg RR</div>
                            <div class="stat-value">${avgRR.toFixed(1)}</div>
                        </div>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    // Update weekdays P&L widget
    updateWeekdaysPnlWidget() {
        const container = document.getElementById('weekdays-pnl-container');
        if (!container) return;

        const filteredTrades = this.getFilteredTrades();
        
        if (filteredTrades.length === 0) {
            container.innerHTML = `
                <div class="strategy-list-empty">
                    <div>
                        <i data-lucide="calendar"></i>
                        <div>No trading data available</div>
                    </div>
                </div>
            `;
            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Initialize weekdays data
        const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
        const weekdaysData = {};
        
        weekdays.forEach(day => {
            weekdaysData[day] = { pnl: 0, trades: 0, wins: 0, losses: 0 };
        });

        // Calculate P&L for each weekday
        filteredTrades.forEach(trade => {
            const date = new Date(trade.entryDate || trade.date);
            const dayIndex = date.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
            
            // Map to weekdays (skip weekends)
            if (dayIndex >= 1 && dayIndex <= 5) {
                const dayName = weekdays[dayIndex - 1];
                weekdaysData[dayName].pnl += (trade.pnl || 0);
                weekdaysData[dayName].trades++;
                
                const result = trade.result;
                if (result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner')) {
                    weekdaysData[dayName].wins++;
                } else if (result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser')) {
                    weekdaysData[dayName].losses++;
                }
            }
        });

        // Find max absolute value for scaling
        const maxPnl = Math.max(...weekdays.map(day => Math.abs(weekdaysData[day].pnl)));
        const scale = maxPnl > 0 ? 100 / maxPnl : 1;

        // Generate chart HTML
        let html = '<div class="weekdays-chart">';
        
        weekdays.forEach(day => {
            const data = weekdaysData[day];
            const pnl = data.pnl;
            const height = Math.abs(pnl) * scale;
            const isPositive = pnl >= 0;
            const winRate = (data.wins + data.losses) > 0 ? (data.wins / (data.wins + data.losses)) * 100 : 0;
            
            html += `
                <div class="weekday-bar-container" title="${day}: ${pnl >= 0 ? '+' : ''}$${pnl.toFixed(0)} (${data.trades} trades, ${winRate.toFixed(0)}% WR)">
                    <div class="weekday-value ${isPositive ? 'positive' : 'negative'}">
                        ${pnl >= 0 ? '+' : ''}$${Math.abs(pnl).toFixed(0)}
                    </div>
                    <div class="weekday-bar ${isPositive ? 'positive' : 'negative'}" style="height: ${height}%">
                    </div>
                    <div class="weekday-label">${day}</div>
                    <div class="weekday-trades">${data.trades}</div>
                </div>
            `;
        });
        
        html += '</div>';
        container.innerHTML = html;
    }

    // Update instruments widget
    updateInstrumentsWidget(direction = 'overall') {
        const instrumentsData = this.getInstrumentsResults(direction);
        const container = document.getElementById('instruments-results-list');

        if (!container) return;

        if (instrumentsData.length === 0) {
            container.innerHTML = `
                <div class="empty-message" style="text-align: center; color: var(--text-tertiary); padding: 20px;">
                    <p>No trading data available</p>
                </div>
            `;
            return;
        }

        container.innerHTML = instrumentsData.slice(0, 8).map(instrument => {
            const pnlClass = instrument.totalPnl >= 0 ? 'positive' : 'negative';
            const winRateClass = instrument.winRate >= 50 ? 'positive' : 'negative';

            return `
                <div class="instrument-item">
                    <div class="item-header">
                        <div class="item-symbol">${instrument.symbol}</div>
                        <div class="item-trades">${instrument.totalTrades} trade${instrument.totalTrades !== 1 ? 's' : ''}</div>
                    </div>
                    <div class="item-metrics-grid">
                        <div class="item-stat">
                            <div class="stat-label">P&L</div>
                            <div class="stat-value ${pnlClass}">
                                ${instrument.totalPnl >= 0 ? '+' : ''}$${instrument.totalPnl.toFixed(0)}
                            </div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Win Rate</div>
                            <div class="stat-value ${winRateClass}">${instrument.winRate.toFixed(1)}%</div>
                        </div>
                        <div class="item-stat">
                            <div class="stat-label">Avg P&L</div>
                            <div class="stat-value">${instrument.avgPnl >= 0 ? '+' : ''}$${instrument.avgPnl.toFixed(0)}</div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Update return analysis widget
    updateReturnAnalysisWidget() {
        const returnData = this.getReturnAnalysisData();

        // Format amounts with proper minus sign for negative values
        const formatAmount = (amount) => {
            if (amount >= 0) {
                return `+$${amount.toFixed(2)}`;
            } else {
                return `-$${Math.abs(amount).toFixed(2)}`;
            }
        };

        this.updateElement('return-total-amount', formatAmount(returnData.totalReturn));
        this.updateElement('return-total-percentage', `${returnData.totalReturnPercent >= 0 ? '+' : ''}${returnData.totalReturnPercent.toFixed(1)}%`);
        this.updateElement('return-avg-trade', formatAmount(returnData.avgReturnPerTrade));
        this.updateElement('return-winners', `$${returnData.returnOnWinners.toFixed(2)}`);
        this.updateElement('return-losers', returnData.returnOnLosers < 0 ? `-$${Math.abs(returnData.returnOnLosers).toFixed(2)}` : `$${returnData.returnOnLosers.toFixed(2)}`);

        // Update best and worst trade
        this.updateElement('return-best-trade', formatAmount(returnData.bestTrade));
        this.updateElement('return-worst-trade', formatAmount(returnData.worstTrade));

        // Update profit factor
        this.updateElement('return-profit-factor', returnData.profitFactor.toFixed(2));

        // Update color classes for Total P&L only
        const totalAmountEl = document.getElementById('return-total-amount');
        const totalPercentageEl = document.getElementById('return-total-percentage');

        if (totalAmountEl) {
            totalAmountEl.className = `return-overview-amount ${returnData.totalReturn >= 0 ? 'positive' : 'negative'}`;
        }
        if (totalPercentageEl) {
            totalPercentageEl.className = `return-percentage-badge ${returnData.totalReturnPercent >= 0 ? 'positive' : 'negative'}`;
        }
    }

    // Update capital overview widget
    updateCapitalOverviewWidget() {
        const filteredAccounts = this.getFilteredAccounts();
        const filteredTrades = this.getFilteredTrades();

        if (filteredAccounts.length === 0) {
            this.updateElement('capital-overview-total', '$0.00');
            this.updateElement('capital-overview-accounts-count', '0');
            this.updateElement('capital-overview-best-account', '-');
            // Очистити динамічну розбивку по типах
            const breakdownContainer = document.querySelector('.capital-overview-breakdown');
            if (breakdownContainer) {
                breakdownContainer.innerHTML = `
                    <div class="capital-overview-item">
                        <div class="capital-overview-item-label">Active Accounts</div>
                        <div class="capital-overview-item-value">0</div>
                    </div>
                    <div class="capital-overview-item">
                        <div class="capital-overview-item-label">Best Performer</div>
                        <div class="capital-overview-item-value">-</div>
                    </div>
                `;
            }
            return;
        }

        // Calculate real capital including trades P&L for each account
        let totalCapital = 0;
        let totalPnl = 0;
        let totalStartingBalance = 0;
        const capitalByType = {}; // Динамічна розбивка по типах
        let bestPerformer = null;
        let bestPnl = -Infinity;

        const today = new Date().toISOString().split('T')[0];
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
        const oneMonthAgo = new Date();
        oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);

        let todayPnl = 0;
        let weeklyPnl = 0;
        let monthlyPnl = 0;

        filteredAccounts.forEach(account => {
            // Get all trades for this account
            const accountTrades = filteredTrades.filter(trade => trade.accountId === account.id);
            const tradesPnl = accountTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

            // Фоллбек для старих даних: використовуємо balance якщо startingBalance відсутнє
            const startingBalance = account.startingBalance || account.balance || 0;
            
            // Calculate real current balance
            const realCurrentBalance = startingBalance + tradesPnl;
            const accountPnl = realCurrentBalance - startingBalance;

            totalCapital += realCurrentBalance;
            totalPnl += accountPnl;
            totalStartingBalance += startingBalance;

            // Групуємо по типах акаунтів (динамічно)
            const accountType = account.type || 'Other';
            if (!capitalByType[accountType]) {
                capitalByType[accountType] = 0;
            }
            capitalByType[accountType] += realCurrentBalance;

            // Find best performer
            if (accountPnl > bestPnl) {
                bestPnl = accountPnl;
                bestPerformer = account;
            }

            // Calculate period-specific P&L for this account
            const todayTrades = accountTrades.filter(trade => 
                (trade.date === today) || (trade.entryDate === today)
            );
            todayPnl += todayTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

            const weeklyTrades = accountTrades.filter(trade => {
                const tradeDate = new Date(trade.date || trade.entryDate);
                return tradeDate >= oneWeekAgo;
            });
            weeklyPnl += weeklyTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

            const monthlyTrades = accountTrades.filter(trade => {
                const tradeDate = new Date(trade.date || trade.entryDate);
                return tradeDate >= oneMonthAgo;
            });
            monthlyPnl += monthlyTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
        });

        // Calculate total ROI
        const totalROI = totalStartingBalance > 0 ? (totalPnl / totalStartingBalance) * 100 : 0;

        // Update total capital
        this.updateElement('capital-overview-total', `$${totalCapital.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
        this.updateElement('capital-overview-accounts-count', filteredAccounts.length.toString());

        // Динамічно рендеримо розбивку по типах
        const breakdownContainer = document.querySelector('.capital-overview-breakdown');
        if (breakdownContainer) {
            let breakdownHTML = '';
            
            // Додаємо тільки ті типи акаунтів, які реально є
            Object.keys(capitalByType).sort().forEach(type => {
                const capital = capitalByType[type];
                const typeLower = type.toLowerCase();
                
                // Маппінг типів на відображувані назви
                const label = typeLower === 'live' ? 'Live Accounts' : 
                             typeLower === 'challenge' ? 'Challenge Accounts' :
                             typeLower === 'demo' ? 'Demo Accounts' :
                             typeLower === 'personal' ? 'Personal Capital' :
                             type.charAt(0).toUpperCase() + type.slice(1) + ' Accounts';
                
                breakdownHTML += `
                    <div class="capital-overview-item">
                        <div class="capital-overview-item-label">${label}</div>
                        <div class="capital-overview-item-value">$${capital.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    </div>
                `;
            });

            // Завжди додаємо Active Accounts та Best Performer
            breakdownHTML += `
                <div class="capital-overview-item">
                    <div class="capital-overview-item-label">Active Accounts</div>
                    <div class="capital-overview-item-value" id="capital-overview-accounts-count">${filteredAccounts.length}</div>
                </div>
                <div class="capital-overview-item">
                    <div class="capital-overview-item-label">Best Performer</div>
                    <div class="capital-overview-item-value" id="capital-overview-best-account">${bestPerformer ? bestPerformer.name : '-'}</div>
                </div>
            `;

            breakdownContainer.innerHTML = breakdownHTML;
        }

        // Update growth periods with styling
        const todayElement = document.getElementById('capital-overview-today');
        if (todayElement) {
            todayElement.textContent = `${todayPnl >= 0 ? '+' : ''}$${Math.abs(todayPnl).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            todayElement.className = 'capital-overview-item-value ' + (todayPnl >= 0 ? 'positive' : 'negative');
        }

        const weeklyElement = document.getElementById('capital-overview-weekly');
        if (weeklyElement) {
            weeklyElement.textContent = `${weeklyPnl >= 0 ? '+' : ''}$${Math.abs(weeklyPnl).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            weeklyElement.className = 'capital-overview-item-value ' + (weeklyPnl >= 0 ? 'positive' : 'negative');
        }

        const monthlyElement = document.getElementById('capital-overview-monthly');
        if (monthlyElement) {
            monthlyElement.textContent = `${monthlyPnl >= 0 ? '+' : ''}$${Math.abs(monthlyPnl).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            monthlyElement.className = 'capital-overview-item-value ' + (monthlyPnl >= 0 ? 'positive' : 'negative');
        }

        // Update ROI with styling
        const roiElement = document.getElementById('capital-overview-roi');
        if (roiElement) {
            roiElement.textContent = `${totalROI >= 0 ? '+' : ''}${totalROI.toFixed(1)}%`;
            roiElement.className = 'capital-overview-item-value ' + (totalROI >= 0 ? 'positive' : 'negative');
        }
    }

    // Update interactive calendar widget
    updateInteractiveCalendarWidget() {
        const currentDate = this.currentCalendarDate || new Date();
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        // Update month display
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                           'July', 'August', 'September', 'October', 'November', 'December'];
        this.updateElement('calendar-current-month', `${monthNames[month]} ${year}`);

        // Get calendar data
        const calendarData = this.getCalendarData(year, month);
        const daysContainer = document.getElementById('interactive-calendar-days');

        if (!daysContainer) return;

        // Generate calendar days
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDayOfWeek = firstDay.getDay(); // Sunday = 0

        let daysHTML = '';

        // Empty days at the beginning
        for (let i = 0; i < startingDayOfWeek; i++) {
            daysHTML += '<div class="calendar-day empty"></div>';
        }

        // Days of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayData = calendarData[day];
            const today = new Date();
            const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();

            let dayClass = 'calendar-day';
            if (isToday) dayClass += ' today';

            // Add trading status classes
            if (dayData && dayData.totalTrades > 0) {
                if (dayData.totalReturn > 0) {
                    dayClass += ' has-trades';
                } else if (dayData.totalReturn < 0) {
                    dayClass += ' has-losses';
                }
            }

            let pnlDisplay = '';
            if (dayData && dayData.totalReturn !== 0) {
                pnlDisplay = `<div class="calendar-day-pnl ${dayData.totalReturn >= 0 ? 'positive' : 'negative'}">${dayData.totalReturn >= 0 ? '+' : ''}$${Math.abs(dayData.totalReturn).toFixed(0)}</div>`;
            }

            daysHTML += `
                <div class="${dayClass}" onclick="window.app?.selectCalendarDay(${day}, ${month}, ${year})">
                    <span class="calendar-day-number">${day}</span>
                    ${pnlDisplay}
                </div>
            `;
        }

        daysContainer.innerHTML = daysHTML;

        // Setup navigation buttons if not already done
        this.setupCalendarNavigation();
    }

    // Select calendar day and show stats
    selectCalendarDay(day, month, year) {
        const calendarData = this.getCalendarData(year, month);
        const dayData = calendarData[day];

        // Remove previous selection
        document.querySelectorAll('.calendar-day.selected').forEach(day => {
            day.classList.remove('selected');
        });

        // Add selection to clicked day
        event.target.classList.add('selected');

        // Update selected date display
        const dateStr = new Date(year, month, day).toLocaleDateString('en-US', { 
            day: 'numeric',
            month: 'short'
        });
        this.updateElement('selected-date-display', dateStr);

        if (!dayData) {
            // No trades on this day
            this.updateElement('day-total-trades', '-');
            this.updateElement('day-winrate', '-');
            this.updateElement('day-return', '-');
            this.updateElement('day-return-winners', '-');
            this.updateElement('day-return-losers', '-');
            this.updateElement('day-win-trades', '0');
            this.updateElement('day-loss-trades', '0');

            // Clear winrate chart
            if (this.dayWinrateChart) {
                this.dayWinrateChart.destroy();
                this.dayWinrateChart = null;
            }

            // Update progress bars
            const dayLongBar = document.getElementById('day-long-bar');
            const dayShortBar = document.getElementById('day-short-bar');
            if (dayLongBar) dayLongBar.style.width = '0%';
            if (dayShortBar) dayShortBar.style.width = '0%';
            this.updateElement('day-long-percentage', '0');
            this.updateElement('day-short-percentage', '0');
            return;
        }

        // Update day stats
        this.updateElement('day-total-trades', dayData.totalTrades.toString());
        this.updateElement('day-winrate', `${dayData.winRate.toFixed(0)}%`);
        
        // Calculate return percentage (assuming initial capital or average)
        const returnPercentage = dayData.totalTrades > 0 ? (dayData.totalReturn / 1000) * 100 : 0; // Assuming $1000 per trade average
        this.updateElement('day-return', `${returnPercentage >= 0 ? '+' : ''}${returnPercentage.toFixed(1)}%`);
        
        const winnersPercentage = dayData.wins > 0 ? (dayData.returnOnWinners / (dayData.wins * 1000)) * 100 : 0;
        const losersPercentage = dayData.losses > 0 ? (dayData.returnOnLosers / (dayData.losses * 1000)) * 100 : 0;
        
        this.updateElement('day-return-winners', `+${winnersPercentage.toFixed(1)}%`);
        this.updateElement('day-return-losers', `${losersPercentage.toFixed(1)}%`);
        this.updateElement('day-win-trades', dayData.wins.toString());
        this.updateElement('day-loss-trades', dayData.losses.toString());

        // Update winrate donut chart
        this.updateDayWinrateChart(dayData.winRate);

        // Update progress bars for long/short
        const totalDirectionalTrades = dayData.longTrades + dayData.shortTrades;
        const longPercentage = totalDirectionalTrades > 0 ? (dayData.longTrades / totalDirectionalTrades) * 100 : 0;
        const shortPercentage = totalDirectionalTrades > 0 ? (dayData.shortTrades / totalDirectionalTrades) * 100 : 0;

        const dayLongBar = document.getElementById('day-long-bar');
        const dayShortBar = document.getElementById('day-short-bar');
        if (dayLongBar) dayLongBar.style.width = `${longPercentage}%`;
        if (dayShortBar) dayShortBar.style.width = `${shortPercentage}%`;
        this.updateElement('day-long-percentage', longPercentage.toFixed(0));
        this.updateElement('day-short-percentage', shortPercentage.toFixed(0));

        // Update color classes
        const returnEl = document.getElementById('day-return');
        if (returnEl) {
            returnEl.className = `day-stat-value ${dayData.totalReturn >= 0 ? 'positive' : 'negative'}`;
        }
    }

    // Update day winrate donut chart
    updateDayWinrateChart(winrate) {
        const canvas = document.getElementById('day-winrate-donut');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        // Destroy existing chart if it exists
        if (this.dayWinrateChart) {
            this.dayWinrateChart.destroy();
        }

        // Create new donut chart
        this.dayWinrateChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [winrate, 100 - winrate],
                    backgroundColor: [
                        'rgba(16, 185, 129, 1)',  // Green for wins
                        'rgba(60, 60, 60, 0.5)'   // Dark gray for losses
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: false,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                }
            }
        });
    }

    // Setup calendar navigation
    setupCalendarNavigation() {
        if (this.calendarNavigationSetup) return; // Prevent multiple setups

        const prevBtn = document.getElementById('calendar-prev-month');
        const nextBtn = document.getElementById('calendar-next-month');

        if (prevBtn && !prevBtn.hasAttribute('data-setup')) {
            prevBtn.setAttribute('data-setup', 'true');
            prevBtn.onclick = () => {
                if (!this.currentCalendarDate) this.currentCalendarDate = new Date();
                this.currentCalendarDate.setMonth(this.currentCalendarDate.getMonth() - 1);
                this.updateInteractiveCalendarWidget();
            };
        }

        if (nextBtn && !nextBtn.hasAttribute('data-setup')) {
            nextBtn.setAttribute('data-setup', 'true');
            nextBtn.onclick = () => {
                if (!this.currentCalendarDate) this.currentCalendarDate = new Date();
                this.currentCalendarDate.setMonth(this.currentCalendarDate.getMonth() + 1);
                this.updateInteractiveCalendarWidget();
            };
        }

        // Setup direction filter buttons
        document.querySelectorAll('.direction-filter-btn').forEach(btn => {
            if (!btn.hasAttribute('data-setup')) {
                btn.setAttribute('data-setup', 'true');
                btn.addEventListener('click', (e) => {
                    document.querySelectorAll('.direction-filter-btn').forEach(b => b.classList.remove('active'));
                    btn.classList.add('active');
                    const direction = btn.dataset.direction;
                    this.updateInstrumentsWidget(direction);
                });
            }
        });

        this.calendarNavigationSetup = true;
    }

    // КАЛЕНДАР
    renderCalendar() {
        const grid = document.getElementById('calendar-grid');
        if (!grid) return;

        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();

        const monthTitle = document.getElementById('calendar-month');
        if (monthTitle) {
            monthTitle.textContent = new Date(year, month).toLocaleDateString('en-US', {
                month: 'long',
                year: 'numeric'
            });
        }

        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDayOfWeek = firstDay.getDay();

        grid.innerHTML = '';

        // Заголовки днів
        const dayHeaders = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        dayHeaders.forEach(day => {
            const header = document.createElement('div');
            header.className = 'calendar-day-header';
            header.textContent = day;
            grid.appendChild(header);
        });

        // Порожні дні
        for (let i = 0; i < startingDayOfWeek; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day other-month';
            grid.appendChild(emptyDay);
        }

        // Дні місяця
        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';

            const dateStr = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            const dayTrades = this.trades.filter(trade =>
                (trade.date === dateStr) || (trade.entryDate === dateStr)
            );
            const dayPnl = dayTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

            const today = new Date();
            if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
                dayElement.classList.add('today');
            }

            // Add classes for days with trades
            if (dayTrades.length > 0) {
                if (dayPnl >= 0) {
                    dayElement.classList.add('has-trades');
                } else {
                    dayElement.classList.add('has-losses');
                }
            }

            // Build HTML with correct class names
            let pnlHtml = '';
            if (dayPnl !== 0) {
                pnlHtml = `<div class="calendar-day-pnl ${dayPnl >= 0 ? 'positive' : 'negative'}">$${dayPnl.toFixed(0)}</div>`;
            }

            dayElement.innerHTML = `
                <div class="calendar-day-number">${day}</div>
                ${pnlHtml}
            `;

            // Add click handler to select day
            dayElement.addEventListener('click', (e) => {
                // Remove previous selection
                document.querySelectorAll('.calendar-day.selected').forEach(d => {
                    d.classList.remove('selected');
                });
                // Add selection to clicked day
                dayElement.classList.add('selected');
                
                // Update stats panel
                this.selectCalendarDay(day, month, year);
            });

            grid.appendChild(dayElement);
        }
    }

    previousMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.renderCalendar();
    }

    nextMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.renderCalendar();
    }

    // Wait for Chart.js to load
    waitForChartJS() {
        return new Promise((resolve) => {
            if (typeof Chart !== 'undefined') {
                resolve();
                return;
            }

            const checkChart = () => {
                if (typeof Chart !== 'undefined') {
                    resolve();
                } else {
                    setTimeout(checkChart, 100);
                }
            };
            checkChart();
        });
    }

    // ГРАФІКИ
    initializeCharts() {
        console.log('Initializing charts with real trade data...');

        // Ensure we have loaded data before initializing charts
        this.loadData();
        this.loadAccounts();

        // Initialize equity curve first (using D3.js)
        this.initEquityCurveChart();

        // Initialize Chart.js charts if available
        if (typeof Chart !== 'undefined') {
            this.initWinRateChart();
            this.initMonthlyPerformance();
            this.initPnlDistribution();
            this.initSymbolPerformance();
            this.initMonthlyBreakdown();
            this.initDrawdownChart();
        } else {
            console.log('Chart.js not available, skipping Chart.js charts');
        }

        console.log('Charts initialized with', this.trades.length, 'trades');
    }

    // EQUITY CURVE CHART using D3.js
    initEquityCurveChart() {
        const container = document.getElementById('equity-curve-chart');
        if (!container) {
            // Don't log error or retry - just return silently
            return;
        }

        if (typeof d3 === 'undefined') {
            this.createSimpleEquityChart();
            return;
        }

        // Always setup controls when initializing
        this.setupEquityControls();
        this.renderEquityCurve();
    }

    setupEquityControls() {
        const equityButtons = document.querySelectorAll('.equity-btn');
        equityButtons.forEach(btn => {
            if (!btn.hasAttribute('data-setup')) {
                btn.setAttribute('data-setup', 'true');
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    console.log('Equity period button clicked:', btn.dataset.period);

                    // Remove active class from all buttons
                    equityButtons.forEach(b => b.classList.remove('active'));
                    // Add active class to clicked button
                    btn.classList.add('active');
                    // Re-render chart with selected period
                    this.renderEquityCurve(btn.dataset.period);
                });
            }
        });
    }

    buildEquityData(period = 'all') {
        // Get filtered trades (this already includes main trades + subtrades correctly)
        const filteredTrades = this.getFilteredTrades();
        const filteredAccounts = this.getFilteredAccounts();

        if (!filteredTrades.length || !filteredAccounts.length) {
            return [];
        }

        // Calculate starting balance from filtered accounts
        const startingBalance = filteredAccounts.reduce((sum, acc) => sum + (acc.startingBalance || 0), 0);

        // Convert filtered trades to the format needed for equity chart
        const allTrades = filteredTrades.map(trade => ({
            date: new Date(trade.date || trade.entryDate),
            pnl: trade.pnl || 0,
            symbol: trade.symbol || 'Unknown',
            type: trade.parentTradeId ? 'subtrade' : 'trade',
            id: trade.id,
            tradeNumber: trade.tradeNumber,
            parentId: trade.parentTradeId
        }));

        // Sort by date
        allTrades.sort((a, b) => a.date.getTime() - b.date.getTime());

        // Group data by period and calculate accumulated balance
        return this.groupEquityDataByPeriod(allTrades, startingBalance, period);
    }

    groupEquityDataByPeriod(trades, startingBalance, period) {
        if (period === 'all') {
            return this.calculateEquityPoints(trades, startingBalance);
        }

        const now = new Date();
        let equityData = [];

        if (period === '1') {
            // 1 день: показуємо трейди по номерах трейдів
            const startOfDay = new Date(now);
            startOfDay.setHours(0, 0, 0, 0);

            const endOfDay = new Date(now);
            endOfDay.setHours(23, 59, 59, 999);

            const todayTrades = trades.filter(trade => {
                const tradeDate = new Date(trade.date);
                return tradeDate >= startOfDay && tradeDate <= endOfDay;
            });

            const startDayBalance = startingBalance + trades.filter(trade => 
                new Date(trade.date) < startOfDay
            ).reduce((sum, trade) => sum + trade.pnl, 0);

            // Створюємо точки графіка починаючи з початкового балансу дня
            equityData = [];
            let runningBalance = startDayBalance;

            // Сортуємо трейди за номером трейду для правильного відображення на осі X
            const sortedTodayTrades = todayTrades.sort((a, b) => {
                const aNumber = a.tradeNumber || 0;
                const bNumber = b.tradeNumber || 0;
                return aNumber - bNumber;
            });

            if (sortedTodayTrades.length === 0) {
                // Якщо немає трейдів сьогодні, показуємо тільки початкову точку
                equityData = [
                    {
                        date: startOfDay,
                        balance: startDayBalance,
                        pnl: 0,
                        period: 'Start',
                        type: 'start'
                    }
                ];
            } else {
                // Додаємо початкову точку (баланс на початок дня)
                equityData.push({
                    date: startOfDay,
                    balance: startDayBalance,
                    pnl: 0,
                    period: 'Start',
                    type: 'start'
                });

                // Створюємо рівномірно розподілені дати для кожного трейду
                const timeSpan = 24 * 60 * 60 * 1000; // 24 години в мілісекундах

                sortedTodayTrades.forEach((trade, index) => {
                    runningBalance += trade.pnl;

                    // Розраховуємо рівномірно розподілену позицію на осі X
                    const positionRatio = (index + 1) / (sortedTodayTrades.length + 1); // +1 для відступу справа
                    const tradeTime = new Date(startOfDay.getTime() + (timeSpan * positionRatio));

                    equityData.push({
                        date: tradeTime,
                        balance: runningBalance,
                        pnl: trade.pnl,
                        period: `#${trade.tradeNumber || (index + 1)}`,
                        symbol: trade.symbol,
                        type: 'trade',
                        tradeNumber: trade.tradeNumber || (index + 1)
                    });
                });
            }

        } else if (period === '7') {
            // 1 тиждень: ділимо по днях (Mon, Tue, Wed, Thu, Fri, Sat, Sun)
            for (let i = 6; i >= 0; i--) {
                const date = new Date(now);
                date.setDate(date.getDate() - i);
                date.setHours(23, 59, 59, 999);

                const dayTrades = trades.filter(trade => {
                    const tradeDate = new Date(trade.date);
                    return tradeDate.toDateString() === date.toDateString();
                });

                const dayPnL = dayTrades.reduce((sum, trade) => sum + trade.pnl, 0);
                const dayBalance = startingBalance + trades.filter(trade => 
                    new Date(trade.date) <= date
                ).reduce((sum, trade) => sum + trade.pnl, 0);

                equityData.push({
                    date: date,
                    balance: dayBalance,
                    pnl: dayPnL,
                    period: date.toLocaleDateString('en-US', { weekday: 'short' })
                });
            }

        } else if (period === '30') {
            // 1 місяць: ділимо по тижнях
            for (let i = 3; i >= 0; i--) {
                const weekStart = new Date(now);
                weekStart.setDate(weekStart.getDate() - (i * 7) - (weekStart.getDay() || 7) + 1);
                weekStart.setHours(0, 0, 0, 0);

                const weekEnd = new Date(weekStart);
                weekEnd.setDate(weekEnd.getDate() + 6);
                weekEnd.setHours(23, 59, 59, 999);

                const weekTrades = trades.filter(trade => {
                    const tradeDate = new Date(trade.date);
                    return tradeDate >= weekStart && tradeDate <= weekEnd;
                });

                const weekPnL = weekTrades.reduce((sum, trade) => sum + trade.pnl, 0);
                const weekBalance = startingBalance + trades.filter(trade => 
                    new Date(trade.date) <= weekEnd
                ).reduce((sum, trade) => sum + trade.pnl, 0);

                equityData.push({
                    date: weekEnd,
                    balance: weekBalance,
                    pnl: weekPnL,
                    period: `W${4-i}`
                });
            }

        } else if (period === '90' || period === '180') {
            // 3 або 6 місяців: ділимо по місяцях
            const monthsBack = period === '90' ? 3 : 6;

            for (let i = monthsBack - 1; i >= 0; i--) {
                const monthStart = new Date(now.getFullYear(), now.getMonth() - i, 1);
                const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
                monthEnd.setHours(23, 59, 59, 999);

                const monthTrades = trades.filter(trade => {
                    const tradeDate = new Date(trade.date);
                    return tradeDate >= monthStart && tradeDate <= monthEnd;
                });

                const monthPnL = monthTrades.reduce((sum, trade) => sum + trade.pnl, 0);
                const monthBalance = startingBalance + trades.filter(trade => 
                    new Date(trade.date) <= monthEnd
                ).reduce((sum, trade) => sum + trade.pnl, 0);

                equityData.push({
                    date: monthEnd,
                    balance: monthBalance,
                    pnl: monthPnL,
                    period: monthEnd.toLocaleDateString('en-US', { month: 'short' })
                });
            }
        }

        return equityData;
    }

    calculateEquityPoints(trades, startingBalance) {
        const equityData = [];
        let runningBalance = startingBalance;

        if (trades.length === 0) {
            return [{ date: new Date(), balance: startingBalance, pnl: 0, period: 'Start' }];
        }

        // Group trades by month for 'all' period
        const monthlyData = {};
        trades.forEach(trade => {
            const date = new Date(trade.date);
            const monthKey = `${date.getFullYear()}-${date.getMonth()}`;

            if (!monthlyData[monthKey]) {
                monthlyData[monthKey] = {
                    trades: [],
                    date: new Date(date.getFullYear(), date.getMonth() + 1, 0), // Last day of month
                    pnl: 0
                };
            }

            monthlyData[monthKey].trades.push(trade);
            monthlyData[monthKey].pnl += trade.pnl;
        });

        // Create equity points for each month
        Object.keys(monthlyData).sort().forEach(monthKey => {
            const monthData = monthlyData[monthKey];
            runningBalance += monthData.pnl;

            equityData.push({
                date: monthData.date,
                balance: runningBalance,
                pnl: monthData.pnl,
                period: monthData.date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
                type: 'month'
            });
        });

        return equityData;
    }

    renderEquityCurve(period = 'all') {
        const container = document.getElementById('equity-curve-chart');
        if (!container) return;

        // Clear previous chart
        d3.select(container).selectAll('*').remove();

        const equityData = this.buildEquityData(period);

        if (equityData.length === 0) {
            // Show empty state
            d3.select(container)
                .append('div')
                .attr('class', 'empty-message')
                .style('display', 'flex')
                .style('flex-direction', 'column')
                .style('align-items', 'center')
                .style('justify-content', 'center')
                .style('height', '100%')
                .style('color', 'var(--text-tertiary)')
                .html('<i data-lucide="trending-up" style="font-size: 32px; opacity: 0.5; margin-bottom: 12px;"></i><p>No trading data available</p>');

            if (typeof lucide !== 'undefined') lucide.createIcons();
            return;
        }

        // Wait for container to be properly sized
        setTimeout(() => {
            const containerRect = container.getBoundingClientRect();

            // Use actual container dimensions with larger left margin for Y-axis labels with dollar signs
            const margin = { top: 8, right: 15, bottom: 95, left: 85 };
            const width = Math.max(250, containerRect.width - margin.left - margin.right);
            const height = Math.max(200, containerRect.height - margin.top - margin.bottom);

        const svg = d3.select(container)
                .append('svg')
                .attr('width', width + margin.left + margin.right)
                .attr('height', height + margin.top + margin.bottom)
                .attr('viewBox', `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
                .style('width', '100%')
                .style('height', '100%')
                .style('display', 'block')
                .style('border', 'none')
                .style('outline', 'none');

            const g = svg.append('g')
                .attr('transform', `translate(${margin.left},${margin.top})`);

        // Scales with proper padding
            const xScale = d3.scaleTime()
                .domain(d3.extent(equityData, d => d.date))
                .range([0, width]);

            const yExtent = d3.extent(equityData, d => d.balance);
            const yRange = yExtent[1] - yExtent[0];

            // Calculate proper Y domain with padding
            let yMin, yMax;
            if (yRange === 0) {
                // If all values are the same, show a small range around the value
                const value = yExtent[0];
                const padding = Math.max(value * 0.05, 100); // At least $100 padding
                yMin = value - padding;
                yMax = value + padding;
            } else {
                // Add 10% padding to top and bottom
                const yPadding = yRange * 0.1;
                yMin = yExtent[0] - yPadding;
                yMax = yExtent[1] + yPadding;
            }

            const yScale = d3.scaleLinear()
                .domain([yMin, yMax])
                .nice()
                .range([height, 0]);

        // Grid lines
            const xGrid = d3.axisBottom(xScale)
                .tickSize(-height)
                .tickFormat('')
                .ticks(5);

            const yGrid = d3.axisLeft(yScale)
                .tickSize(-width)
                .tickFormat('')
                .ticks(4);

            g.append('g')
                .attr('class', 'equity-chart-grid')
                .attr('transform', `translate(0,${height})`)
                .call(xGrid)
                .selectAll('line')
                .style('stroke', '#333333')
                .style('stroke-width', '0.3')
                .style('stroke-dasharray', '2,2')
                .style('opacity', 0.15);

            g.append('g')
                .attr('class', 'equity-chart-grid')
                .call(yGrid)
                .selectAll('line')
                .style('stroke', '#333333')
                .style('stroke-width', '0.3')
                .style('stroke-dasharray', '2,2')
                .style('opacity', 0.15);

        // Area generator
            const area = d3.area()
                .x(d => xScale(d.date))
                .y0(height)
                .y1(d => yScale(d.balance))
                .curve(d3.curveMonotoneX);

            // Line generator
            const line = d3.line()
                .x(d => xScale(d.date))
                .y(d => yScale(d.balance))
                .curve(d3.curveMonotoneX);

        // Add area with gradient
            const gradient = svg.append('defs')
                .append('linearGradient')
                .attr('id', 'equity-gradient')
                .attr('gradientUnits', 'userSpaceOnUse')
                .attr('x1', 0).attr('y1', margin.top)
                .attr('x2', 0).attr('y2', margin.top + height);

        gradient.append('stop')
            .attr('offset', '0%')
            .attr('stop-color', '#666666')
            .attr('stop-opacity', 0.3);

        gradient.append('stop')
            .attr('offset', '100%')
            .attr('stop-color', '#666666')
            .attr('stop-opacity', 0.05);

        // Add area
        g.append('path')
            .datum(equityData)
            .attr('class', 'equity-area')
            .attr('d', area)
            .attr('fill', 'url(#equity-gradient)');

        // Add line з плавними переходами
        g.append('path')
            .datum(equityData)
            .attr('class', 'equity-line')
            .attr('d', line)
            .attr('fill', 'none')
            .attr('stroke', '#888888')
            .attr('stroke-width', 1.5)
            .attr('stroke-linecap', 'round')
            .attr('stroke-linejoin', 'round');

        // Add dots тільки для реальних трейдів (не intermediate points)
        g.selectAll('.equity-dot')
            .data(equityData.filter(d => d.type !== 'start' && d.type !== 'intermediate'))
            .enter()
            .append('circle')
            .attr('class', 'equity-dot')
            .attr('cx', d => xScale(d.date))
            .attr('cy', d => yScale(d.balance))
            .attr('r', 3)
            .attr('fill', '#888888')
            .style('opacity', 0.9)
            .on('mouseover', (event, d) => this.showEquityTooltip(event, d))
            .on('mouseout', () => this.hideEquityTooltip());

        // X axis
            const xAxis = d3.axisBottom(xScale);
            if (period === '1' && equityData.length > 0) {
                // For 1D filter, show trade numbers
                xAxis.tickValues(equityData.filter(d => d.type === 'trade').map(d => d.date))
                     .tickFormat((d, i) => {
                         const dataPoint = equityData.find(point => point.date.getTime() === d.getTime() && point.type === 'trade');
                         return dataPoint && dataPoint.tradeNumber ? `#${dataPoint.tradeNumber}` : '';
                     });
            } else if (equityData.length > 0 && equityData[0].period) {
                // For other periods, use period labels
                xAxis.tickValues(equityData.map(d => d.date))
                     .tickFormat((d, i) => {
                         const dataPoint = equityData.find(point => point.date.getTime() === d.getTime());
                         return dataPoint ? dataPoint.period : '';
                     });
            } else {
                xAxis.tickFormat(d3.timeFormat('%m/%d'));
            }

            const xAxisGroup = g.append('g')
                .attr('class', 'equity-chart-axis')
                .attr('transform', `translate(0,${height})`)
                .call(xAxis);

            // Remove axis lines
            xAxisGroup.selectAll('path').remove();
            xAxisGroup.selectAll('line').remove();

            // Y axis
            const yAxisGroup = g.append('g')
                .attr('class', 'equity-chart-axis')
                .call(d3.axisLeft(yScale)
                    .tickFormat(d => `$${d.toFixed(0)}`));

            // Remove axis lines
            yAxisGroup.selectAll('path').remove();
            yAxisGroup.selectAll('line').remove();

            // Style axis text
            svg.selectAll('.equity-chart-axis text')
                .style('fill', 'var(--text-tertiary)')
                .style('font-size', '14px');

            // Ensure no borders on the main SVG element and all children
            svg.style('border', 'none')
               .style('outline', 'none')
               .style('box-shadow', 'none')
               .style('background', 'transparent')
               .attr('style', 'border: none !important; outline: none !important; box-shadow: none !important;');

            // Remove any borders from all child elements including axis paths
            svg.selectAll('*')
               .style('border', 'none')
               .style('outline', 'none')
               .style('box-shadow', 'none');

            // Specifically remove axis domain lines (the border lines around chart)
            svg.selectAll('.domain').remove();

            // Remove tick lines that create borders
            svg.selectAll('.tick line').remove();
        }, 50); // Small delay to ensure container is properly sized
    }

    showEquityTooltip(event, d) {
        const tooltip = d3.select('body')
            .append('div')
            .attr('class', 'equity-chart-tooltip')
            .style('opacity', 0);

        const pnlClass = d.pnl >= 0 ? 'positive' : 'negative';
        const pnlColor = d.pnl >= 0 ? 'var(--success)' : 'var(--danger)';

        const periodLabel = d.period || d.date.toLocaleDateString();

        tooltip.html(`
            <div style="margin-bottom: 4px;"><strong>${periodLabel}</strong></div>
            <div style="margin-bottom: 2px;">Balance: <strong>$${d.balance.toFixed(2)}</strong></div>
            <div style="margin-bottom: 2px;">P&L: <span style="color: ${pnlColor}; font-weight: 600;">${d.pnl >= 0 ? '+' : ''}$${d.pnl.toFixed(2)}</span></div>
            ${d.symbol && d.symbol !== 'Unknown' ? `<div>Symbol: ${d.symbol}</div>` : ''}
        `);

        // Get tooltip dimensions
        const tooltipNode = tooltip.node();
        const tooltipRect = tooltipNode.getBoundingClientRect();
        const tooltipWidth = tooltipRect.width;
        const tooltipHeight = tooltipRect.height;

        // Get viewport dimensions
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;

        // Calculate position
        let left = event.pageX + 10;
        let top = event.pageY - 10;

        // Check if tooltip goes off the right edge
        if (left + tooltipWidth > viewportWidth) {
            left = event.pageX - tooltipWidth - 10;
        }

        // Check if tooltip goes off the bottom edge
        if (top + tooltipHeight > viewportHeight) {
            top = event.pageY - tooltipHeight - 10;
        }

        // Check if tooltip goes off the top edge
        if (top < 0) {
            top = event.pageY + 10;
        }

        // Check if tooltip goes off the left edge
        if (left < 0) {
            left = 10;
        }

        tooltip
            .style('left', left + 'px')
            .style('top', top + 'px')
            .transition()
            .duration(200)
            .style('opacity', 1);
    }

    hideEquityTooltip() {
        d3.selectAll('.equity-chart-tooltip')
            .transition()
            .duration(200)
            .style('opacity', 0)
            .remove();
    }

    // Easing function for smooth transitions
    easeInOutCubic(t) {
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }

    createSimpleEquityChart() {
        const container = document.getElementById('equity-curve-chart');
        if (!container) return;

        // Clear previous content
        container.innerHTML = '';

        const equityData = this.buildEquityDataSimple();

        if (equityData.length === 0) {
            container.innerHTML = `
                <div class="empty-message" style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: var(--text-tertiary);">
                    <div style="font-size: 32px; opacity: 0.5; margin-bottom: 12px;">📈</div>
                    <p>No trading data available</p>
                </div>
            `;
            return;
        }

        // Create canvas for simple chart
        const canvas = document.createElement('canvas');
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        container.appendChild(canvas);

        const ctx = canvas.getContext('2d');

        // Simple line chart drawing
        const margin = { top: 20, right: 30, bottom: 40, left: 70 };
        const width = canvas.width - margin.left - margin.right;
        const height = canvas.height - margin.top - margin.bottom;

        // Find min/max values
        const minBalance = Math.min(...equityData.map(d => d.balance));
        const maxBalance = Math.max(...equityData.map(d => d.balance));

        // Draw background
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--surface') || '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw grid lines
        ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--border') || '#e5e7eb';
        ctx.lineWidth = 1;

        // Vertical grid lines
        for (let i = 0; i <= 5; i++) {
            const x = margin.left + (width / 5) * i;
            ctx.beginPath();
            ctx.moveTo(x, margin.top);
            ctx.lineTo(x, margin.top + height);
            ctx.stroke();
        }

        // Horizontal grid lines
        for (let i = 0; i <= 4; i++) {
            const y = margin.top + (height / 4) * i;
            ctx.beginPath();
            ctx.moveTo(margin.left, y);
            ctx.lineTo(margin.left + width, y);
            ctx.stroke();
        }

        // Draw equity line
        ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent') || '#3b82f6';
        ctx.lineWidth = 2;
        ctx.beginPath();

        equityData.forEach((point, index) => {
            const x = margin.left + (width / (equityData.length - 1)) * index;
            const y = margin.top + height - ((point.balance - minBalance) / (maxBalance - minBalance)) * height;

            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });

        ctx.stroke();

        // Draw axis labels
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-secondary') || '#6b7280';
        ctx.font = '12px system-ui';

        // Y-axis labels
        for (let i = 0; i <= 4; i++) {
            const value = minBalance + ((maxBalance - minBalance) / 4) * (4 - i);
            const y = margin.top + (height / 4) * i;
            ctx.fillText('$' + value.toFixed(0), 10, y + 4);
        }

        // Title
        ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--text-primary') || '#111827';
        ctx.font = 'bold 14px system-ui';
        ctx.fillText('Account Balance Over Time', margin.left, 15);
    }

    buildEquityDataSimple() {
        // Simplified version for canvas chart
        const filteredTrades = this.getFilteredTrades();
        const filteredAccounts = this.getFilteredAccounts();

        if (!filteredTrades.length || !filteredAccounts.length) {
            return [];
        }

        const startingBalance = filteredAccounts.reduce((sum, acc) => sum + (acc.startingBalance || 0), 0);

        // Use filtered trades directly (no duplication)
        const allTrades = filteredTrades.map(trade => ({
            date: new Date(trade.date || trade.entryDate),
            pnl: trade.pnl || 0
        }));

        allTrades.sort((a, b) => a.date.getTime() - b.date.getTime());

        const equityData = [];
        let runningBalance = startingBalance;

        equityData.push({ date: new Date(), balance: runningBalance });

        allTrades.forEach(trade => {
            runningBalance += trade.pnl;
            equityData.push({
                date: trade.date,
                balance: runningBalance
            });
        });

        return equityData;
    }

    updateEquityCurve() {
        const container = document.getElementById('equity-curve-chart');
        if (!container) {
            return;
        }

        // Get current active period
        const activeBtn = document.querySelector('.equity-btn.active');
        const period = activeBtn ? activeBtn.dataset.period : 'all';

        if (typeof d3 !== 'undefined') {
            this.renderEquityCurve(period);
        } else {
            this.createSimpleEquityChart();
        }
    }

    initWinRateChart() {
        const canvas = document.getElementById('win-rate-chart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts.winRateChart) {
            this.charts.winRateChart.destroy();
        }

        this.charts.winRateChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Wins', 'Losses'],
                datasets: [{
                    data: [1, 1],
                    backgroundColor: ['#059669', '#dc2626'],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                },
                cutout: '60%'
            }
        });

        this.updateWinRateChart();
    }

    updateWinRateChart() {
        if (!this.charts.winRateChart) return;

        // Use filtered trades instead of all trades
        const filteredTrades = this.getFilteredTrades();

        const wins = filteredTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        }).length;

        const losses = filteredTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        }).length;

        this.charts.winRateChart.data.datasets[0].data = [wins || 1, losses || 1];
        this.charts.winRateChart.update('none');
    }

    initMonthlyPerformance() {
        const canvas = document.getElementById('monthly-performance');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts.monthlyPerformance) {
            this.charts.monthlyPerformance.destroy();
        }

        this.charts.monthlyPerformance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Monthly P&L',
                    data: [],
                    backgroundColor: [],
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toFixed(0);
                            }
                        }
                    }
                }
            }
        });

        this.updateMonthlyPerformance();
    }

    updateMonthlyPerformance() {
        if (!this.charts.monthlyPerformance) return;

        const monthlyData = {};
        // Use filtered trades instead of all trades
        const filteredTrades = this.getFilteredTrades();

        filteredTrades.forEach(trade => {
            try {
                const date = new Date(trade.date || trade.entryDate);
                const monthKey = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;

                if (!monthlyData[monthKey]) {
                    monthlyData[monthKey] = 0;
                }
                monthlyData[monthKey] += (trade.pnl || 0);
            } catch (e) {
                console.error('Invalid date in trade:', trade.date);
            }
        });

        const labels = Object.keys(monthlyData).sort();
        const data = labels.map(label => monthlyData[label]);
        const colors = data.map(value => value >= 0 ? '#059669' : '#dc2626');

        this.charts.monthlyPerformance.data.labels = labels;
        this.charts.monthlyPerformance.data.datasets[0].data = data;
        this.charts.monthlyPerformance.data.datasets[0].backgroundColor = colors;
        this.charts.monthlyPerformance.update('none');
    }

    initPnlDistribution() {
        const canvas = document.getElementById('pnl-distribution');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts.pnlDistribution) {
            this.charts.pnlDistribution.destroy();
        }

        this.charts.pnlDistribution = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Wins', 'Losses'],
                datasets: [{
                    data: [1, 1],
                    backgroundColor: ['#059669', '#dc2626'],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                },
                cutout: '60%'
            }
        });

        this.updatePnlDistribution();
    }

    updatePnlDistribution() {
        if (!this.charts.pnlDistribution) return;

        // Use filtered trades instead of all trades
        const filteredTrades = this.getFilteredTrades();

        const wins = filteredTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'win' || result.toLowerCase() === 'winner');
        }).length;

        const losses = filteredTrades.filter(trade => {
            const result = trade.result;
            return result && (result.toLowerCase() === 'loss' || result.toLowerCase() === 'lose' || result.toLowerCase() === 'loser');
        }).length;

        this.charts.pnlDistribution.data.datasets[0].data = [wins || 1, losses || 1];
        this.charts.pnlDistribution.update('none');
    }

    initSymbolPerformance() {
        const canvas = document.getElementById('symbol-performance');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts.symbolPerformance) {
            this.charts.symbolPerformance.destroy();
        }

        this.charts.symbolPerformance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'P&L by Symbol',
                    data: [],
                    backgroundColor: '#2563eb',
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toFixed(0);
                            }
                        }
                    }
                }
            }
        });

        this.updateSymbolPerformance();
    }

    updateSymbolPerformance() {
        if (!this.charts.symbolPerformance) return;

        const symbolData = {};
        // Use filtered trades instead of all trades
        const filteredTrades = this.getFilteredTrades();

        filteredTrades.forEach(trade => {
            if (!symbolData[trade.symbol]) {
                symbolData[trade.symbol] = 0;
            }
            symbolData[trade.symbol] += (trade.pnl || 0);
        });

        const labels = Object.keys(symbolData);
        const data = labels.map(symbol => symbolData[symbol]);

        this.charts.symbolPerformance.data.labels = labels;
        this.charts.symbolPerformance.data.datasets[0].data = data;
        this.charts.symbolPerformance.update('none');
    }

    initMonthlyBreakdown() {
        const canvas = document.getElementById('monthly-breakdown');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts.monthlyBreakdown) {
            this.charts.monthlyBreakdown.destroy();
        }

        this.charts.monthlyBreakdown = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Monthly P&L',
                    data: [],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toFixed(0);
                        }
                    }
                }
            }
        });

        this.updateMonthlyBreakdown();
    }

    updateMonthlyBreakdown() {
        if (!this.charts.monthlyBreakdown) return;

        const monthlyData = {};
        // Use filtered trades instead of all trades
        const filteredTrades = this.getFilteredTrades();

        filteredTrades.forEach(trade => {
            try {
                const date = new Date(trade.date || trade.entryDate);
                const monthKey = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;

                if (!monthlyData[monthKey]) {
                    monthlyData[monthKey] = 0;
                }
                monthlyData[monthKey] += (trade.pnl || 0);
            } catch (e) {
                console.error('Invalid date in trade:', trade.date);
            }
        });

        const labels = Object.keys(monthlyData).sort();
        const data = labels.map(label => monthlyData[label]);

        this.charts.monthlyBreakdown.data.labels = labels;
        this.charts.monthlyBreakdown.data.datasets[0].data = data;
        this.charts.monthlyBreakdown.update('none');
    }

    initDrawdownChart() {
        const canvas = document.getElementById('drawdown-chart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts.drawdownChart) {
            this.charts.drawdownChart.destroy();
        }

        this.charts.drawdownChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Drawdown %',
                    data: [],
                    borderColor: '#dc2626',
                    backgroundColor: 'rgba(220, 38, 38, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    y: {
                        reverse: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    ticks: {
                        callback: function(value) {
                            return value.toFixed(1) + '%';
                        }
                    }
                }
            }
        });

        this.updateDrawdownChart();
    }

    updateDrawdownChart() {
        if (!this.charts.drawdownChart) return;

        const startingBalance = parseFloat(localStorage.getItem('startingBalance') || '10000');
        // Use filtered trades instead of all trades
        const filteredTrades = this.getFilteredTrades();
        const sortedTrades = [...filteredTrades].sort((a, b) => {
            try {
                const dateA = new Date(a.date || a.entryDate);
                const dateB = new Date(b.date || b.entryDate);
                return dateA.getTime() - dateB.getTime();
            } catch {
                return 0;
            }
        });

        const labels = [];
        const drawdowns = [];

        let peak = startingBalance;
        let running = startingBalance;

        sortedTrades.forEach(trade => {
            running += (trade.pnl || 0);
            if (running > peak) peak = running;
            const drawdown = peak > 0 ? ((peak - running) / peak) * 100 : 0;

            labels.push(this.formatDate(trade.date || trade.entryDate));
            drawdowns.push(drawdown);
        });

        this.charts.drawdownChart.data.labels = labels;
        this.charts.drawdownChart.data.datasets[0].data = drawdowns;
        this.charts.drawdownChart.update('none');
    }

    updateCharts() {
        // Update equity curve (D3.js)
        if (typeof d3 !== 'undefined') {
            this.updateEquityCurve();
        }

        // Update Chart.js charts if available
        if (typeof Chart !== 'undefined') {
            this.updateWinRateChart();
            this.updateMonthlyPerformance();
            this.updatePnlDistribution();
            this.updateSymbolPerformance();
            this.updateMonthlyBreakdown();
            this.updateDrawdownChart();
        }
    }

    // СУБТРЕЙДИ (незалежні трейди з parentTradeId)
    addSubtrade(parentTradeId) {
        const parentTrade = this.trades.find(t => t.id === parentTradeId);
        if (!parentTrade) return;

        const nextTradeNumber = this.getNextTradeNumber();

        // Створюємо новий незалежний трейд як субтрейд
        const newSubtrade = {
            id: Date.now(),
            tradeNumber: nextTradeNumber,
            parentTradeId: parentTradeId, // Зв'язок з батьківським трейдом
            symbol: parentTrade.symbol,
            direction: parentTrade.direction,
            strategy: parentTrade.strategy,
            result: 'Win', // За замовчуванням
            entryDate: parentTrade.entryDate,
            exitDate: parentTrade.exitDate,
            pnl: 0, // Буде заповнено вручну
            risk: 1, // За замовчуванням
            riskReward: 0,
            notes: '',
            screenshot: null,
            screenshots: [],
            date: parentTrade.entryDate,
            accountId: null // Буде вибрано вручну
        };

        this.trades.push(newSubtrade);
        this.saveData();

        // Оновлюємо відображення
        this.updateAllMetrics();
        this.updateAllTables();

        // Відкриваємо форму редагування для нового субтрейду
        this.editTrade(newSubtrade.id);

        this.showNotification('Subtrade added successfully!', 'success');
    }

    editSubtrade(parentTradeId, subtradeId) {
        this.editTrade(subtradeId);
    }

    deleteSubtrade(parentTradeId, subtradeId) {
        this.trades = this.trades.filter(trade => trade.id !== subtradeId);
        this.saveData();
        this.updateAllMetrics();
        this.updateAllTables();
        this.showNotification('Subtrade deleted successfully!', 'success');
    }

    updateProfitDisplayCard(profit, risk, rr, account) {
        const card = document.getElementById('profit-display-card');
        const amountEl = document.getElementById('profit-display-amount');
        const riskEl = document.getElementById('profit-detail-risk');
        const rrEl = document.getElementById('profit-detail-rr');
        const accountEl = document.getElementById('profit-detail-account');

        if (!card || !amountEl) return;

        // Показуємо картку тільки якщо є профіт
        if (profit !== 0) {
            card.style.display = 'block';

            // Оновлюємо суму з правильним відображенням мінуса
            amountEl.textContent = `${profit >= 0 ? '+' : '-'}$${Math.abs(profit).toFixed(2)}`;

            // Оновлюємо класи для кольорів
            card.className = 'profit-display-card';
            amountEl.className = 'profit-display-amount';

            if (profit > 0) {
                card.classList.add('positive');
                amountEl.classList.add('positive');
            } else if (profit < 0) {
                card.classList.add('negative');
                amountEl.classList.add('negative');
            }

            // Оновлюємо деталі
            if (riskEl) riskEl.textContent = `${risk.toFixed(1)}%`;
            if (rrEl) rrEl.textContent = rr.toFixed(1);
            if (accountEl) accountEl.textContent = account ? account.name : '-';
        } else {
            card.style.display = 'none';
        }
    }

    updateEditProfitDisplayCard(profit, risk, rr, account) {
        const card = document.getElementById('edit-profit-display-card');
        const amountEl = document.getElementById('edit-profit-display-amount');
        const riskEl = document.getElementById('edit-profit-detail-risk');
        const rrEl = document.getElementById('edit-profit-detail-rr');
        const accountEl = document.getElementById('edit-profit-detail-account');

        if (!card || !amountEl) return;

        // Показуємо картку тільки якщо є профіт
        if (profit !== 0) {
            card.style.display = 'block';

            // Оновлюємо суму з правильним відображенням мінуса
            amountEl.textContent = `${profit >= 0 ? '+' : '-'}$${Math.abs(profit).toFixed(2)}`;

            // Оновлюємо класи для кольорів
            card.className = 'profit-display-card';
            amountEl.className = 'profit-display-amount';

            if (profit > 0) {
                card.classList.add('positive');
                amountEl.classList.add('positive');
            } else if (profit < 0) {
                card.classList.add('negative');
                amountEl.classList.add('negative');
            }

            // Оновлюємо деталі
            if (riskEl) riskEl.textContent = `${risk.toFixed(1)}%`;
            if (rrEl) rrEl.textContent = rr.toFixed(1);
            if (accountEl) accountEl.textContent = account ? account.name : '-';
        } else {
            card.style.display = 'none';
        }
    }

    openScreenshotFullscreen(screenshotSrc) {
        // Create fullscreen overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.95);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        `;

        const img = document.createElement('img');
        img.src = screenshotSrc;
        img.style.cssText = `
            max-width: 95vw;
            max-height: 95vh;
            object-fit: contain;
            border-radius: 8px;
            box-shadow: 0 0 50px rgba(0, 0, 0, 0.5);
        `;

        // Close on click
        overlay.addEventListener('click', () => {
            document.body.removeChild(overlay);
        });

        // Close on ESC key
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                document.body.removeChild(overlay);
                document.removeEventListener('keydown', handleEsc);
            }
        };
        document.addEventListener('keydown', handleEsc);

        overlay.appendChild(img);
        document.body.appendChild(overlay);
    }

    viewSubtradeScreenshot(screenshotSrc) {
        this.openScreenshotFullscreen(screenshotSrc);
    }

    // НАЛАШТУВАННЯ
    saveSettings() {
        const startingBalance = document.getElementById('starting-balance');
        const currency = document.getElementById('currency-setting');
        const theme = document.getElementById('theme-setting');
        const compactMode = document.getElementById('compact-mode');

        if (startingBalance?.value) localStorage.setItem('startingBalance', startingBalance.value);
        if (currency?.value) localStorage.setItem('currency', currency.value);
        if (theme?.value) localStorage.setItem('theme', theme.value);
        if (compactMode) localStorage.setItem('compactMode', compactMode.checked.toString());

        this.updateAllMetrics();
        this.showNotification('Settings saved successfully!', 'success');
    }

    loadSettings() {
        const startingBalance = localStorage.getItem('startingBalance') || '10000';
        const currency = localStorage.getItem('currency') || 'USD';
        const theme = localStorage.getItem('theme') || 'light';
        const compactMode = localStorage.getItem('compactMode') === 'true';

        const startingBalanceEl = document.getElementById('starting-balance');
        const currencyEl = document.getElementById('currency-setting');
        const themeEl = document.getElementById('theme-setting');
        const compactModeEl = document.getElementById('compact-mode');

        if (startingBalanceEl) startingBalanceEl.value = startingBalance;
        if (currencyEl) currencyEl.value = currency;
        if (themeEl) themeEl.value = theme;
        if (compactModeEl) compactModeEl.checked = compactMode;
    }

    // ДАНІ
    saveData() {
        try {
            localStorage.setItem('trades', JSON.stringify(this.trades));
        } catch (e) {
            console.error('Error saving trades:', e);
        }
    }

    loadData() {
        try {
            const savedTrades = localStorage.getItem('trades');
            if (savedTrades) {
                this.trades = JSON.parse(savedTrades);

                // Assign trade numbers to existing trades that don't have them
                this.assignTradeNumbers();

                console.log('Loaded trades from localStorage:', this.trades.length, 'trades');
                console.log('Sample trade data:', this.trades[0]);
            } else {
                // Створюємо тестовий трейд якщо їх немає
                const today = new Date().toISOString().split('T')[0];
                this.trades = [{
                    id: 'test-trade-1',
                    entryDate: today,
                    exitDate: today,
                    accountId: 'test-account-1',
                    symbol: 'EURUSD',
                    direction: 'buy',
                    risk: 2.0,
                    profit: 150.00,
                    pnl: 150.00,
                    rr: 2.5,
                    result: 'win',
                    strategyId: null,
                    entryModelId: null,
                    notes: 'Test trade - click edit to modify',
                    createdAt: new Date().toISOString(),
                    tradeNumber: 1
                }];
                this.saveData();
                console.log('Created test trade');
            }
        } catch (e) {
            console.error('Error loading trades:', e);
            this.trades = [];
        }
    }

    assignTradeNumbers() {
        // Sort trades by date to assign numbers chronologically
        const sortedTrades = [...this.trades].sort((a, b) => {
            const dateA = new Date(a.date || a.entryDate);
            const dateB = new Date(b.date || b.entryDate);
            return dateA.getTime() - dateB.getTime();
        });

        let tradeNumber = 1;
        sortedTrades.forEach(trade => {
            if (!trade.tradeNumber) {
                // Find the original trade in the array and assign number
                const originalTrade = this.trades.find(t => t.id === trade.id);
                if (originalTrade) {
                    originalTrade.tradeNumber = tradeNumber;
                }
                tradeNumber++;
            } else {
                tradeNumber = Math.max(tradeNumber, trade.tradeNumber + 1);
            }
        });

        // Save updated trades
        if (this.trades.some(trade => !trade.tradeNumber)) {
            this.saveData();
        }
    }

    saveAccounts() {
        try {
            localStorage.setItem('accounts', JSON.stringify(this.accounts));
        } catch (e) {
            console.error('Error saving accounts:', e);
        }
    }

    loadAccounts() {
        try {
            const savedAccounts = localStorage.getItem('accounts');
            if (savedAccounts) {
                this.accounts = JSON.parse(savedAccounts);
                
                // Міграція: додаємо startingBalance для старих акаунтів
                let needsSave = false;
                this.accounts.forEach(account => {
                    if (!account.startingBalance && account.balance) {
                        account.startingBalance = account.balance;
                        needsSave = true;
                    }
                });
                
                if (needsSave) {
                    this.saveAccounts();
                    console.log('Migrated accounts: added startingBalance field');
                }
                
                console.log('Loaded accounts from localStorage:', this.accounts.length);
            } else {
                // Створюємо тестовий акаунт якщо їх немає
                this.accounts = [{
                    id: 'test-account-1',
                    name: 'Demo Account',
                    type: 'demo',
                    balance: 10000,
                    startingBalance: 10000,
                    currency: 'USD'
                }];
                this.saveAccounts();
                console.log('Created test account');
            }
        } catch (e) {
            console.error('Error loading accounts:', e);
            this.accounts = [];
        }
    }

    // ЕКСПОРТ/ІМПОРТ
    exportData() {
        try {
            const data = {
                trades: this.trades,
                settings: {
                    startingBalance: localStorage.getItem('startingBalance'),
                    currency: localStorage.getItem('currency')
                },
                exportDate: new Date().toISOString()
            };

            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `tradescope-export-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

            this.showNotification('Data exported successfully!', 'success');
        } catch (e) {
            console.error('Error exporting data:', e);
            this.showNotification('Error exporting data', 'error');
        }
    }

    importData() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'application/json';

        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);

                    if (data.trades) {
                        this.trades = data.trades;
                        this.saveData();
                    }

                    this.updateAllMetrics();
                    this.updateAllTables();
                    this.updateCharts();
                    this.renderCalendar();

                    this.showNotification('Data imported successfully!', 'success');
                } catch (error) {
                    this.showNotification('Error importing data', 'error');
                }
            };
            reader.readAsText(file);
        };

        input.click();
    }

    clearAllData() {
        if (confirm('Are you sure you want to clear all data?')) {
            this.trades = [];
            this.saveData();
            this.updateAllMetrics();
            this.updateAllTables();
            this.updateCharts();
            this.renderCalendar();
            this.showNotification('All data cleared!', 'success');
        }
    }

    // ПОВІДОМЛЕННЯ
    showNotification(message, type = 'info') {
        console.log('Showing notification:', message, type);

        // Створити контейнер якщо його немає
        let container = document.getElementById('notification-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            container.className = 'notification-container';
            document.body.appendChild(container);
        }

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i data-lucide="${type === 'success' ? 'check-circle' : type === 'error' ? 'x-circle' : 'info'}"></i>
            <span>${message}</span>
        `;

        // Додати стилі для повідомлення
        notification.style.cssText = `
            padding: 12px 16px;
            margin: 8px 0;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 8px;
            color: white;
            font-weight: 500;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            animation: slideIn 0.3s ease;
        `;

        container.appendChild(notification);
        if (typeof lucide !== 'undefined') lucide.createIcons();

        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }
        }, 3000);
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        if (sidebar && mainContent) {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('sidebar-collapsed');
        }
    }

    // ========================================
    // CALENDAR SECTION METHODS
    // ========================================

    initCalendarSection() {
        this.currentCalendarViewDate = new Date();
        this.setupCalendarNavigation();
        this.renderCalendarView();
    }

    setupCalendarNavigation() {
        const prevBtn = document.getElementById('prevMonth');
        const nextBtn = document.getElementById('nextMonth');

        if (prevBtn && !prevBtn.hasAttribute('data-calendar-setup')) {
            prevBtn.setAttribute('data-calendar-setup', 'true');
            prevBtn.addEventListener('click', () => {
                this.currentCalendarViewDate.setMonth(this.currentCalendarViewDate.getMonth() - 1);
                this.renderCalendarView();
            });
        }

        if (nextBtn && !nextBtn.hasAttribute('data-calendar-setup')) {
            nextBtn.setAttribute('data-calendar-setup', 'true');
            nextBtn.addEventListener('click', () => {
                this.currentCalendarViewDate.setMonth(this.currentCalendarViewDate.getMonth() + 1);
                this.renderCalendarView();
            });
        }

        // View toggle buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            if (!btn.hasAttribute('data-calendar-setup')) {
                btn.setAttribute('data-calendar-setup', 'true');
                btn.addEventListener('click', (e) => {
                    document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
                    e.target.classList.add('active');
                    // Future: implement quarterly and yearly views
                });
            }
        });
    }

    renderCalendarView() {
        this.renderCalendarMonth();
        this.renderWeekSummary();
        this.renderCalendarGrid();
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    renderCalendarMonth() {
        const monthDisplay = document.getElementById('currentMonthDisplay');
        if (monthDisplay) {
            const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                               'July', 'August', 'September', 'October', 'November', 'December'];
            monthDisplay.textContent = 
                `${monthNames[this.currentCalendarViewDate.getMonth()]} ${this.currentCalendarViewDate.getFullYear()}`;
        }
    }

    renderWeekSummary() {
        const container = document.getElementById('weekSummary');
        if (!container) return;

        const weeks = this.getWeeksData();
        
        if (weeks.length === 0) {
            container.innerHTML = '<div style="padding: var(--space); text-align: center; color: var(--text-tertiary); font-size: 12px;">No data</div>';
            return;
        }

        container.innerHTML = weeks.map((week, index) => {
            const pnlClass = week.pnl === 0 ? 'neutral' : (week.pnl > 0 ? 'positive' : 'negative');
            const pnlSign = week.pnl > 0 ? '+' : (week.pnl < 0 ? '-' : '');
            return `
                <div class="week-card">
                    <div class="week-header">
                        <span class="week-title">Week ${index + 1}</span>
                        <span class="week-trades">${week.trades}</span>
                    </div>
                    <div class="week-pnl ${pnlClass}">
                        ${pnlSign}$${Math.abs(week.pnl).toFixed(0)}
                    </div>
                    <div class="week-percentage">
                        ${week.percentage > 0 ? '+' : week.percentage < 0 ? '-' : ''}${Math.abs(week.percentage).toFixed(2)}%
                    </div>
                    <div class="week-days">${week.days} day${week.days !== 1 ? 's' : ''}</div>
                </div>
            `;
        }).join('');
    }

    getWeeksData() {
        const year = this.currentCalendarViewDate.getFullYear();
        const month = this.currentCalendarViewDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        
        const weeks = [];
        let currentWeekStart = new Date(firstDay);
        
        // Adjust to Monday
        const dayOfWeek = currentWeekStart.getDay();
        const daysToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
        currentWeekStart.setDate(currentWeekStart.getDate() + daysToMonday);
        
        while (currentWeekStart <= lastDay || weeks.length === 0) {
            const weekEnd = new Date(currentWeekStart);
            weekEnd.setDate(weekEnd.getDate() + 6);
            
            const weekTrades = this.trades.filter(trade => {
                const tradeDate = new Date(trade.entryDate || trade.date);
                return tradeDate >= currentWeekStart && tradeDate <= weekEnd &&
                       tradeDate.getMonth() === month;
            });
            
            if (weekTrades.length > 0 || weeks.length < 4) {
                const weekPnl = weekTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                const initialBalance = 10000; // You might want to get this from settings
                const weekPercentage = (weekPnl / initialBalance) * 100;
                
                // Count trading days
                const tradingDays = new Set(weekTrades.map(t => 
                    new Date(t.entryDate || t.date).toDateString()
                )).size;
                
                weeks.push({
                    pnl: weekPnl,
                    percentage: weekPercentage,
                    trades: weekTrades.length,
                    days: tradingDays
                });
            }
            
            currentWeekStart.setDate(currentWeekStart.getDate() + 7);
            if (weeks.length >= 5) break; // Max 5 weeks per month
        }
        
        return weeks;
    }

    renderCalendarGrid() {
        const grid = document.getElementById('calendarGridView');
        if (!grid) return;

        const year = this.currentCalendarViewDate.getFullYear();
        const month = this.currentCalendarViewDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        
        // Get day of week (0 = Sunday, 1 = Monday, etc.)
        let startDay = firstDay.getDay();
        // Convert to Monday = 0
        startDay = startDay === 0 ? 6 : startDay - 1;
        
        const daysInMonth = lastDay.getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();
        
        grid.innerHTML = '';
        
        // Previous month days
        for (let i = startDay - 1; i >= 0; i--) {
            const day = daysInPrevMonth - i;
            const cell = this.createDayCell(day, true, false);
            grid.appendChild(cell);
        }
        
        // Current month days
        const today = new Date();
        for (let day = 1; day <= daysInMonth; day++) {
            const date = new Date(year, month, day);
            const isToday = date.toDateString() === today.toDateString();
            const cell = this.createDayCell(day, false, isToday, date);
            grid.appendChild(cell);
        }
        
        // Next month days
        const totalCells = grid.children.length;
        const remainingCells = 35 - totalCells; // 5 weeks × 7 days
        for (let day = 1; day <= remainingCells; day++) {
            const cell = this.createDayCell(day, true, false);
            grid.appendChild(cell);
        }
    }

    createDayCell(day, isOtherMonth, isToday, date = null) {
        const cell = document.createElement('div');
        cell.className = 'calendar-day-cell';
        if (isOtherMonth) cell.classList.add('other-month');
        if (isToday) cell.classList.add('today');
        
        let content = `<div class="day-number">${day}</div>`;
        
        if (date && !isOtherMonth) {
            const dateStr = date.toISOString().split('T')[0];
            const dayTrades = this.trades.filter(trade => {
                const tradeDate = trade.entryDate || trade.date;
                return tradeDate === dateStr;
            });
            
            if (dayTrades.length > 0) {
                const totalPnl = dayTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                const initialBalance = 10000; // Get from settings
                const totalPercentage = (totalPnl / initialBalance) * 100;
                const avgRR = dayTrades.reduce((sum, t) => sum + (t.rr || 0), 0) / dayTrades.length;
                
                const pnlClass = totalPnl >= 0 ? 'positive' : 'negative';
                const indicator = totalPnl >= 0 ? 'win' : 'loss';
                const pnlSign = totalPnl > 0 ? '+' : (totalPnl < 0 ? '-' : '');
                const percentSign = totalPercentage > 0 ? '+' : (totalPercentage < 0 ? '-' : '');
                
                content += `
                    <div class="day-indicator ${indicator}"></div>
                    <div class="day-trades-count">${dayTrades.length} trade${dayTrades.length > 1 ? 's' : ''}</div>
                    <div class="day-pnl ${pnlClass}">${pnlSign}$${Math.abs(totalPnl).toFixed(2)}</div>
                    <div class="day-percentage ${pnlClass}">${percentSign}${Math.abs(totalPercentage).toFixed(2)}%</div>
                    <div class="day-rr">RR ${avgRR.toFixed(2)}</div>
                `;
            }
        }
        
        cell.innerHTML = content;
        return cell;
    }
}

// ========================================
// ГЛОБАЛЬНІ ФУНКЦІЇ
// ========================================

window.toggleSidebar = () => {
    if (window.app) window.app.toggleSidebar();
};

window.showAddTradeModal = () => {
    console.log('Global showAddTradeModal called - should open TRADE modal');
    if (window.app && typeof window.app.showAddTradeModal === 'function') {
        window.app.showAddTradeModal();
    } else {
        console.error('App or showAddTradeModal method not available');
    }
};

window.showAddAccountModal = () => {
    console.log('Global showAddAccountModal called - should open ACCOUNT modal');
    if (window.app && typeof window.app.showAddAccountModal === 'function') {
        window.app.showAddAccountModal();
    } else {
        console.error('App or showAddAccountModal method not available');
    }
};

window.toggleFiltersPanel = () => {
    if (window.app) window.app.toggleFiltersPanel();
};

window.closeModal = (modalId) => {
    if (window.app) window.app.closeModal(modalId);
};

window.showSection = (section) => {
    if (window.app) window.app.showSection(section);
};

window.previousMonth = () => {
    if (window.app) window.app.previousMonth();
};

window.nextMonth = () => {
    if (window.app) window.app.nextMonth();
};

window.exportData = () => {
    if (window.app) window.app.exportData();
};

window.importData = () => {
    if (window.app) window.app.importData();
};

window.clearAllData = () => {
    if (window.app) window.app.clearAllData();
};

window.toggleAccountSection = (status) => {
    if (window.app) window.app.toggleAccountSection(status);
};

window.toggleAccountFilter = () => {
    if (window.app) window.app.toggleAccountFilter();
};

window.selectAllAccounts = () => {
    if (window.app) window.app.selectAllAccounts();
};

window.deselectAllAccounts = () => {
    if (window.app) window.app.deselectAllAccounts();
};

window.selectCalendarDay = (day, month, year) => {
    if (window.app) window.app.selectCalendarDay(day, month, year);
};

// ========================================
// ІНІЦІАЛІЗАЦІЯ
// ========================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing TradingApp...');

    try {
        window.app = new TradingApp();
        console.log('TradingApp initialized successfully!');
        // Ensure all modal methods are bound to the instance
        window.app.showEntryModelsManager = window.app.showEntryModelsManager.bind(window.app);
    } catch (error) {
        console.error('Error initializing app:', error);
    }

    // Закриття модальних вікон при кліку поза ними
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-overlay')) {
            const modal = e.target.closest('.modal');
            if (modal) {
                modal.classList.remove('show');
                document.body.style.overflow = '';
            }
        }
    });

    // Закриття панелі фільтрів
    document.addEventListener('click', (e) => {
        const filtersPanel = document.querySelector('.filters-panel');
        const filtersDropdown = document.getElementById('filtersDropdown');

        if (filtersPanel && filtersDropdown && !filtersPanel.contains(e.target)) {
            filtersDropdown.classList.remove('show');
        }
    });

    // Обробка налаштувань
    const settingsInputs = ['starting-balance', 'currency-setting', 'theme-setting', 'compact-mode'];
    settingsInputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('change', () => {
                if (window.app) window.app.saveSettings();
            });
        }
    });
});